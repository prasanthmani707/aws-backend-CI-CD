import boto3
import json

def lambda_handler(event, context):
    print(f"📩 Received event: {json.dumps(event)}")

    # -------------------------------------------------
    # 1️⃣ Extract instance_id
    # -------------------------------------------------
    instance_id = None

    if 'instance_id' in event:
        instance_id = event['instance_id']
    elif 'detail' in event and isinstance(event['detail'], dict):
        instance_id = event['detail'].get('instance_id')
    elif 'detail' in event and isinstance(event['detail'], str):
        try:
            instance_id = json.loads(event['detail']).get('instance_id')
        except json.JSONDecodeError:
            pass

    if not instance_id:
        print("❌ No instance_id provided")
        return {
            "statusCode": 400,
            "body": "No instance_id provided"
        }

    # -------------------------------------------------
    # 2️⃣ REGION RESOLUTION (MULTI-REGION SAFE)
    # -------------------------------------------------
    region = event.get("region")

    # Backward compatibility – infer from Scheduler ARN
    if not region and "resources" in event and event["resources"]:
        try:
            # arn:aws:scheduler:ap-south-1:xxx:schedule/default/Stop-i-xxx
            region = event["resources"][0].split(":")[3]
            print(f"🌍 Region inferred from ARN: {region}")
        except Exception:
            pass

    # Final fallback – Lambda deployment region
    if not region:
        region = boto3.session.Session().region_name
        print(f"⚠️ Falling back to Lambda region: {region}")

    if not region:
        return {
            "statusCode": 400,
            "body": "Region not provided and could not be inferred"
        }

    print(f"🔄 Processing instance {instance_id} in region {region}")

    # -------------------------------------------------
    # 3️⃣ AWS Clients (Region-aware)
    # -------------------------------------------------
    ec2 = boto3.client("ec2", region_name=region)
    events = boto3.client("events", region_name=region)
    scheduler = boto3.client("scheduler", region_name=region)

    try:
        # -------------------------------------------------
        # 4️⃣ Validate instance state
        # -------------------------------------------------
        response = ec2.describe_instances(InstanceIds=[instance_id])
        instance = response["Reservations"][0]["Instances"][0]
        state = instance["State"]["Name"]

        if state != "running":
            print(f"⚠️ Instance {instance_id} not running (state={state})")
            return {
                "statusCode": 200,
                "body": f"Instance {instance_id} already {state}"
            }

        # -------------------------------------------------
        # 5️⃣ Stop instance
        # -------------------------------------------------
        print(f"🛑 Stopping instance {instance_id}")
        ec2.stop_instances(InstanceIds=[instance_id])
        print(f"✔ Instance {instance_id} stop initiated")

        # -------------------------------------------------
        # 6️⃣ Identify matching schedule / rule
        # -------------------------------------------------
        rule_name = None

        # From Scheduler event ARN
        if "resources" in event and event["resources"]:
            rule_name = event["resources"][0].split("/")[-1]
            print(f"🧭 Schedule name from ARN: {rule_name}")

        # Fallback search by prefix
        if not rule_name:
            prefix = f"Stop-{instance_id}-"
            print(f"🔍 Searching schedules with prefix {prefix}")

            # Scheduler
            schedules = scheduler.list_schedules(NamePrefix=prefix)
            if schedules.get("Schedules"):
                rule_name = schedules["Schedules"][0]["Name"]
                print(f"📅 Found Scheduler schedule: {rule_name}")

            # Legacy EventBridge rule
            if not rule_name:
                rules = events.list_rules(NamePrefix=prefix)
                if rules.get("Rules"):
                    rule_name = rules["Rules"][0]["Name"]
                    print(f"📜 Found legacy EventBridge rule: {rule_name}")

        # -------------------------------------------------
        # 7️⃣ CLEANUP – Scheduler
        # -------------------------------------------------
        if rule_name:
            try:
                scheduler.delete_schedule(Name=rule_name)
                print(f"🧹 Scheduler schedule deleted: {rule_name}")
            except scheduler.exceptions.ResourceNotFoundException:
                print(f"ℹ Scheduler schedule not found: {rule_name}")

            # -------------------------------------------------
            # 8️⃣ CLEANUP – Legacy EventBridge Rule
            # -------------------------------------------------
            try:
                targets = events.list_targets_by_rule(Rule=rule_name)
                if targets.get("Targets"):
                    ids = [t["Id"] for t in targets["Targets"]]
                    events.remove_targets(Rule=rule_name, Ids=ids)

                events.delete_rule(Name=rule_name)
                print(f"🧹 EventBridge rule deleted: {rule_name}")
            except events.exceptions.ResourceNotFoundException:
                print(f"ℹ No legacy EventBridge rule found")
            except Exception as e:
                print(f"⚠️ Error deleting EventBridge rule: {str(e)}")

        else:
            print("ℹ No schedule or rule found for cleanup")

        return {
            "statusCode": 200,
            "body": f"Instance {instance_id} stopped successfully (region={region})"
        }

    except ec2.exceptions.ClientError as e:
        if "InvalidInstanceID.NotFound" in str(e):
            return {
                "statusCode": 404,
                "body": f"Instance {instance_id} not found in region {region}"
            }
        raise

    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Error stopping instance: {str(e)}"
        }
