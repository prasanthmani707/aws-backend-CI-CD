import json
import requests
from requests.auth import HTTPBasicAuth

def lambda_handler(event, context):
    # Parse body from API Gateway
    if "body" in event and isinstance(event["body"], str):
        body = json.loads(event["body"])
    else:
        body = event

    management_server_ip = body.get("management_server_ip")
    username = body.get("username")
    password = body.get("password")

    url = f"https://{management_server_ip}:8089/services/licenser/licenses?output_mode=json"

    try:
        requests.packages.urllib3.disable_warnings()

        response = requests.get(
            url,
            auth=HTTPBasicAuth(username, password),
            verify=False,
            timeout=10
        )

        if response.status_code != 200:
            return _json_response({
                "status": "error",
                "message": f"Failed to connect to Splunk. HTTP {response.status_code}",
                "details": response.text
            })

        data = response.json()
        licenses = data.get("entry", [])

        for lic in licenses:
            content = lic.get("content", {})
            group_id = content.get("group_id", "")
            status = content.get("status", "")

            if status == "VALID":
                if group_id == "Trial":
                    return _json_response({"status": "Splunk Enterprise Trial free account"})
                elif group_id == "Enterprise":
                    return _json_response({"status": "Splunk License updated"})

        return _json_response({"status": "No valid Enterprise/Trial license found"})

    except requests.exceptions.RequestException as e:
        return _json_response({"status": "error", "message": str(e)})

def _json_response(data: dict, status_code: int = 200):
    """Helper to return clean JSON API Gateway proxy response"""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(data)
    }
