import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('user_profile_creditbased')

def lambda_handler(event, context):
    try:
        # Get query parameters
        params = event.get('queryStringParameters') or {}
        email_id = params.get('email_id')

        # Validate email_id
        if not email_id:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing email_id parameter'})
            }

        email_id = email_id.strip().lower()

        # Fetch from DynamoDB
        response = table.get_item(
            Key={
                'email_id': email_id
            }
        )

        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({'User_exists': 'false'})
            }

        return {
            'statusCode': 200,
            'body': json.dumps(response['Item'])
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error'})
        }
