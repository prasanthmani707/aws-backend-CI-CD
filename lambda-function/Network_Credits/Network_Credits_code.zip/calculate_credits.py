import datetime

def calculate_credits(bytes_out,price_per_gb):
    gp = bytes_out / (1024**3)
    credits = gp * float(price_per_gb)
    return credits