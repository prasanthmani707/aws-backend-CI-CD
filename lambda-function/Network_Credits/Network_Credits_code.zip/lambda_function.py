import json
import boto3
import datetime
import store
from store import get_start_time
from store import store_start_time
from get_network_out import get_network_out
from get_price_per_gb import get_price_per_gp
from calculate_credits import calculate_credits
from store import store_credits


def lambda_handler(event, context):
    detail = event.get('detail',{})
    instance_id = detail.get('instance-id')
    state = detail.get('state')
    if not instance_id:
        return {"error": "No instance_id"}
    if not state:
        return {"error": "No state"}
    if state == 'running':
        store_start_time(instance_id)
        return{
            "message": "start time stored",
            "instance_id": instance_id
        }
    elif state == 'stopped':
        start_time_str = get_start_time(instance_id)   
        if not start_time_str:
            return{
                "error": "start time not found"
            }
        start_time = datetime.datetime.fromisoformat(start_time_str)
        end_time = datetime.datetime.utcnow()
        bytes_out = get_network_out(instance_id, start_time, end_time)
        print(bytes_out)
        price_per_gb = get_price_per_gp()
        print(f"price per gb {price_per_gb}")
        credits = calculate_credits(bytes_out, price_per_gb)
        store_credits(instance_id, credits, start_time, end_time, bytes_out)
        return{
            "message": "credits stored",
            "instance_id": instance_id,
            "credits": credits,
            "bytes_out": bytes_out,
            "price_per_gb": price_per_gb    
        }
    return {
        "message": "No action"
    }
