import boto3
import json
import datetime
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Network_credits')

def store_start_time(instance_id):
    start_time = datetime.datetime.utcnow().isoformat()
    table.put_item(
        Item={
            'instance_id': instance_id,
            'start_time': start_time
        }
    )
    return start_time

def get_start_time(instance_id):
    response = table.query(
        KeyConditionExpression="instance_id = :id",
        ExpressionAttributeValues={":id": instance_id},
        ScanIndexForward=False,  # latest first
        Limit=1
    )

    items = response.get('Items', [])
    
    if not items:
        return None

    return items[0]['start_time']

def store_credits(instance_id, start_time, credits, end_time, bytes_out):
    table.update_item(
        Key={
            'instance_id': instance_id,
            'start_time': start_time
        },
        UpdateExpression="""
            SET end_time = :et,
                bytes_out = :bo,
                usdcost = :c
        """,
        ExpressionAttributeValues={
            ':et': end_time.isoformat(),
            ':bo': int(bytes_out),
            ':c': Decimal(str(credits))
        }
    )