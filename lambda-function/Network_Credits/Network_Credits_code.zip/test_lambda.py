from lambda_function import lambda_handler
event = {
    "detail": {
        "instance-id": "i-08fcd6a5db9a2f68f",
        "state": "stopped"
    }
}

response = lambda_handler(event, None)
print(response)