import boto3

cloudwatch = boto3.client('cloudwatch')


def get_network_out(instance_id, start_time, end_time):
    response = cloudwatch.get_metric_statistics(
        Namespace='AWS/EC2',
        MetricName='NetworkOut',
        Dimensions=[   # ✅ fixed
            {
                'Name': 'InstanceId',
                'Value': instance_id
            }
        ],
        StartTime=start_time,
        EndTime=end_time,
        Period=3600,   # ✅ fixed
        Statistics=['Sum']
    )

    total_bytes = sum(dp['Sum'] for dp in response['Datapoints'])  # ✅ fixed
    print(f"Total bytes out: {total_bytes}")
    return total_bytes