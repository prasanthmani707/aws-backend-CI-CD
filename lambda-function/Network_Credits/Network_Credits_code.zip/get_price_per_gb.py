import boto3
import json
import datetime

pricing = boto3.client('pricing', region_name='us-east-1')

def get_price_per_gp():
    response = pricing.get_products(
        ServiceCode='AmazonEC2',
        Filters = [
            {
                'Type':'TERM_MATCH',
                'Field':'productFamily',
                'Value':'Data Transfer'
            },
            {
                'Type':'TERM_MATCH',
                'Field':'transferType',
                'Value':'AWS Outbound'
            }
        ],
        MaxResults=1
    )
    price_item = json.loads(response['PriceList'][0])
    terms = price_item['terms']['OnDemand']

    for term in terms.values():
        for dim in term['priceDimensions'].values():
            return dim['pricePerUnit']['USD']
        
    return 0.0


    