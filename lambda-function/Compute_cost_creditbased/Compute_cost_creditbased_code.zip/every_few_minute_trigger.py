import boto3
from datetime import datetime
from decimal import Decimal
from boto3.dynamodb.conditions import Key
from calculate_cost import calculate_cost

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('compute_cost_creditbased')

def process_running_instances():
    now = datetime.utcnow()

    # Query all currently running instances
    response = table.query(
        IndexName='few_minute_trigger',  # make sure this GSI exists
        KeyConditionExpression=Key('state').eq('running')
    )

    items = response.get('Items', [])

    for item in items:
        instance_id = item['instance_id']

        # Calculate incremental cost since last calculation
        incremental_cost, incremental_seconds = calculate_cost(item, now)

        if incremental_cost == 0:
            continue  # nothing new to update

        # Update DynamoDB: cumulative + incremental fields
        table.update_item(
            Key={
                'instance_id': instance_id,
                'tnx_id': item['tnx_id']
            },
            UpdateExpression="""
                SET session_total_cost = if_not_exists(total_cost, :zero) + :inc_cost,
                    total_cost = :inc_cost,
                    session_used_time_seconds = if_not_exists(used_time_seconds, :zero) + :inc_sec,
                    used_time_seconds = :inc_sec,
                    last_calculated_time = :now
            """,
            ExpressionAttributeValues={
                ':inc_cost': incremental_cost,
                ':inc_sec': incremental_seconds,
                ':now': now.isoformat(),
                ':zero': Decimal("0")
            }
        )

        print(f"Updated running cost for {instance_id} → {incremental_cost} | "
              f"User time: {incremental_seconds}s")

    return {"statusCode": 200}