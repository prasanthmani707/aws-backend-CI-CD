import json
import boto3
import os
from decimal import Decimal
from boto3.dynamodb.conditions import Key
from auth_utils import get_email_from_event

dynamodb = boto3.resource("dynamodb")

TABLE_NAME = os.environ.get(
    "CLUSTER_RETENTION_TABLE",
    "ClusterConfigStatusHistory"
)

table = dynamodb.Table(TABLE_NAME)


def lambda_handler(event, context):
    try:
        # --------------------------------
        # GET param: ?email=
        # --------------------------------
        email, error = get_email_from_event(event)
        print(f"email id : {email}")

        if error:
            return error
        # query_params = event.get("queryStringParameters") or {}
        # email = query_params.get("email")

        if not email:
            return {
                "statusCode": 400,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "error": "email query parameter is required"
                })
            }

        # --------------------------------
        # Query DynamoDB by email
        # --------------------------------
        response = table.query(
            KeyConditionExpression=Key("email").eq(email)
        )
        # print(" Responce  ==>  ", response)
        items = response.get("Items", [])

        # if not items:
        #     return {
        #         "statusCode": 404,
        #         "headers": {"Access-Control-Allow-Origin": "*"},
        #         "body": json.dumps({
        #             "error": "No records found for this email"
        #         })
        #     }

        # --------------------------------
        # Format response (Decimal FIX)
        # --------------------------------
        records = []
        for item in items:
            # print(item)
            records.append({
                "plan_start_date": item.get("plan_start_date"),
                "expires_at": int(item["expires_at"])
                if isinstance(item.get("expires_at"), Decimal)
                else item.get("expires_at"),
                "instance_ids": item.get("instance_ids", []),
                "status": item.get("status", "Undefined"),
                "triggered_at" : item.get("triggered_at", "Undefined")
            })

        return {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "email": email,
                "count": len(records),
                "records": records
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "error": "Internal server error",
                "message": str(e)
            })
        }
