import boto3
from decimal import Decimal

# DynamoDB setup
dynamodb = boto3.resource('dynamodb')
wallet_table = dynamodb.Table('user_wallet_creditbased')

def check_user_exists(email_id):
    """
    Checks if a user exists and returns a tuple:
    (exists: bool, current_balance: Decimal or 0)
    """
    response = wallet_table.get_item(
        Key={'email_id': email_id},
        ProjectionExpression='email_id, current_balance'
    )
    
    if 'Item' in response:
        current_balance = response['Item'].get('current_balance', Decimal('0'))
        return True, current_balance
    else:
        return False, Decimal('0')