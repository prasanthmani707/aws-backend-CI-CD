import boto3
from decimal import Decimal

# Initialize SES client
ses = boto3.client('ses', region_name='us-east-1')

def send_wallet_credit_email(email_id, amount_inr, existing_balance):
    """
    Send wallet credit email including previous balance, added amount, and new balance.
    
    Parameters:
    - email_id: str
    - amount_inr: Decimal or float
    - existing_balance: Decimal or float
    """
    # Extract username from email
    user_name = email_id.split('@')[0].replace('.', ' ').title()  # e.g., john.doe -> John Doe

    # Calculate new balance
    new_balance = Decimal(existing_balance) + Decimal(amount_inr)

    # Email body
    email_body = f"""Hi {user_name},

We are pleased to inform you that your wallet has been credited successfully.

Previous Balance: ₹{existing_balance}
Amount Added: ₹{amount_inr}
Total Balance: ₹{new_balance}

You can now use this credit in your SplunkLab environment.
If you have any questions or need assistance, please contact labsupport@softmania.in.

Thank you,
SoftMania Team
"""

    try:
        response = ses.send_email(
            Source="eng-team@softmania.in",
            Destination={'ToAddresses': [email_id]},
            Message={
                'Subject': {
                    'Data': 'SoftMania SplunkLab Wallet Credit Added',
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': email_body,
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        print("✅ Email sent successfully")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")