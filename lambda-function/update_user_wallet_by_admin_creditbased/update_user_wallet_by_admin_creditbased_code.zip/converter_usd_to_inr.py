import boto3
from decimal import Decimal
from botocore.exceptions import ClientError

# Initialize SSM client
ssm = boto3.client('ssm')
PARAMETER_NAME = "/exchange/inr_to_usd"  # USD per 1 INR

def convert_to_inr(existing_balance):
    """
    Convert the given amount (assume USD) to INR using the exchange rate from SSM.
    
    Parameters:
    - amount: Decimal, float, or int (in USD)
    
    Returns:
    - amount_inr: Decimal (rounded to 2 decimals)
    """
    try:
        # Fetch USD per 1 INR rate from SSM
        response = ssm.get_parameter(Name=PARAMETER_NAME)
        usd_per_inr = Decimal(response['Parameter']['Value'])
        
        # Convert USD → INR by dividing by USD per INR
        amount_usd = Decimal(str(existing_balance))
        amount_inr = amount_usd / usd_per_inr
        
        # Round to 2 decimals
        return round(amount_inr, 2)
    
    except ClientError as e:
        print("❌ Error fetching exchange rate from SSM:", e)
        raise e
    except Exception as e:
        print("❌ Unexpected error:", e)
        raise e

