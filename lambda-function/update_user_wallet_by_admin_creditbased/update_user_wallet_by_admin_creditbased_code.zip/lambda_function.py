import json
import boto3
from decimal import Decimal
from datetime import datetime
import uuid
from botocore.exceptions import ClientError

from check_user_exists import check_user_exists
from send_wallet_credit_email import send_wallet_credit_email
from welcome_email import send_welcome_email
from converter_inr_to_usd import convert_inr_to_usd
from admin_verify_email import admin_verify_email
from converter_usd_to_inr import convert_to_inr

# DynamoDB
dynamodb = boto3.resource('dynamodb')
wallet_table = dynamodb.Table('user_wallet_creditbased')

# Lambda client (Ledger)
lambda_client = boto3.client('lambda')
LEDGER_LAMBDA_NAME = "history_tracker_creditbased"


def lambda_handler(event, context):
    try:

        # 1️⃣ Parse request body
        body = event.get('body')

        if body is None:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Body is missing'})
            }

        if isinstance(body, str):
            body = json.loads(body)

        email_id = body.get('email_id')
        amount_inr = body.get('amount')
        admin_email = body.get('admin_email')
        txn_type = body.get('type', '').upper()

        if email_id:
            email_id = email_id.lower()

        print("Email:", email_id)
        print("Amount INR:", amount_inr)

        # 2️⃣ Validation
        if not all([email_id, amount_inr, txn_type]):
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Missing required fields'})
            }

        if txn_type != 'PAY':
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Only PAY transactions allowed'})
            }

        amount_inr = Decimal(str(amount_inr))

        if amount_inr <= 0:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Amount must be positive'})
            }

        # Convert INR → USD
        amount = convert_inr_to_usd(amount_inr)
        amount = Decimal(str(amount))

        updated_time = datetime.utcnow().isoformat()

        # 3️⃣ Check user
        is_existing_user, existing_balance = check_user_exists(email_id)


        # 4️⃣ Update Wallet
        response = wallet_table.update_item(
            Key={'email_id': email_id},
            UpdateExpression="""
                SET previous_balance = if_not_exists(current_balance, :zero),
                    current_balance = if_not_exists(current_balance, :zero) + :amount,
                    last_transaction_amount = :amount,
                    cb_last_updated = :now
            """,
            ExpressionAttributeValues={
                ':amount': amount,
                ':zero': Decimal('0'),
                ':now': updated_time
            },
            ReturnValues="UPDATED_NEW"
        )

        # Safe Attributes handling
        attributes = response.get("Attributes") or {}

        prev_balance = attributes.get("previous_balance", Decimal("0"))
        curr_balance = attributes.get("current_balance", Decimal("0"))

        print(f"✅ Wallet updated for {email_id}: {prev_balance} → {curr_balance}")

        # 5️⃣ Send Emails
        existing_balance = convert_to_inr(existing_balance)
        print(f"${existing_balance} = ₹{existing_balance}")
        if not is_existing_user:
            send_welcome_email(email_id, amount_inr)
        else:
            send_wallet_credit_email(email_id, amount_inr,existing_balance)
        
        admin_verify_email(email_id ,amount_inr, admin_email,existing_balance)

        # 6️⃣ Ledger Record
        ledger_record = {
            "tnx_id": str(uuid.uuid4()),
            "email_id": email_id,
            "amount": float(amount),
            "balance_before": float(prev_balance),
            "balance_after": float(curr_balance),
            "source": "PAY",
            "status": "SUCCESS",
            "updated_time": updated_time
        }

        # 7️⃣ Invoke Ledger Lambda
        try:

            payload = {"records": [ledger_record]}

            print("🚀 Invoking Ledger Lambda")
            print(json.dumps(payload, indent=2))

            invoke_response = lambda_client.invoke(
                FunctionName=LEDGER_LAMBDA_NAME,
                InvocationType='Event',
                Payload=json.dumps(payload).encode('utf-8')
            )

            if invoke_response['StatusCode'] != 202:
                print("⚠️ Unexpected Status:", invoke_response['StatusCode'])
            else:
                print("✅ Ledger update triggered")

        except ClientError as e:
            print("❌ Ledger Lambda Error:", e)

        # 8️⃣ Success Response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'PAY successful',
                'credited_amount': float(amount),
                'balance_before': float(prev_balance),
                'balance_after': float(curr_balance),
                'updated_time': updated_time
            })
        }

    except ClientError as e:
        print("AWS ClientError:", e)

        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'AWS Error'})
        }

    except Exception as e:
        print("Internal Error:", e)

        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal Server Error'})
        }