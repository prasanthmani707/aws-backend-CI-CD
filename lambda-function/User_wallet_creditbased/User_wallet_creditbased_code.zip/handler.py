import json
import boto3
from decimal import Decimal
from datetime import datetime
import uuid
import urllib.request
from botocore.exceptions import ClientError
from check_user_exists import check_user_exists
from send_wallet_credit_email import send_wallet_credit_email
from welcome_email import send_welcome_email
from converter_inr_to_usd import convert_inr_to_usd
from payment_verification import payment_verification
# DynamoDB table
dynamodb = boto3.resource('dynamodb')
wallet_table = dynamodb.Table('user_wallet_creditbased')

# Lambda client (to send record to Ledger)
lambda_client = boto3.client('lambda')
LEDGER_LAMBDA_NAME = "history_tracker_creditbased"  # 👈 Your ledger Lambda name



def lambda_handler(event, context):
    try:
        # 1️⃣ Parse request body
        body = event.get('body')
        if isinstance(body, str):
            body = json.loads(body)

        email_id = body.get('email_id').lower()
        order_id = body.get('order_id')
        payment_id = body.get('payment_id')
        print(f"{payment_id}")
        print(f"{order_id}")
        # amount_inr = body.get('amount')
        txn_type = body.get('type', '').upper()

        verified, razorpay_amount = payment_verification(order_id, payment_id)
        if not verified:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Payment verification failed'})
            }
        amount_inr = Decimal(str(razorpay_amount))
        print(f"{amount_inr}")
        amount = convert_inr_to_usd(amount_inr)

        # 2️⃣ Validation
        if not all([email_id, amount, txn_type]):
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Missing fields'})
            }

        if txn_type != 'PAY':
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Only PAY transactions allowed'})
            }
        amount = Decimal(str(amount))
        if amount <= 0:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Amount must be positive'})
            }
        updated_time = datetime.utcnow().isoformat() 
        # 3️⃣ Update wallet
        is_existing_user = check_user_exists(email_id)

        response = wallet_table.update_item(
            Key={'email_id': email_id},
            UpdateExpression="""
                SET previous_balance = if_not_exists(current_balance, :zero),
                    current_balance = if_not_exists(current_balance, :zero) + :amount,
                    last_transaction_amount = :amount,
                    cb_last_updated = :now
            """,
            ExpressionAttributeValues={
                ':amount': amount,
                ':zero': Decimal('0'),
                ':now': updated_time
            },
            ReturnValues="UPDATED_NEW"
        )
        if not is_existing_user:
            send_welcome_email(email_id,amount_inr)
        else:
            send_wallet_credit_email(email_id, amount_inr)

        prev_balance = response["Attributes"].get("previous_balance", Decimal("0"))
        curr_balance = response["Attributes"].get("current_balance", Decimal("0"))

        print(f"✅ Wallet updated for {email_id}: {prev_balance} → {curr_balance}")

        # 4️⃣ Prepare ledger record
        ledger_record = {
            "tnx_id": str(uuid.uuid4()),
            "email_id": email_id,
            "amount": float(amount),
            "balance_before": float(prev_balance),
            "balance_after": float(curr_balance),
            "source": "PAY",
            "status": "SUCCESS",
            "updated_time": updated_time,  # ✅ added here
        }

        # 5️⃣ Invoke ledger Lambda async with logging
        try:
            payload = {"records": [ledger_record]}
            print(f"🚀 Invoking ledger Lambda '{LEDGER_LAMBDA_NAME}' with payload:")
            print(json.dumps(payload, indent=2))

            response = lambda_client.invoke(
                FunctionName=LEDGER_LAMBDA_NAME,
                InvocationType='Event',  # async
                Payload=json.dumps(payload).encode('utf-8')
            )
            if response['StatusCode'] != 202:
                print("⚠️ Unexpected status code from Lambda invoke:", response['StatusCode'])
            else:
                print("✅ Ledger update initiated successfully")

        except ClientError as e:
            print("❌ Failed to invoke ledger Lambda:", e)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'PAY successful',
                'credited_amount': float(amount),
                'balance_before': float(prev_balance),
                'balance_after': float(curr_balance),
                'updated_time': updated_time  # ✅ include in response
            })
        }

    except ClientError as e:
        print("AWS ClientError:", e)
        return {'statusCode': 500, 'body': json.dumps({'message': 'AWS Error'})}

    except Exception as e:
        print("Internal Error:", e)
        return {'statusCode': 500, 'body': json.dumps({'message': 'Internal Server Error'})}
