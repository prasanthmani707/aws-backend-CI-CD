import base64
import json
import urllib.request
import os

def payment_verification(order_id, payment_id):

    key_id = os.environ["RAZORPAY_KEY_ID"]
    key_secret = os.environ["RAZORPAY_KEY_SECRET"]

    url = f"https://api.razorpay.com/v1/payments/{payment_id}"

    credentials = f"{key_id}:{key_secret}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()

    headers = {
        "Authorization": f"Basic {encoded_credentials}"
    }

    request = urllib.request.Request(url, headers=headers)

    with urllib.request.urlopen(request) as response:
        payment = json.loads(response.read().decode())

    if payment["status"] == "captured" and payment["order_id"] == order_id:

        amount_paise = payment["amount"]     # amount in paise
        amount_inr = amount_paise / 100      # convert to rupees

        print(f"Payment verified successfully. Amount paid: ₹{amount_inr}")

        return True, amount_inr

    return False, 