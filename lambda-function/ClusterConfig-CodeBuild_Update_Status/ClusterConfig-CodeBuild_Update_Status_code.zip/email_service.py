
from typing import Any, Dict, List, Optional


# =========================================================
# EMAIL
# =========================================================
def get_user_name(email: str) -> str:
    return email.split("@")[0].replace(".", " ").replace("_", " ").title()


def format_failure_logs(failure_logs: List[Dict[str, Any]]) -> str:
    if not failure_logs:
        return "The build failed, but no matching failure log was found."

    formatted_logs = []

    for index, log in enumerate(failure_logs, start=1):
        matched_keywords = ", ".join(log.get("matched_keywords", []))
        message = log.get("message", "")

        if matched_keywords:
            formatted_logs.append(f"{index}. [{matched_keywords}] {message}")
        else:
            formatted_logs.append(f"{index}. {message}")

    return "\n".join(formatted_logs)


def build_email_body(
    email: str,
    final_status: str,
    build_id: str,
    log_stream_name: str,
    platform_url: str,
    support_email: str,
    failure_logs: List[Dict[str, Any]],
    command_execution_error: Dict[str, Any],
) -> str:
    user_name = get_user_name(email)

    body = f"""Hi {user_name},

Your SoftMania SplunkLab environment request has been updated.

Account Email: {email}

You can create and manage your environment using the platform below:
{platform_url}

You will receive automated alerts based on usage. Stay informed and plan accordingly.
"""

    if final_status == "FAILED":
        
        body += """\n 
        Build ID: {build_id}
        Log Stream: {log_stream_name}
        Current Status: {final_status}
        \nBuild Failure Details:\n
        """

        body += f"```\n{format_failure_logs(failure_logs)}\n```\n"
    else:
        body += "\n configuration Successfully Completed 👌:\n"
    body += f"""
If you experience any issues or need assistance, please contact our support team.
Support: {support_email}

Best regards,
SoftMania Team
"""

    return body


def send_status_email(
    ses_client: Any,
    sender_email: str,
    platform_url: str,
    support_email: str,
    email: str,
    final_status: str,
    build_id: str,
    log_stream_name: str,
    failure_logs: List[Dict[str, Any]],
    command_execution_error: Dict[str, Any],
) -> Dict[str, Any]:
    subject = f"SoftMania SplunkLab Build Status: {final_status}"

    response = ses_client.send_email(
        Source=sender_email,
        Destination={
            "ToAddresses": [email],
        },
        Message={
            "Subject": {
                "Data": subject,
                "Charset": "UTF-8",
            },
            "Body": {
                "Text": {
                    "Data": build_email_body(
                        email=email,
                        final_status=final_status,
                        build_id=build_id,
                        log_stream_name=log_stream_name,
                        platform_url=platform_url,
                        support_email=support_email,
                        failure_logs=failure_logs,
                        command_execution_error=command_execution_error,
                    ),
                    "Charset": "UTF-8",
                },
            },
        },
    )

    print(f"[EMAIL] Sent status email to {email}")
    return response
