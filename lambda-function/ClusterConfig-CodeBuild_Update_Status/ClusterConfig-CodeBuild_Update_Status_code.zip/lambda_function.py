import os
from typing import Any, Dict

import boto3
from cloudwatch_log_extraction import (
    extract_command_execution_error,
    fetch_failure_logs,
)
from dynamodb import find_email_for_build, update_build_status
from email_service import send_status_email
from event_parsing import get_build_id, get_final_status, get_log_stream_name
from utils import log_json

# =========================================================
# CONFIGURATION
# =========================================================
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

TABLE_NAME = os.environ.get(
    "CLUSTER_RETENTION_TABLE",
    "ClusterConfigStatusHistory",
)

BUILD_ID_INDEX = os.environ.get(
    "BUILD_ID_INDEX",
    "build_id-index",
)

LOG_GROUP_NAME = os.environ.get(
    "CODEBUILD_LOG_GROUP",
    "/aws/codebuild/Cluster-Configuration",
)

SENDER_EMAIL = os.environ.get(
    "SENDER_EMAIL",
    "eng-team@softmania.in",
)

PLATFORM_URL = os.environ.get(
    "PLATFORM_URL",
    "https://splunklab.softmania.in/",
)

SUPPORT_EMAIL = os.environ.get(
    "SUPPORT_EMAIL",
    "labsupport@softmania.in",
)

SEND_EMAIL = os.environ.get("SEND_EMAIL", "true").lower() == "true"
FAILURE_LOG_MAX_PAGES = int(os.environ.get("FAILURE_LOG_MAX_PAGES", "3"))

FAILURE_KEYWORDS = [
    "ERROR!",
    "COMMAND_EXECUTION_ERROR",
    "exit status",
    "fatal:",
    "FAILED! =>",
    "Traceback",
    "unexpected parameter type",
    "non-zero return code",
    "Command did not exit successfully",
    "Phase complete: BUILD State: FAILED",
]

IGNORE_PATTERNS = [
    "cache archive is empty",
    "Phase context status code:  Message:",
]

STATUS_MAP = {
    "SUCCEEDED": "COMPLETED",
    "FAILED": "FAILED",
}


# =========================================================
# AWS CLIENTS
# =========================================================
dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
table = dynamodb.Table(TABLE_NAME)

logs_client = boto3.client("logs", region_name=AWS_REGION)
ses_client = boto3.client("ses", region_name=AWS_REGION)


# =========================================================
# LAMBDA HANDLER
# =========================================================
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    print("=== LAMBDA START ===")
    log_json("EVENT", event)

    try:
        detail = event.get("detail", {})
        build_status = detail.get("build-status")
        build_id_full = detail.get("build-id")

        print(detail)
        
        if not build_id_full:
            return {
                "status": "error",
                "reason": "missing_build_id",
            }

        build_id = get_build_id(build_id_full)
        log_stream_name = get_log_stream_name(build_id)
        final_status = get_final_status(build_status, STATUS_MAP)

        email = detail.get("email") or find_email_for_build(
            table=table,
            build_id_index=BUILD_ID_INDEX,
            build_id=build_id,
        )
        
        print(f"[DYNAMODB] Searching email for build_id: {build_id}")
        print(f"[DYNAMODB] Found email: {email} for build_id: {build_id}")
        
        
        if not email:
            return {
                "status": "not_found",
                "reason": "email_not_found",
                "build_id": build_id,
            }


        failure_logs = []
        command_execution_error = {}

        if final_status == "FAILED":
            failure_logs = fetch_failure_logs(
                logs_client=logs_client,
                log_group_name=LOG_GROUP_NAME,
                log_stream_name=log_stream_name,
                failure_keywords=FAILURE_KEYWORDS,
                ignore_patterns=IGNORE_PATTERNS,
                max_pages=FAILURE_LOG_MAX_PAGES,
            )
            command_execution_error = extract_command_execution_error(failure_logs)
            log_json("FAILURE_LOGS", failure_logs)
            log_json("COMMAND_EXECUTION_ERROR", command_execution_error)
        else:
            print("[LOGS] Skipped failure log extraction for non-failed build")

        update_response = update_build_status(
            table=table,
            email=email,
            build_id=build_id,
            final_status=final_status,
        )

        log_json("DYNAMODB_UPDATE", update_response)

        email_message_id = None

        if SEND_EMAIL:
            try:
                email_response = send_status_email(
                    ses_client=ses_client,
                    sender_email=SENDER_EMAIL,
                    platform_url=PLATFORM_URL,
                    support_email=SUPPORT_EMAIL,
                    email=email,
                    final_status=final_status,
                    build_id=build_id,
                    log_stream_name=log_stream_name,
                    failure_logs=failure_logs,
                    command_execution_error=command_execution_error,
                )
                email_message_id = email_response.get("MessageId")
            except Exception as email_error:
                print("[EMAIL ERROR]", str(email_error))
        else:
            print("[EMAIL] Skipped because SEND_EMAIL is false")

        print("=== LAMBDA END SUCCESS ===")

        return {
            "status": "updated",
            "email": email,
            "build_id": build_id,
            "log_stream_name": log_stream_name,
            "final_status": final_status,
            "failure_log_count": len(failure_logs),
            "command_execution_error": command_execution_error,
            "failure_logs": failure_logs,
            "email_message_id": email_message_id,
        }

    except Exception as exc:
        print("[ERROR]", str(exc))
        print("=== LAMBDA END FAILURE ===")

        return {
            "status": "error",
            "message": str(exc),
        }
