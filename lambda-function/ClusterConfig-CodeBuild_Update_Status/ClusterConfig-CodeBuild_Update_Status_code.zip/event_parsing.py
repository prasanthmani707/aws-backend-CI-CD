
from typing import Dict, Optional


# =========================================================
# EVENT PARSING
# =========================================================
def get_build_id(build_id_full: str) -> str:
    return build_id_full.split("/")[-1]


def get_log_stream_name(build_id: str) -> str:
    return build_id.split(":")[-1]


def get_final_status(build_status: Optional[str], status_map: Dict[str, str]) -> str:
    return status_map.get(build_status or "", "UNKNOWN")
