import json
from decimal import Decimal
from typing import Any


# =========================================================
# JSON HELPERS
# =========================================================
def json_default(value: Any) -> Any:
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)

    return str(value)


def log_json(label: str, payload: Any) -> None:
    print(f"[{label}]")
    print(json.dumps(payload, indent=2, default=json_default))
