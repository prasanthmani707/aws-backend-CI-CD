
from typing import Any, Dict, Optional

from boto3.dynamodb.conditions import Key


# =========================================================
# DYNAMODB
# =========================================================
def find_email_for_build(
    table: Any,
    build_id_index: str,
    build_id: str,
) -> Optional[str]:
    response = table.query(
        IndexName=build_id_index,
        KeyConditionExpression=Key("build_id").eq(build_id),
        Limit=1,
    )

    items = response.get("Items", [])

    if not items:
        return None

    return items[0].get("email")


def update_build_status(
    table: Any,
    email: str,
    build_id: str,
    final_status: str,
) -> Dict[str, Any]:
    return table.update_item(
        Key={
            "email": email,
            "build_id": build_id,
        },
        UpdateExpression="SET #status = :status",
        ExpressionAttributeNames={
            "#status": "status",
        },
        ExpressionAttributeValues={
            ":status": final_status,
        },
        ReturnValues="UPDATED_NEW",
    )
