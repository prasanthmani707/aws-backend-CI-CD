
from typing import Any, Dict, List


# =========================================================
# CLOUDWATCH LOG EXTRACTION
# =========================================================
def add_log_item(
    failure_logs: List[Dict[str, Any]],
    seen_messages: set,
    timestamp: Any,
    message: str,
    matched_keywords: List[str],
) -> None:
    item_key = f"{timestamp}:{message}"

    if item_key in seen_messages:
        return

    seen_messages.add(item_key)
    failure_logs.append(
        {
            "timestamp": timestamp,
            "message": message,
            "matched_keywords": matched_keywords,
        }
    )


def should_ignore_log(message: str, ignore_patterns: List[str]) -> bool:
    return any(pattern.lower() in message.lower() for pattern in ignore_patterns)


def get_matched_failure_keywords(
    message: str,
    failure_keywords: List[str],
) -> List[str]:
    return [
        keyword
        for keyword in failure_keywords
        if keyword.lower() in message.lower()
    ]


def should_capture_error_context(message: str) -> bool:
    context_markers = [
        "The error appears to be in",
        "The offending line appears to be",
        "line ",
        "column ",
        "^ here",
        "- name:",
    ]

    return any(marker.lower() in message.lower() for marker in context_markers)


def should_start_error_context(matched_keywords: List[str]) -> bool:
    context_keywords = [
        "ERROR!",
        "Traceback",
        "unexpected parameter type",
    ]

    return any(keyword in matched_keywords for keyword in context_keywords)


def fetch_failure_logs(
    logs_client: Any,
    log_group_name: str,
    log_stream_name: str,
    failure_keywords: List[str],
    ignore_patterns: List[str],
    max_pages: int,
) -> List[Dict[str, Any]]:
    failure_logs = []
    seen_messages = set()
    next_token = None
    context_remaining = 0
    context_lines_after_match = 8

    print(f"[LOGS] Fetching failure logs from stream: {log_stream_name}")

    for page_number in range(1, max_pages + 1):
        request = {
            "logGroupName": log_group_name,
            "logStreamName": log_stream_name,
            "startFromHead": True,
        }

        if next_token:
            request["nextToken"] = next_token

        response = logs_client.get_log_events(**request)
        events = response.get("events", [])

        print(f"[LOGS] Page {page_number}: {len(events)} events")

        for event in events:
            message = event.get("message", "").strip()
            timestamp = event.get("timestamp")

            if not message or should_ignore_log(message, ignore_patterns):
                continue

            matched_keywords = get_matched_failure_keywords(
                message,
                failure_keywords,
            )

            if not matched_keywords:
                if context_remaining > 0 and should_capture_error_context(message):
                    add_log_item(
                        failure_logs=failure_logs,
                        seen_messages=seen_messages,
                        timestamp=timestamp,
                        message=message,
                        matched_keywords=["ERROR_CONTEXT"],
                    )

                if context_remaining > 0:
                    context_remaining -= 1

                continue

            add_log_item(
                failure_logs=failure_logs,
                seen_messages=seen_messages,
                timestamp=timestamp,
                message=message,
                matched_keywords=matched_keywords,
            )

            if should_start_error_context(matched_keywords):
                context_remaining = context_lines_after_match

        new_token = response.get("nextForwardToken")

        if new_token == next_token:
            break

        next_token = new_token

    print(f"[LOGS] Failure log count: {len(failure_logs)}")
    return failure_logs


def extract_command_execution_error(
    failure_logs: List[Dict[str, Any]],
) -> Dict[str, Any]:
    for log in failure_logs:
        if "COMMAND_EXECUTION_ERROR" in log.get("message", ""):
            return log

    return {}

