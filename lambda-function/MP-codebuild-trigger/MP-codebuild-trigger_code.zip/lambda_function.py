import os
import boto3
import datetime
import random
import json
import re
import logging
import botocore

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def log_event(message, **kwargs):
    event = {"message": message, **kwargs}
    logger.info(json.dumps(event))

REGION = os.environ["AWS_REGION"]  # ✅ Lambda automatically sets this

s3 = boto3.client('s3', region_name=REGION)
ec2 = boto3.client('ec2', region_name=REGION)
codebuild = boto3.client('codebuild', region_name=REGION)

BUCKET = "splunklab-dev"

# ---------------- EC2 / S3 Key Functions ----------------
def check_ec2_key_exists(key_name, region=REGION):
    try:
        ec2.describe_key_pairs(KeyNames=[key_name])
        return True
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'InvalidKeyPair.NotFound':
            return False
        else:
            raise e

def check_s3_key_exists(usermail, key_name):
    try:
        key_path = f"clients/{usermail}/keys/{key_name}.pem"
        s3.head_object(Bucket=BUCKET, Key=key_path)
        return True
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == '404':
            return False
        else:
            raise e

def create_ec2_key_and_upload(usermail, base_name):
    clean_name = re.sub(r'[^a-zA-Z0-9\-]', '-', base_name)
    final_name = clean_name
    suffix = 1

    existing_keys = s3.list_objects_v2(
        Bucket=BUCKET,
        Prefix=f"clients/{usermail}/keys/{clean_name}"
    )

    if 'Contents' in existing_keys and existing_keys['KeyCount'] > 0:
        print(f"🔐 Existing PEM key already found in S3 for user {usermail}. Skipping new key creation.")
        return clean_name

    while check_ec2_key_exists(final_name) or check_s3_key_exists(usermail, final_name):
        final_name = f"{clean_name}-{suffix}"
        suffix += 1

    try:
        response = ec2.create_key_pair(KeyName=final_name)
        private_key = response['KeyMaterial']
        key_path = f"clients/{usermail}/keys/{final_name}.pem"
        s3.put_object(Bucket=BUCKET, Key=key_path, Body=private_key.encode(), ACL='private')
        print(f"✅ Created EC2 KeyPair and uploaded to S3: {key_path}")
    except Exception as e:
        print(f"❌ Failed to create EC2 key pair: {str(e)}")
        raise e

    return final_name

# ---------------- CodeBuild Template Map ----------------
TEMPLATE_PROJECT_MAP = {
    "linux.template": "MP-linux-trigger",
    "win-splunk.template": "MP-Win-Splunk-trigger",
    "Splunk-DNC-1000.template": "Splunk-DNC-EC2Only",
    "openvpn-200.template": "OpenVPN-trigger",
    "windows-400.template": "Windows-trigger",
    "syslog-200.template": "Syslog-trigger",
    "linux-200.template": "Linux-trigger"
}

# ---------------- Lambda Handler ----------------
def lambda_handler(event, context):
    # Support both API Gateway and direct Lambda test invocation
    if not event:
        return {"statusCode": 400, "body": json.dumps({"error": "Request body is missing"})}

    body = event.get("body") if isinstance(event, dict) else None
    if body is None:
        body = event  # maybe already JSON object

    if isinstance(body, str):
        try:
            body = json.loads(body)
        except json.JSONDecodeError:
            return {"statusCode": 400, "body": json.dumps({"error": "Request body is not valid JSON"})}

    # ✅ Mandatory fields
    required_fields = ["usermail", "username", "template_file"]
    missing_fields = [field for field in required_fields if not body.get(field)]
    if missing_fields:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": f"Missing required fields: {', '.join(missing_fields)}"})
        }

    usermail = body.get("usermail", "").strip().lower()
    username = body.get("username", "").strip()
    price = body.get("price")          # optional
    course_id = body.get("course_id")  # optional
    module_id = body.get("module_id")  # optional
    topic_id = body.get("topic_id")    # optional
    quotahours = str(body.get("quotahours", "2"))

    # ✅ Ensure EC2 key exists
    create_ec2_key_and_upload(usermail, username)

    # Handle single or multiple template files
    template_files = body.get("template_file")
    if isinstance(template_files, str):
        template_files = [template_files]

    results = []

    for template_file in template_files:
        # Fetch template from S3
        s3_key = f"mp-templates/{template_file}"
        obj = s3.get_object(Bucket=BUCKET, Key=s3_key)
        template_content = obj['Body'].read().decode()

        # Mandatory placeholders
        template_content = template_content.replace("{username}", username)
        template_content = template_content.replace("{usermail}", usermail)
        template_content = template_content.replace("{quotahours}", quotahours)
        template_content = template_content.replace("{current_time}",
                                                    datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z")

        # Optional placeholders: remove lines if not provided
        optional_fields = {
            "price": price,
            "course_id": course_id,
            "module_id": module_id,
            "topic_id": topic_id
        }

        for key, value in optional_fields.items():
            if value:
                template_content = template_content.replace(f"{{{key}}}", value)
            else:
                template_content = "\n".join(
                    [line for line in template_content.splitlines() if f"{{{key}}}" not in line]
                )

        # Save tfvars to S3
        suffix = random.randint(100, 999)
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
        final_key = f"final/terraform-{timestamp}-{suffix}-{template_file.replace('.template','.tfvars')}.tfvars"
        s3.put_object(Bucket=BUCKET, Key=final_key, Body=template_content.encode())

        # Trigger CodeBuild
        project_name = TEMPLATE_PROJECT_MAP.get(template_file)
        if not project_name:
            results.append({
                "template_file": template_file,
                "error": "No CodeBuild project mapped"
            })
            continue

        codebuild.start_build(
            projectName=project_name,
            environmentVariablesOverride=[
                {"name": "TFVARS_S3_KEY", "value": final_key, "type": "PLAINTEXT"},
                {"name": "USER_EMAIL", "value": usermail, "type": "PLAINTEXT"},
                {"name": "USERNAME", "value": username, "type": "PLAINTEXT"},
                {"name": "COURSE_ID", "value": course_id or "", "type": "PLAINTEXT"},
                {"name": "MODULE_ID", "value": module_id or "", "type": "PLAINTEXT"},
                {"name": "TOPIC_ID", "value": topic_id or "", "type": "PLAINTEXT"},
                {"name": "PRICE", "value": price or "", "type": "PLAINTEXT"}
            ]
        )

        results.append({
            "template_file": template_file,
            "tfvars": final_key,
            "project": project_name
        })

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Lab(s) triggered successfully",
            "results": results
        })
    }
