import boto3
import datetime
import json
import os

STOP_EC2_LAMBDA_ARN = os.environ.get('STOP_EC2_LAMBDA_ARN')
SCHEDULER_ROLE_ARN = os.environ.get('SCHEDULER_ROLE_ARN')

# 🔥 Centralized Control: Schedule Offset in Hours
SCHEDULE_OFFSET_HOURS = int(os.environ.get("SCHEDULE_OFFSET_HOURS", "2"))


def lambda_handler(event, context):
    print(f"📩 Received event: {json.dumps(event)}")

    try:
        # ---------------------------------------------
        # 1️⃣ Extract instance_id & region
        # ---------------------------------------------
        instance_id = event['detail']['instance-id']
        region = event['region']

        print(f"🔄 Scheduling stop for instance {instance_id} in region {region}")

        ec2 = boto3.client('ec2', region_name=region)

        # ---------------------------------------------
        # 2️⃣ (Optional safety) Validate instance exists
        # ---------------------------------------------
        ec2.describe_instances(InstanceIds=[instance_id])

        # ---------------------------------------------
        # 3️⃣ Calculate stop time (UTC)
        # ---------------------------------------------
        stop_time = datetime.datetime.utcnow() + datetime.timedelta(
            hours=SCHEDULE_OFFSET_HOURS
        )

        cron_expression = (
            f"cron({stop_time.minute} "
            f"{stop_time.hour} "
            f"{stop_time.day} "
            f"{stop_time.month} "
            f"? {stop_time.year})"
        )

        print(f"🕒 Stop time (UTC): {stop_time}")
        print(f"📅 Cron expression: {cron_expression}")

        rule_name = f"Stop-{instance_id}-{int(datetime.datetime.utcnow().timestamp())}"

        scheduler = boto3.client('scheduler', region_name=region)

        # ---------------------------------------------
        # 4️⃣ CREATE SCHEDULE (DIRECT – NO TAG CHECK)
        # ---------------------------------------------
        scheduler.create_schedule(
            Name=rule_name,
            ScheduleExpression=cron_expression,
            FlexibleTimeWindow={'Mode': 'OFF'},
            Target={
                'Arn': STOP_EC2_LAMBDA_ARN,
                'RoleArn': SCHEDULER_ROLE_ARN,
                'Input': json.dumps({
                    "instance_id": instance_id,
                    "region": region
                })
            },
            Description=(
                f"Direct auto-stop EC2 {instance_id} "
                f"in {region} after {SCHEDULE_OFFSET_HOURS} hours"
            )
        )

        print(f"✔ Stop schedule created successfully: {rule_name}")

        return {
            "statusCode": 200,
            "body": json.dumps(
                f"Stop scheduled for instance {instance_id} in region {region}"
            )
        }

    except Exception as e:
        print(f"❌ Error occurred: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps(f"Error: {str(e)}")
        }
