import json, boto3
from datetime import datetime, timedelta, timezone
from collections import defaultdict
from boto3.dynamodb.conditions import Attr

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ManageEC2Instances')

# IST offset
IST_OFFSET = timedelta(hours=5, minutes=30)
IST = timezone(IST_OFFSET)

def hhmm(hours_f):
    h, m = divmod(round(hours_f * 60), 60)
    return f"{int(h):02d}:{int(m):02d}"

def lambda_handler(event, _):
    print("[DEBUG] Event received:", event)  # Debug: incoming event
    body = json.loads(event.get("body", "{}"))
    email = body.get("email")
    svc_filter = body.get("serviceTypes")

    print(f"[DEBUG] Email: {email}, Service filter: {svc_filter}")

    if not email:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing email"})
        }

    # Normalize service filter
    if svc_filter is None:
        wanted = set()
    elif isinstance(svc_filter, str):
        wanted = {svc_filter}
    else:
        wanted = set(svc_filter)

    print(f"[DEBUG] Scanning DynamoDB for {email}...")
    # Scan items that begin with email#
    scan_resp = table.scan(
        FilterExpression=Attr("UserEmail").begins_with(f"{email}#")
    )
    items = scan_resp.get("Items", [])
    print(f"[DEBUG] Found {len(items)} items in DynamoDB.")

    if not items:
        return {
            "statusCode": 404,
            "body": json.dumps({"error": "No usage data"})
        }

    grouped = defaultdict(list)
    for item in items:
        full_key = item.get("UserEmail", "")
        if "#" in full_key:
            base_email, service_type = full_key.split("#", 1)
        else:
            service_type = "Unknown"

        if wanted and service_type not in wanted:
            continue

        grouped[service_type].append(item)

    if not grouped:
        return {
            "statusCode": 404,
            "body": json.dumps({"error": "Requested service not found"})
        }

    now = datetime.now(timezone.utc)
    summaries = []

    for service, rows in grouped.items():
        print(f"[DEBUG] Processing service: {service}")
        quota_h = used_h = 0.0
        earliest_start = None
        hours_per_day = float(rows[0].get("HoursPerDay", 2))
        plan_start_raw = rows[0].get("PlanStartDate")

        instance_ids = []
        for r in rows:
            quota_h += float(r.get("RunQuotaHours", 0))
            used_h += float(r.get("TotalHoursUsed", 0))

            if r.get("InstanceIds"):
                for inst in r["InstanceIds"]:
                    if inst not in instance_ids:
                        instance_ids.append(inst)

            if r.get("IsRunning") and r.get("LastStartTime"):
                try:
                    ts = datetime.fromisoformat(r["LastStartTime"].replace("Z", "+00:00"))
                    if earliest_start is None or ts < earliest_start:
                        earliest_start = ts
                except Exception:
                    pass

        if earliest_start:
            used_h += (now - earliest_start).total_seconds() / 3600

        quota_days = quota_h / hours_per_day
        consumed_days = used_h / hours_per_day
        balance_h = max(0, quota_h - used_h)
        balance_days = max(0, quota_days - consumed_days)

        utc_start = datetime.fromisoformat(plan_start_raw.replace("Z", "+00:00"))
        ist_end = (utc_start + timedelta(days=quota_days)).astimezone(IST)

        # ✅ Adjust BalanceDays using PlanEndDate and current IST date
        today_ist = now.astimezone(IST).date()
        end_ist_date = ist_end.date()
        balance_days_by_date = (end_ist_date - today_ist).days
        balance_days = max(0, (end_ist_date - today_ist).days)

        summaries.append({
            "ServiceType": service,
            "UserEmail": email,
            "QuotaHours": round(quota_h, 2),
            "QuotaHoursFormatted": hhmm(quota_h),
            "ConsumedHours": round(used_h, 2),
            "ConsumedHoursFormatted": hhmm(used_h),
            "BalanceHours": round(balance_h, 2),
            "BalanceHoursFormatted": hhmm(balance_h),
            "QuotaExpiryDays": round(quota_days, 2),
            "ConsumedDays": round(consumed_days, 2),
            "BalanceDays": balance_days,
            "PlanStartDate": utc_start.astimezone(IST).strftime("%Y-%m-%d %I:%M %p (IST)"),
            "PlanEndDate": ist_end.strftime("%Y-%m-%d %I:%M %p (IST)"),
            "InstanceIds": instance_ids
        })

    print("[DEBUG] Usage summary prepared.")
    return {
        "statusCode": 200,
        "body": json.dumps({"UsageSummary": summaries})
    }
