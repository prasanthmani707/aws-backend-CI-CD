import boto3
import json

events = boto3.client('events')
lambda_client = boto3.client('lambda')

RULE_NAME = "CodeBuildStatusRule"


def create_eventbridge_rule(project_name: str, lambda_arn: str):
    event_pattern = {
        "source": ["aws.codebuild"],
        "detail-type": ["CodeBuild Build State Change"],
        "detail": {
            "project-name": [project_name],
            "build-status": ["SUCCEEDED", "FAILED"]
        }
    }

    # Create/Update rule
    rule_response = events.put_rule(
        Name=RULE_NAME,
        EventPattern=json.dumps(event_pattern),
        State='ENABLED',
        Description='Monitor Cluster-Configuration CodeBuild status'
    )
    rule_arn = rule_response['RuleArn']

    # Attach target
    events.put_targets(
        Rule=RULE_NAME,
        Targets=[{"Id": "1", "Arn": lambda_arn}]
    )

    # Add permission (idempotent best effort)
    try:
        lambda_client.add_permission(
            FunctionName=lambda_arn,
            StatementId='EventBridgeInvokePermission',
            Action='lambda:InvokeFunction',
            Principal='events.amazonaws.com',
            SourceArn=rule_arn
        )
    except lambda_client.exceptions.ResourceConflictException:
        pass  # Permission already exists

    return RULE_NAME, rule_arn
    