def render_templates(s3_client, s3_bucket, template_key, all_yml_template_key, component_info, ssh_user):
    template_content = s3_client.get_object(
        Bucket=s3_bucket,
        Key=template_key
    )['Body'].read().decode()

    template_content = template_content.replace('{ssh_user}', ssh_user)

    first_key = next(
        (info.get('key_name') for info in component_info.values() if info.get('key_name')),
        None
    )
    pem_path = f"/root/.ssh/{first_key}.pem" if first_key else '{pemkey}'
    template_content = template_content.replace('{pemkey}', pem_path)

    for comp, info in component_info.items():
        template_content = template_content.replace(f'{{{comp}}}', info.get('ip') or '')

    all_yml = s3_client.get_object(
        Bucket=s3_bucket,
        Key=all_yml_template_key
    )['Body'].read().decode()

    mapping = {
        'cluster_master_ip': component_info.get('ClusterMaster', {}).get('private_ip', ''),
        'idx1_ip': component_info.get('idx1', {}).get('private_ip', ''),
        'idx2_ip': component_info.get('idx2', {}).get('private_ip', ''),
        'idx3_ip': component_info.get('idx3', {}).get('private_ip', ''),
        'sh1_ip': component_info.get('SH1', {}).get('private_ip', ''),
        'sh2_ip': component_info.get('SH2', {}).get('private_ip', ''),
        'sh3_ip': component_info.get('SH3', {}).get('private_ip', ''),
        'management_server_ip': component_info.get('Management_server', {}).get('private_ip', ''),
        'if_ip': component_info.get('IF', {}).get('private_ip', '')
    }

    for key, val in mapping.items():
        all_yml = all_yml.replace(f'{{{key}}}', val or '')

    return template_content, all_yml


def prepare_and_trigger_build(
    s3_client, codebuild_client, s3_bucket, final_folder,
    email, plan_start_date, template_content, all_yml,
    component_info, instances, codebuild_project_name
):
    safe_plan_date = plan_start_date.replace(':', '-')

    inventory_file = f"inventory-{safe_plan_date}.ini"
    all_yml_file = f"all-{safe_plan_date}.yml"
    instance_ids_file = f"instance-ids-{safe_plan_date}.txt"

    email_folder = final_folder.format(email=email)

    instance_ids = [i['InstanceId'] for i in instances]

    s3_client.put_object(
        Bucket=s3_bucket,
        Key=f"{email_folder}{instance_ids_file}",
        Body="\n".join(instance_ids)
    )

    s3_client.put_object(
        Bucket=s3_bucket,
        Key=f"{email_folder}{inventory_file}",
        Body=template_content
    )

    s3_client.put_object(
        Bucket=s3_bucket,
        Key=f"{email_folder}group_vars/{all_yml_file}",
        Body=all_yml
    )

    key_files = sorted({
        f"{info['key_name']}.pem"
        for info in component_info.values()
        if info.get('key_name')
    })

    response = codebuild_client.start_build(
        projectName=codebuild_project_name,
        environmentVariablesOverride=[
            {'name': 'EMAIL', 'value': email, 'type': 'PLAINTEXT'},
            {'name': 'INVENTORY_S3_PATH', 'value': f"s3://{s3_bucket}/{email_folder}{inventory_file}", 'type': 'PLAINTEXT'},
            {'name': 'GROUP_VARS_S3_PATH', 'value': f"s3://{s3_bucket}/{email_folder}group_vars/{all_yml_file}", 'type': 'PLAINTEXT'},
            {'name': 'KEY_FILES', 'value': " ".join(key_files), 'type': 'PLAINTEXT'},
            {'name': 'INSTANCE_IDS_S3_PATH', 'value': f"s3://{s3_bucket}/{email_folder}{instance_ids_file}", 'type': 'PLAINTEXT'}
        ]
    )
    

    # After successfully starting the build

    build_id = response['build']['id']
    build_arn = response['build']['arn']
    project_name = response['build']['projectName']

    print("=== CODEBUILD TRIGGERED SUCCESSFULLY ===")
    print(f"Build ID     : {build_id}")
    print(f"Build ARN    : {build_arn}")
    print(f"Project      : {project_name}")
    print(f"Console Link : https://console.aws.amazon.com/codesuite/codebuild/projects/{project_name}/build/{build_id}")

    return response, inventory_file, instance_ids_file, all_yml_file, instance_ids