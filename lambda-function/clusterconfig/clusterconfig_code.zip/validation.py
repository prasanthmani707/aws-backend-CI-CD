import re
import json


def build_error(message, status=400):
    return {
        "statusCode": status,
        "headers": {"Access-Control-Allow-Origin": "*"},
        "body": json.dumps({"error": message})
    }


def validate_required(username, email, plan_start_date):
    if not username or not email or not plan_start_date:
        return build_error(
            "username, email and plan_start_date (or PlanStartDate) are required"
        )
    return None


def validate_ssh_user(ssh_user):
    if not ssh_user:
        return build_error("ssh_user is required")
    if ssh_user not in ["ec2-user", "ubuntu"]:
        return build_error("Invalid ssh_user. Allowed values: ec2-user, ubuntu")
    return None


def validate_username_format(username):
    if not re.match(r'^[a-zA-Z0-9_-]+$', username):
        return build_error("Invalid username format")
    return None


def validate_email_format(email):
    if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
        return build_error("Invalid email format")
    return None


def validate_request(username, email, plan_start_date, ssh_user):
    for fn in (validate_required,):
        err = fn(username, email, plan_start_date)
        if err:
            return err

    err = validate_ssh_user(ssh_user)
    if err:
        return err

    err = validate_username_format(username)
    if err:
        return err

    err = validate_email_format(email)
    if err:
        return err

    return None