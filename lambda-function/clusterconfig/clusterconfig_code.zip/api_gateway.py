import json
from auth_utils import get_email_from_event



def API_Gateway(event):
    if 'body' in event:
        try:
            body = json.loads(event['body'])
            username = body.get("username")
            # email = body.get("email")
            plan_start_date = body.get("PlanStartDate")
            ssh_user = body.get("ssh_user")
            #getting JWT email from get_email_from_event function
            email, error = get_email_from_event(event)
            print(f"email id : {email}")

            if error:
               return error
        except json.JSONDecodeError:
            return None, None, None, None
    else:
        username = event.get("username")
        email = event.get("email")
        plan_start_date = event.get("PlanStartDate")
        ssh_user = event.get("ssh_user")

    return username, email, plan_start_date, ssh_user