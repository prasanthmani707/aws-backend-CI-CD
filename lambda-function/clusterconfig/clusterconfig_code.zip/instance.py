def get_tag_value(tags, key):
    return next((t['Value'] for t in tags if t['Key'] == key), None)


def get_user_instances(ec2_client, email):
    response = ec2_client.describe_instances(
        Filters=[
            {'Name': 'tag:Owner', 'Values': [email]},
            {'Name': 'tag-key', 'Values': ['Name']}
        ]
    )

    instances = []
    for res in response.get('Reservations', []):
        instances.extend(res.get('Instances', []))

    return instances


def filter_instances_by_plan(instances, plan_start_date):
    return [
        i for i in instances
        if get_tag_value(i.get('Tags', []), 'PlanStartDate') == plan_start_date
    ]


def get_required_components(username):
    return {
        "ClusterMaster": f"{username}-ClusterMaster",
        "idx1": f"{username}-idx1",
        "idx2": f"{username}-idx2",
        "idx3": f"{username}-idx3",
        "SH1": f"{username}-SH1",
        "SH2": f"{username}-SH2",
        "SH3": f"{username}-SH3",
        "Management_server": f"{username}-Management_server",
        "IF": f"{username}-IF"
    }


def build_component_info(instances, username):
    required_components = get_required_components(username)

    component_info = {
        comp: {
            'state': None,
            'ip': None,
            'private_ip': None,
            'key_name': None,
            'found': False
        } for comp in required_components
    }

    for instance in instances:
        name_tag = get_tag_value(instance.get('Tags', []), "Name")
        if not name_tag:
            continue

        for comp, expected_name in required_components.items():
            if name_tag == expected_name:
                component_info[comp]['found'] = True
                component_info[comp]['state'] = instance['State']['Name']
                component_info[comp]['key_name'] = instance.get('KeyName')
                component_info[comp]['private_ip'] = instance.get('PrivateIpAddress')

                if instance['State']['Name'] == "running":
                    component_info[comp]['ip'] = instance.get('PublicIpAddress')
                break

    errors = []
    for comp, info in component_info.items():
        if not info['found']:
            errors.append(f"{required_components[comp]} not found")
        elif info['state'] != "running":
            errors.append(f"{required_components[comp]} is not running")
        elif not info['ip']:
            errors.append(f"{required_components[comp]} has no public IP")
        elif not info['private_ip']:
            errors.append(f"{required_components[comp]} has no private IP")
        elif not info['key_name']:
            errors.append(f"{required_components[comp]} has no key pair")

    return component_info, errors