import boto3
import os
import json
from datetime import datetime, timezone
from api_gateway import API_Gateway
from validation import validate_request
from instance import (
    get_user_instances,
    filter_instances_by_plan,
    build_component_info
)
from codebuild import render_templates, prepare_and_trigger_build
from eventbridge import create_eventbridge_rule  # <-- New separate module

ec2 = boto3.client('ec2')
s3 = boto3.client('s3')
codebuild = boto3.client('codebuild')
dynamodb = boto3.resource('dynamodb')

S3_BUCKET = os.environ.get("S3_BUCKET", "splunklab-dev")
TEMPLATE_KEY = "cluster-templates/inventory.ini"
ALL_YML_TEMPLATE_KEY = "cluster-templates/all.yml"
FINAL_FOLDER = "cluster-templates/final/{email}/"
CODEBUILD_PROJECT_NAME = "Cluster-Configuration"
CLUSTER_RETENTION_TABLE = os.environ.get("CLUSTER_RETENTION_TABLE", "ClusterConfigStatusHistory")

retention_table = dynamodb.Table(CLUSTER_RETENTION_TABLE)
LAMBDA_TARGET_ARN = "arn:aws:lambda:us-east-1:ACCOUNT_ID:function:PostBuildHandler"  # Replace ACCOUNT_ID

triggered_at = datetime.now(timezone.utc).isoformat()

print("triggered_at", triggered_at)

def lambda_handler(event, context):
    try:
        # -------------------------------
        # API Gateway / Direct call handling
        # -------------------------------
        username, email, plan_start_date, ssh_user = API_Gateway(event)
        
        request_error = validate_request(username, email, plan_start_date, ssh_user)
        if request_error:
            return request_error

        # -------------------------------
        # Get and filter EC2 instances
        # -------------------------------
        instances = get_user_instances(ec2, email)
        if not instances:
            return {
                "statusCode": 404,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "No instances found for this user"})
            }

        instances = filter_instances_by_plan(instances, plan_start_date)
        if not instances:
            return {
                "statusCode": 404,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "error": f"No instances found for PlanStartDate {plan_start_date}"
                })
            }

        # -------------------------------
        # Build component info
        # -------------------------------
        component_info, errors = build_component_info(instances, username)
        if errors:
            return {
                "statusCode": 400,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": " | ".join(errors)})
            }

        # -------------------------------
        # Render templates
        # -------------------------------
        template_content, all_yml = render_templates(
            s3, S3_BUCKET, TEMPLATE_KEY, ALL_YML_TEMPLATE_KEY, component_info, ssh_user
        )

        # -------------------------------
        # Prepare files + Trigger CodeBuild
        # -------------------------------
        response, inventory_file, instance_ids_file, all_yml_file, instance_ids = prepare_and_trigger_build(
            s3, codebuild, S3_BUCKET, FINAL_FOLDER, email,
            plan_start_date, template_content, all_yml,
            component_info, instances, CODEBUILD_PROJECT_NAME
        )

        # -------------------------------
        # Create EventBridge Rule (idempotent)
        # -------------------------------
        # rule_name, rule_arn = create_eventbridge_rule(
        #     project_name=CODEBUILD_PROJECT_NAME,
        #     lambda_arn=LAMBDA_TARGET_ARN
        # )
        # print(f"EventBridge Rule: {rule_name} | ARN: {rule_arn}")
        
        retention_table.put_item(
            Item={
                "build_id": response['build']['id'],
                "email": email,
                "plan_start_date": plan_start_date,
                "instance_ids": instance_ids,
                "status": "IN_PROGRESS",
                "triggered_at": triggered_at   # <-- Added field
            }
        )

        return {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "status": "success",
                "email": email,
                "plan_start_date": plan_start_date,
                "ssh_user": ssh_user,
                "inventory_file": inventory_file,
                "instance_file": instance_ids_file,
                "group_vars_file": all_yml_file,
                "build_id": response['build']['id'],
                "instance_count": len(instances)
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")  # Log for CloudWatch
        return {
            "statusCode": 500,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "error": "Internal server error",
                "message": str(e)
            })
        }