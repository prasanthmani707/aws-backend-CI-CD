import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Common headers for all responses
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    }
    
    try:
        # Handle OPTIONS request first
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'status': 'OK'})
            }
        
        # Parse the request
        body = event.get('body', '{}')
        if event.get('isBase64Encoded', False):
            import base64
            body = base64.b64decode(body).decode('utf-8')
        
        data = json.loads(body)
        instance_id = data.get('instance_id', '').strip()
        new_name = data.get('new_name', '').strip()
        
        # Basic validation
        if not instance_id or not new_name:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': 'instance_id and new_name are required'})
            }
        
        # Initialize EC2 client and rename instance
        ec2 = boto3.client('ec2')
        ec2.create_tags(
            Resources=[instance_id],
            Tags=[{'Key': 'Name', 'Value': new_name}]
        )
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'message': f'Successfully renamed instance to {new_name}'
            })
        }
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error: {error_msg}")
        
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'success': False,
                'error': error_msg
            })
        }