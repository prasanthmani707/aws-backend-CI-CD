import boto3
from datetime import datetime, timezone
from decimal import Decimal
from boto3.dynamodb.conditions import Key, Attr

# AWS clients
ec2 = boto3.client('ec2')
dynamodb = boto3.resource('dynamodb')

table = dynamodb.Table('compute_cost')
price_catalog = dynamodb.Table('Pricing_catalog')


# ---------------- Price lookup ----------------
def get_ec2_price_per_hour(instance_type, region):
    resource_type = f"ec2#{region}#{instance_type}"

    response = price_catalog.get_item(
        Key={"resource_type": resource_type}
    )

    item = response.get("Item")
    if not item:
        return None

    return Decimal(str(item["price_per_hour"]))

def calculate_cost(running_item, event_time):
    try:
        start_time = datetime.fromisoformat(running_item['start_time'])
        total_seconds = int((event_time - start_time).total_seconds())
        
        # 🔥 COST CALCULATION
        hours_decimal = Decimal(str(total_seconds)) / Decimal("3600")
        per_hour_cost = Decimal(str(running_item['per_hour_cost']))
        total_cost = (hours_decimal * per_hour_cost).quantize(Decimal("0.00001"))
        
        # 🔥 SINGLE STRING: "minutesmsecondss" 
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        time_used = f"{minutes}m{seconds}s"  # ex: "45m30s"
        
        return total_cost, time_used
    except Exception as e:
        print(f"Error calculating cost: {e}")
        return Decimal('0.0'), "0m0s"
# ---------------- Lambda handler ----------------
def lambda_handler(event, context):

    instance_id = event['detail']['instance-id']
    state = event['detail']['state']
    region = event['region']   # running | stopped | terminated
    now = datetime.utcnow().isoformat()

    print(f"📥 Event received: {instance_id} → {state}")

    email_id = None
    per_hour_cost = None

    # ---------------- Instance metadata (safe) ----------------
    try:
        response = ec2.describe_instances(InstanceIds=[instance_id])
        instance = response['Reservations'][0]['Instances'][0]

        tags = instance.get('Tags', [])
        email_id = next((t['Value'].lower() for t in tags if t['Key'] == 'email_id'), None)

        instance_type = instance['InstanceType']
        per_hour_cost = get_ec2_price_per_hour(instance_type, region)

    except Exception as e:
        # Happens for terminated instances
        print(f"⚠️ describe_instances failed: {e}")

    # ================= RUNNING =================
    if state == 'running':

        table.put_item(
            Item={
                'instance_id': instance_id,
                'tnx_id': now,      # unique session
                'email_id': email_id,
                'state': 'running',
                'start_time': now,
                'per_hour_cost': per_hour_cost
            }
        )

        print(f"Instance {instance_id} started")
        return {"statusCode": 200}

    # ================= STOPPED / TERMINATED =================
    elif state in ('stopped', 'terminated'):

        # 1️⃣ Find latest RUNNING session
        running_resp = table.query(
            KeyConditionExpression=Key('instance_id').eq(instance_id),
            FilterExpression=Attr('state').eq('running'),
            ScanIndexForward=False,
            Limit=1
        )

        if not running_resp['Items']:
            print(" No running session found (already closed)")
            return {"statusCode": 200}

        running_item = running_resp['Items'][0]

        # Idempotency guard
        if 'end_time' in running_item:
            print("Session already ended")
            return {"statusCode": 200}

        start_time = datetime.fromisoformat(running_item['start_time'])
        per_hour_cost = Decimal(str(running_item['per_hour_cost']))

        total_cost, time_used = calculate_cost(running_item, datetime.fromisoformat(now))
        if not total_cost:
            return {"statusCode": 500}

        # 3️⃣ Update the same session
        table.update_item(
            Key={
                'instance_id': instance_id,
                'tnx_id': running_item['tnx_id']
            },
            UpdateExpression="""
                SET #s = :s,
                    end_time = :et,
                    total_cost = :tc,
                    time_used = :h
            """,
            ExpressionAttributeNames={'#s': 'state'},
            ExpressionAttributeValues={
                ':s': state,
                ':et': now,
                ':tc': total_cost,
                ':h': time_used
            }
        )

        print(
            f"✅ Instance {instance_id} {state} | "
            f"Total cost: {total_cost}"
        )

    return {"statusCode": 200}
