import os
import boto3
import datetime
import random
import json
import re
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def log_event(message, **kwargs):
    event = {"message": message, **kwargs}
    logger.info(json.dumps(event))

s3 = boto3.client('s3')
ec2 = boto3.client('ec2')
codebuild = boto3.client('codebuild')
current_region = os.environ.get('AWS_REGION')  # Lambda automatically sets this

# ✅ DynamoDB setup
dynamodb = boto3.resource('dynamodb')
status_table = dynamodb.Table('ProvisioningStatus')
USERWALLET_TABLE = os.environ.get("USERWALLET_TABLE", "UserWallet")

BUCKET = "splunklab-dev"

def check_ec2_key_exists(key_name, region_name=current_region):
    try:
        ec2.describe_key_pairs(KeyNames=[key_name])
        return True
    except:
        return False

def check_s3_key_exists(usermail, key_name):
    try:
        key_path = f"clients/{usermail}/keys/{key_name}.pem"
        s3.head_object(Bucket=BUCKET, Key=key_path)
        return True
    except:
        return False

def create_ec2_key_and_upload(usermail, base_name):
    clean_name = re.sub(r'[^a-zA-Z0-9\-]', '-', base_name)
    final_name = clean_name
    suffix = 1

    # 🟡 Check if any PEM key already exists for this user (username.pem or username-1.pem)
    existing_keys = s3.list_objects_v2(
        Bucket=BUCKET,
        Prefix=f"clients/{usermail}/keys/{clean_name}"
    )

    if 'Contents' in existing_keys and existing_keys['KeyCount'] > 0:
        print(f"🔐 Existing PEM key already found in S3 for {usermail}. Skipping new key creation.")
        return clean_name

    while check_ec2_key_exists(final_name) or check_s3_key_exists(usermail, final_name):
        final_name = f"{clean_name}-{suffix}"
        suffix += 1

        if check_s3_key_exists(usermail, final_name):
            print(f"🔐 Key already exists in S3 for user {usermail}: {final_name}. Skipping creation.")
            return final_name

    try:
        response = ec2.create_key_pair(KeyName=final_name)
        private_key = response['KeyMaterial']
        key_path = f"clients/{usermail}/keys/{final_name}.pem"
        s3.put_object(Bucket=BUCKET, Key=key_path, Body=private_key.encode(), ACL='private')
        print(f"✅ Created EC2 KeyPair and uploaded to S3: {key_path}")
    except Exception as e:
        print(f"❌ Failed to create EC2 key pair: {str(e)}")
        raise e

    return final_name

def get_splunk_version(body):
    raw_version = body.get("splunk_version")
    if not raw_version:
        return ""
    raw_version = str(raw_version).strip()
    # Allow simple version tokens only to avoid path issues
    safe_version = re.sub(r"[^a-zA-Z0-9._-]", "", raw_version)
    return safe_version

def build_versioned_prefix(base_prefix, splunk_version):
    if not splunk_version:
        return base_prefix
    return f"splunk-version-based-environments/splunk-{splunk_version}/{base_prefix}"


# ✅ Separated handler for direct triggers
def handle_direct_triggers(body, triggered_projects):
    extra_direct_triggers = {
        # template_name: (codebuild_project, tfvars_folder)
        "Splunk-DC_IDX_SS": ("Splunk-DC-IDX-SS-trigger", "tfvars/"),
        "Splunk-SE_DEV_ADV_KO": ("Splunk-SE_DEV_ADV_KO-trigger", "tfvars/"),
        "Splunk-DNC_DATA_ADMIN_ADV1": ("Splunk-DNC-EC2Only","tfvars/"),
        "Splunk-DC_IDX_MS_SH": ("Splunk-DC_IDX_MS_SH-trigger","tfvars/"),
        "Splunk-DC_IDX_SS_SH": ("Splunk-DC_IDX_SS_SH-trigger","tfvars/"),
        "Splunk-DC_IDX_SS_SHC_SS": ("Splunk-DC_IDX_SS_SHC_SS-trigger","tfvars/"),
        "Splunk-DC_IDX_MS_SHC_MS": ("Splunk-DC_IDX_MS_SHC_MS-trigger","tfvars/"),
        "Splunk-DC-SS-Full": ("Splunk-DC-SS-Full-trigger","tfvars/"),
        "Splunk-HF": ("SplunkEC2Only","tfvars/"),
        "Splunk-MC": ("SplunkEC2Only","tfvars/"),
        "Splunk-DC_IDX_SS_NS": ("Splunk-DC_IDX_SS_NS-trigger", "tfvars/"),
        "Splunk-DC_IDX_SS_S1": ("Splunk-DC_IDX_SS_S1-trigger", "tfvars/"),
        "Splunk-DC_IDX_SS_S2": ("Splunk-DC_IDX_SS_S2-trigger", "tfvars/"),
        "Splunk-DC_SH_SS_S2": ("Splunk-DC_SH_SS_S2-trigger", "tfvars/"),
        "Splunk-DC_S2_IDXC_SH": ("Splunk-DC_S2_IDXC_SH-trigger", "tfvars/"),
        "Splunk-DC_S2_SHC": ("Splunk-DC_SH_SS_S2-trigger", "tfvars/"),
        "Splunk-DNC_SHIDXHF" : ("Splunk-DNC_SHIDXHF-trigger", "tfvars/"),
        # Add future direct templates here...
    }

    template_files = body.get("template_file", [])
    if isinstance(template_files, str):
        try:
            template_files = json.loads(template_files)
        except:
            template_files = [template_files]

    suffix = random.randint(100, 999)
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    current_time = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    splunk_version = get_splunk_version(body)

    # ✅ MODIFIED: Check if this is normal user access (all three fields missing)
    id_field = body.get("id")
    unique_id_field = body.get("unique_id")
    created_field = body.get("created")
    
    is_normal_user_access = all([not id_field, not unique_id_field, not created_field or created_field == "false"])

    for template_name in template_files:
        # Extract base template name without suffix number and .template extension
        # For "Splunk-DC_IDX_SS_SHC_SS-670.template" → "Splunk-DC_IDX_SS_SHC_SS"
        template_base = re.sub(r'-\d+\.template$', '', template_name).strip()
        
        for direct_key, (project_name, tfvars_prefix) in extra_direct_triggers.items():
            if direct_key == template_base:
                # Splunk-SOAR requires an explicit yes/no toggle.
                if direct_key == "Splunk-SOAR":
                    soar_install = str(body.get("soar_install", "")).strip().lower()
                    if soar_install not in ["yes", "no"]:
                        raise ValueError("For Splunk-SOAR template, provide soar_install as 'yes' or 'no'")
                    project_name = "Splunk-SOAR-trigger" if soar_install == "yes" else "Splunk-SOAR-ec2-only-trigger"

                # ✅ MODIFIED: Only validate required fields if NOT normal user access
                if not is_normal_user_access:
                    required_fields = ["id", "unique_id", "created"]
                    missing_fields = []
                    
                    for field in required_fields:
                        if not body.get(field):
                            missing_fields.append(field)
                    
                    if missing_fields:
                        error_msg = f"Missing required fields for direct trigger: {', '.join(missing_fields)}"
                        print(f"❌ {error_msg}")
                        raise ValueError(error_msg)
                else:
                    print(f"📝 Normal user access detected for direct template {template_name}, skipping validation")
                
                versioned_tfvars_prefix = build_versioned_prefix(tfvars_prefix, splunk_version)
                print(f"📥 Fetching direct template: {versioned_tfvars_prefix}{template_name}")
                try:
                    res = s3.get_object(Bucket=BUCKET, Key=f"{versioned_tfvars_prefix}{template_name}")
                    content = res['Body'].read().decode()
                except Exception as e:
                    print(f"❌ Failed to fetch template {template_name}: {str(e)}")
                    continue

                # 🔁 Replace placeholders
                if "{current_time}" in content:
                    content = content.replace("{current_time}", current_time)
                    print(f"🔄 Replaced current_time with: {current_time}")

                placeholders = re.findall(r"{(.*?)}", content)
                for key in placeholders:
                    if key == "PlanStartDate":
                        value = current_time
                    elif key == "suffix":
                        value = str(suffix)
                    elif key in ["course_id", "CourseID", "COURSE_ID"]:
                        value = body.get("course_id") or "General"   # ✅ default
                    else:
                        value = str(body.get(key) or "")             # ✅ EMPTY if missing

                    content = content.replace(f"{{{key}}}", value)

                # 📝 Save final tfvars
                final_prefix = "final" if tfvars_prefix == "tfvars/" else "sds-final"
                final_key = f"{final_prefix}/terraform-{timestamp}-{suffix}-{template_base}.tfvars"
                s3.put_object(Bucket=BUCKET, Key=final_key, Body=content.encode())
                print(f"✅ Final tfvars saved to: {final_key}")

                # 🚀 Trigger CodeBuild
                print(f"🚀 Triggering CodeBuild: {project_name}")
                
                # ✅ MODIFIED: Use provided fields or defaults for normal user access
                env_vars = [
                    {'name': 'TFVARS_S3_KEY', 'value': final_key, 'type': 'PLAINTEXT'},
                    {'name': 'USER_EMAIL', 'value': body.get("usermail", "unknown"), 'type': 'PLAINTEXT'},
                    {'name': 'COURSE_ID', 'value': body.get("course_id", "splunk-test"), 'type': 'PLAINTEXT'},
                    {'name': 'TEMPLATE_FILE', 'value': template_name, 'type': 'PLAINTEXT'},
                    {'name': 'UNIQUE_ID', 'value': body.get("unique_id", ""), 'type': 'PLAINTEXT'},
                    {'name': 'START_DATE', 'value': body.get("start_date", ""), 'type': 'PLAINTEXT'},
                    {'name': 'CREATED', 'value': str(body.get("created", "false")).lower(), 'type': 'PLAINTEXT'},
                    {'name': 'ITEM_ID', 'value': body.get("id", ""), 'type': 'PLAINTEXT'}
                ]
                
                response = codebuild.start_build(
                    projectName=project_name,
                    environmentVariablesOverride=env_vars
                )

                actual_build_id = response["build"]["id"]

                triggered_projects.append({
                    'template': template_name,
                    'final_tfvars': final_key,
                    'codebuild_project': project_name,
                    'actual_build_id': actual_build_id
                })

                # ✅ Save to DynamoDB
                status_table.put_item(
                    Item={
                        "email": body.get("usermail", "unknown"),
                        "status": "in_progress",
                        "project": project_name,
                        "build_id": actual_build_id,
                        "instance_ids": [],
                        "started_at": datetime.datetime.utcnow().isoformat()
                    }
                )
def lambda_handler(event, context):
    print("📩 Event received:", event)
    try:
        # ✅ Safe body parsing
        if "body" in event and isinstance(event["body"], str):
            body = json.loads(event["body"])
        elif "body" in event and isinstance(event["body"], dict):
            body = event["body"]
        else:
            body = event

        for k, v in list(body.items()):
            if v is None:
                body[k] = "null"

        template_files = body.get('template_file') or []
        if isinstance(template_files, str):
            template_files = template_files.strip()
            if template_files.startswith('[') and template_files.endswith(']'):
                try:
                    template_files = json.loads(template_files)
                except json.JSONDecodeError:
                    template_files = [template_files]
            else:
                template_files = [template_files]

        usermail = body.get('usermail', '').strip().lower()
        course_id = body.get('course_id') or "General"
        unique_id = body.get('unique_id', '')  # Optional field, default is ''
        start_date = body.get('start_date', '')  # Optional
        created = str(body.get('created', 'false')).lower()  # Always string: "true" / "false"
        item_id = body.get("id")  # Optional field
        splunk_version = get_splunk_version(body)

        # ✅ MODIFIED LOGIC: Check if ALL three fields are missing (normal user access)
        all_fields_missing = all([not unique_id, not item_id, not created or created == "false"])
        
        if not all_fields_missing:
            # At least one of the fields is present, proceed with UserWallet update
            print("✅ At least one required field present, attempting UserWallet update...")
            
            # Check if we have enough data to attempt UserWallet update
            if usermail and template_files and (unique_id or item_id):
                wallet_update_result = update_userwallet_start_created_direct(
                    usermail=usermail,
                    course_id=course_id,
                    template_file=template_files[0],  # use first template for source_id
                    unique_id=unique_id or "",  # Use empty string if not provided
                    start_date=start_date,
                    created=created,
                    item_id=item_id or ""  # Use empty string if not provided
                )
                
                if wallet_update_result is False:
                    print("❌ UserWallet update failed, stopping provisioning...")
                    return {
                        'statusCode': 400,
                        'body': json.dumps({'error': 'No matching wallet record found for the provided details'})
                    }
            else:
                print("⚠️ Missing required fields for UserWallet update, but proceeding with provisioning...")
        else:
            # All three fields are missing - normal user access, skip UserWallet update
            print("⏭️ Normal user access detected (missing id, unique_id, created), skipping UserWallet update")
            print(f"   Fields received: id={item_id}, unique_id={unique_id}, created={created}")

        log_event("📂 Templates to process", usermail=usermail, templates=template_files)

        lowercase_keywords = ["mysql", "mssql", "ossec", "syslog", "jenkins", "windows", "linux", "openvpn"]
        processed_templates = []
        for f in template_files:
            if any(keyword in f.lower() for keyword in lowercase_keywords):
                processed_templates.append(f.lower())
            else:
                processed_templates.append(f)
        template_files = processed_templates

        if not template_files:
            print("❌ No template files provided")
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing template_file(s)'})}

        username = body.get('username')
        install_splunk = body.get('splunk_install', '').lower()
        soar_install = body.get('soar_install', '').lower()
        botsv3 = body.get('botsv3', '').lower()
        key_name = body.get('key_name', username or 'default')

        if not username or not usermail:
            print("❌ Missing username or usermail in request")
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing username or usermail'})}

        if not check_s3_key_exists(usermail, key_name):
            print(f"🔑 Key not found in S3 for user {usermail}, creating new key...")
            key_name = create_ec2_key_and_upload(usermail, key_name)

        suffix = random.randint(100, 999)
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
        current_time = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

        triggered_projects = []

        # ✅ Call direct triggers handler
        handle_direct_triggers(body, triggered_projects)

        for template_file in template_files:
            # ⏭️ Skip if already handled by direct trigger
            if any(d["template"] == template_file for d in triggered_projects):
                print(f"⏭️ Skipping tfvars generation for already triggered template: {template_file}")
                continue

            template_file_lower = template_file.lower()
            s3_key_prefix = "tfvars/" if any(x in template_file for x in ["DNC", "SE", "DC", "SOAR"]) else "sds-tfvars/"
            s3_key_prefix = build_versioned_prefix(s3_key_prefix, splunk_version)

            print("📥 Fetching template from S3:", f"{s3_key_prefix}{template_file}")
            res = s3.get_object(Bucket=BUCKET, Key=f"{s3_key_prefix}{template_file}")
            content = res['Body'].read().decode()

            if "{current_time}" in content:
                content = content.replace("{current_time}", current_time)
                print(f"🔄 Replaced current_time placeholder with: {current_time}")

            placeholders = re.findall(r"{(.*?)}", content)
            for key in placeholders:
                if key == "PlanStartDate":
                    value = current_time
                elif key == "suffix":
                    value = str(suffix)
                elif key in ["course_id", "CourseID", "COURSE_ID"]:
                    value = body.get("course_id") or "General"    
                else:
                    value = str(body.get(key, f"<{key}_missing>"))
                content = content.replace(f"{{{key}}}", value)

            final_key_prefix = "final" if "tfvars/" in s3_key_prefix else "sds-final"
            final_key = f"{final_key_prefix}/terraform-{timestamp}-{suffix}-{template_file.replace('.tfvars','')}.tfvars"
            s3.put_object(Bucket=BUCKET, Key=final_key, Body=content.encode())
            print(f"✅ Final tfvars saved as: {final_key}")

            if any(x in template_file for x in ["DNC", "SE", "DC", "SOAR"]):
                template_type = next((x for x in ["DNC", "SE", "DC", "SOAR"] if x in template_file), None)
                print(f"�� Detected template type: {template_type}")
                if not template_type:
                    continue

                if template_type == "DNC":
                    if botsv3 == "yes" and install_splunk == "yes":
                        project_name = "Splunk-DNC-EC2Splunk-Ansible"
                    elif botsv3 == "yes" and install_splunk == "no":
                        project_name = "Splunk-DNC-EC2Only"
                    elif botsv3 == "no" and install_splunk == "yes":
                        project_name = "Splunk-DNC-EC2Splunk"
                    else:
                        project_name = "Splunk-DNC-EC2Only"

                elif template_type in ["SE", "HF", "MC"]:
                    if botsv3 == "yes" and install_splunk == "yes":
                        project_name = "SplunkEC2Ansible"
                    elif botsv3 == "yes" and install_splunk == "no":
                        project_name = "SplunkEC2Only"
                    elif botsv3 == "no" and install_splunk == "yes":
                        project_name = "SplunkEC2Splunk"
                    else:
                        project_name = "SplunkEC2Only"

                elif template_type == "DC":
                    project_name = "Splunk-DC-EC2Splunk" if install_splunk == "yes" else "Splunk-DC-EC2Only"

                elif template_type == "SOAR":
                    if soar_install == "yes":
                        project_name = "Splunk-SOAR-trigger"
                    else:
                        project_name = "Splunk-SOAR-ec2-only-trigger"

            else:
                if 'mysql' in template_file_lower:
                    project_name = "MySQL-trigger"
                elif 'mssql' in template_file_lower:
                    project_name = "MSSQL-trigger"
                elif 'ossec' in template_file_lower:
                    project_name = "OSSEC-trigger"
                elif 'syslog' in template_file_lower:
                    project_name = "Syslog-trigger"
                elif 'jenkins' in template_file_lower:
                    project_name = "Jenkins-trigger"
                elif 'windows' in template_file_lower:
                    project_name = "Windows-trigger"
                elif 'linux' in template_file_lower:
                    project_name = "Linux-trigger"
                elif 'openvpn' in template_file_lower:
                    project_name = "OpenVPN-trigger"
                else:
                    print(f"❌ Unknown template type: {template_file}")
                    return {'statusCode': 400, 'body': json.dumps({'error': f'Unknown template type: {template_file}'})}

            print(f"🚀 Triggering CodeBuild: {project_name}")
            response = codebuild.start_build(
                projectName=project_name,
                environmentVariablesOverride=[
                    {'name': 'TFVARS_S3_KEY', 'value': final_key, 'type': 'PLAINTEXT'},
                    {'name': 'USER_EMAIL', 'value': usermail, 'type': 'PLAINTEXT'},
                    {'name': 'COURSE_ID', 'value': course_id, 'type': 'PLAINTEXT'},
                    {'name': 'TEMPLATE_FILE', 'value': template_file, 'type': 'PLAINTEXT'},
                    {'name': 'UNIQUE_ID', 'value': unique_id, 'type': 'PLAINTEXT'},
                    {'name': 'START_DATE', 'value': start_date, 'type': 'PLAINTEXT'},
                    {'name': 'CREATED', 'value': created, 'type': 'PLAINTEXT'},
                    {'name': 'ITEM_ID', 'value': body.get("id", ""), 'type': 'PLAINTEXT'}
                ]
            )

            actual_build_id = response["build"]["id"]

            triggered_projects.append({
                'template': template_file,
                'final_tfvars': final_key,
                'codebuild_project': project_name,
                'actual_build_id': actual_build_id
            })

            # ✅ Save with actual CodeBuild ID in DynamoDB
            status_table.put_item(
                Item={
                    "email": usermail,
                    "status": "in_progress",
                    "project": project_name,
                    "build_id": actual_build_id,
                    "instance_ids": [],
                    "started_at": datetime.datetime.utcnow().isoformat()
                }
            )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f"{len(triggered_projects)} project(s) triggered",
                'details': triggered_projects
            })
        }

    except Exception as e:
        print("❌ Error occurred:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


def update_userwallet_start_created_direct(usermail, course_id, template_file, unique_id, start_date, created, item_id=None):
    usermail = usermail.strip().lower()
    
    # Auto-create start_date if empty
    if not start_date or start_date == "null":
        start_date = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    # Require all fields to be present
    if not (unique_id and item_id and usermail and template_file):
        print("⚠️ Skipping UserWallet update: Missing required fields (id, unique_id, usermail, or template_file)")
        return True  # ✅ MODIFIED: Return True to continue processing

    try:
        table = boto3.resource("dynamodb").Table(USERWALLET_TABLE)

        # Fetch exact item using PK+SK - matching DynamoDB column names
        resp = table.get_item(
            Key={
                "user_email": usermail,  # DynamoDB column name
                "id": item_id            # DynamoDB column name
            }
        )

        if "Item" not in resp:
            print(f"❌ No wallet row found for user {usermail} with id {item_id}")
            return False  # ✅ MODIFIED: Return False to indicate failure

        item = resp["Item"]
        
        # Also verify course_id matches if provided
        if course_id and item.get("course_id") != course_id:
            print(f"⚠️ Course ID mismatch: DB has '{item.get('course_id')}', request has '{course_id}'")
            # ✅ MODIFIED: This is also a failure case
            return False

        env_list = item.get("environment", [])
        updated_env = []
        found = False

        # Loop environments → match using EXACT (source_id + unique_id)
        for env in env_list:
            # Check if this environment object matches EXACTLY
            if env.get("source_id") == template_file and env.get("unique_id") == unique_id:
                # Update ONLY this environment object
                env["start_date"] = start_date
                env["created"] = created.lower() == "true"
                found = True
                print(f"✅ Found matching environment: source_id={template_file}, unique_id={unique_id}")

            updated_env.append(env)

        if not found:
            print(f"⚠️ No matching environment found: source_id={template_file}, unique_id={unique_id}")
            print(f"   Available environments: {[(e.get('source_id'), e.get('unique_id')) for e in env_list]}")
            return False  # ✅ MODIFIED: Return False to indicate failure

        # Update back to DB
        table.update_item(
            Key={
                "user_email": usermail,
                "id": item_id
            },
            UpdateExpression="SET environment = :env",
            ExpressionAttributeValues={
                ":env": updated_env
            }
        )

        print(f"✅ UserWallet updated successfully — user_email={usermail}, id={item_id}")
        print(f"   Updated environment: source_id={template_file}, unique_id={unique_id}")
        print(f"   start_date={start_date}, created={created.lower() == 'true'}")
        
        return True  # ✅ MODIFIED: Return True to indicate success

    except Exception as e:
        print(f"❌ Failed to update UserWallet: {str(e)}")
        return False  # ✅ MODIFIED: Return False to indicate failure
