import json
import boto3
from decimal import Decimal
from datetime import datetime
from botocore.exceptions import ClientError
from community_member_check import apply_member_discount

dynamodb = boto3.resource("dynamodb")
wallet_table = dynamodb.Table("user_wallet_creditbased")
lambda_client = boto3.client("lambda")

HISTORY_LAMBDA_NAME = "history_tracker_creditbased"
INSTANCE_TRACKER_LAMBDA_NAME = "Instance_tracker_creditbased"


def lambda_handler(event, context):
    print("🔥 EVENT RECEIVED")
    print(json.dumps(event))

    results = []

    for record in event.get("Records", []):

        #  Validate source
        if record.get("eventSource") != "aws:dynamodb":
            print("⏭ Not DynamoDB event")
            continue

        if record.get("eventName") != "MODIFY":
            print("⏭ Not MODIFY event")
            continue

        new_image = record["dynamodb"].get("NewImage")
        if not new_image:
            print("⏭ No NewImage")
            continue

        #  State check
        state = new_image.get("state", {}).get("S", "").lower()
        print("DEBUG → state:", state)


        # Cost check
        total_cost_raw = new_image.get("total_cost", {}).get("N")
        if not total_cost_raw:
            print("⏭ No total_cost")
            continue

        amount = Decimal(total_cost_raw)
        email_id = new_image.get("email_id", {}).get("S")
        
        if not email_id:
            print("⏭ No email_id")
            continue

        instance_id = new_image.get("instance_id", {}).get("S", "UNKNOWN")
        instance_name = new_image.get("instance_name", {}).get("S", "UNKNOWN")
        used_time = new_image.get("used_time_seconds", {}).get("N")
        updated_time = datetime.utcnow().isoformat()
        print(f"💰 Charging wallet → {email_id}, amount={amount}")
        print(f"💰 Calculated storage cost: ${amount}")
        original_amount = amount  # Save the original cost before discount
        amount, discount_amount = apply_member_discount(email_id, amount)
        print(f"Original amount: ${original_amount}, Discount applied: ${discount_amount}, Final amount to charge: ${amount}")
        print(f"Amount to pay: ${amount}")

        try:
            # 4️⃣ WALLET UPDATE
            response = wallet_table.update_item(
                Key={"email_id": email_id},
                UpdateExpression="""
                    SET previous_balance = current_balance,
                        current_balance = current_balance - :amount,
                        cb_last_updated = :now
                """,
                ConditionExpression="current_balance >= :amount",
                ExpressionAttributeValues={
                    ":amount": amount,
                    ":now": updated_time
                },
                ReturnValues="UPDATED_NEW"
            )

            prev_balance = response["Attributes"]["previous_balance"]
            curr_balance = response["Attributes"]["current_balance"]

            print(f"✅ Wallet updated: {prev_balance} → {curr_balance}")

            results.append({
                "email_id": email_id,
                "instance_id": instance_id,
                "instance_name": instance_name,
                "original_amount": float(original_amount),   # <-- original
                "discount_amount": float(discount_amount),  
                "amount": float(amount),
                "used_time": int(used_time) if used_time else 0,
                "balance_before": float(prev_balance),
                "balance_after": float(curr_balance),
                "source": "compute",
                "status": "SUCCESS",
                "updated_time": updated_time
            })

        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                print(f"⚠️ Insufficient balance for {email_id}")
            else:
                print("❌ DynamoDB error", e)
                raise

    # 5️⃣ Invoke ledger
    if results:
        print(f"🚀 Invoking Ledger with {len(results)} successful charges")
        payload = json.dumps({"records": results}).encode("utf-8")
        lambda_name =[
            HISTORY_LAMBDA_NAME,
            INSTANCE_TRACKER_LAMBDA_NAME,
        ]
        print(f"Invoke → lambda_name: {len(lambda_name)}")
        for name in lambda_name:
            lambda_client.invoke(
                FunctionName=name,
                InvocationType="Event",
                Payload=payload,
            )
    else:
        print("ℹ️ No wallet updates done")

    return {"status": "ok"}
