import json
from trainer_central import create_user

from checkuser import check_user
from auth_jwt import create_jwt
from verify_google_token import verify_google_token
from update_db import update_db


def lambda_handler(event, context):

    path = event.get("rawPath") or event.get("path")

    method = (
        event.get("requestContext", {})
        .get("http", {})
        .get("method")
        or event.get("httpMethod")
    )

    # -------------------------
    # CHECK USER / LOGIN
    # -------------------------
    if path == "/user_profile/checkuser" and method == "POST":

        body = json.loads(event.get("body") or "{}")

        token_id = body.get("token")

        data = verify_google_token(token_id)

        print("GOOGLE DATA:", data)

        email_id = data.get("email")

        user_result = check_user(email_id)

        if user_result == False:
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "message": "User not found."
                })
            }

        if "body" in user_result:
            user_result = json.loads(user_result["body"])

        user_data = user_result.get("data") or user_result

        token = create_jwt(user_data)

        return {
            "statusCode": 200,
            "headers": {
                "Set-Cookie": f"token={token}; HttpOnly; Path=/; Max-Age=3600; Secure; SameSite=Strict"
            },
            "body": json.dumps({
                "message": "login success",
                "user": user_data,
                "source": user_result.get("source")
            })
        }

    # -------------------------
    # USER ADD
    # -------------------------
    if path == "/user_profile/useradd" and method == "POST":

        body = json.loads(event.get("body") or "{}")

        token_id = body.get("token")

        data = verify_google_token(token_id)

        email_id = data.get("email")

        resp = create_user(email_id, body.get("name"))
        print("Create user response:", resp)

        # Create user through centralized Lambda
        lambda_response = update_db(email_id,body)

        print("Lambda1 response:", lambda_response)

        # Re-fetch newly created user
        user_result = check_user(email_id)

        if user_result == False:
            return {
                "statusCode": 500,
                "body": json.dumps({
                    "message": "User creation failed"
                })
            }

        if "body" in user_result:
            user_result = json.loads(user_result["body"])

        user_data = user_result.get("data") or user_result

        token = create_jwt(user_data)

        return {
            "statusCode": 200,
            "headers": {
                "Set-Cookie": f"token={token}; HttpOnly; Path=/; Max-Age=3600; Secure; SameSite=Strict"
            },
            "body": json.dumps({
                "message": "user added successfully",
                "user": user_data
            })
        }

    # -------------------------
    # DEFAULT ROUTE
    # -------------------------
    return {
        "statusCode": 404,
        "body": json.dumps({
            "message": "Route not found"
        })
    }