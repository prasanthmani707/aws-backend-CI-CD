import json
import boto3
lambda_client = boto3.client("lambda",region_name="us-west-2")


def update_db(email_id, body):


    payload = {
        "rawPath": "/members/add",

        "requestContext": {
            "http": {
                "method": "POST"
            }
        },

        "body": json.dumps({

            "email_id": email_id,

            "name": body.get("name",""),

            "phone": body.get("phone",""),

            "address": body.get("address",{}),

            "source_portal": body.get("source_portal","credit_based_labs"),

            "plan_name": "free"
        })
    }

    response = lambda_client.invoke(

        FunctionName="user_community_subscription",

        InvocationType="RequestResponse",

        Payload=json.dumps(payload)
    )

    lambda_response = json.loads(
        response["Payload"].read().decode("utf-8")
    )

    return lambda_response




