import json
import boto3
from decimal import Decimal
from datetime import datetime
from zoneinfo import ZoneInfo
from botocore.exceptions import ClientError

# DynamoDB
dynamodb = boto3.resource("dynamodb")
wallet_table = dynamodb.Table("User_Wallet")

# Lambda client
lambda_client = boto3.client("lambda")

IST = ZoneInfo("Asia/Kolkata")

LEDGER_LAMBDA_NAME = "Deduct_tracker"


def lambda_handler(event, context):
    print("🔔 DynamoDB Stream Event")
    print(json.dumps(event))

    results = []

    for record in event.get("Records", []):

        if record.get("eventSource") != "aws:dynamodb":
            continue

        event_name = record.get("eventName")
        if event_name not in ("MODIFY","REMOVE"):
            continue

        dynamodb_data = record.get("dynamodb", {})
        old_image = dynamodb_data.get("OldImage")
        new_image = dynamodb_data.get("NewImage")

        # ---- EMAIL ID ----
        email_id = (
            (new_image or {}).get("email_id", {}).get("S")
            or (old_image or {}).get("email_id", {}).get("S")
        )
        email_id = email_id.lower()

        if not email_id:
            continue

        # ---- STORAGE COST CALCULATION ----
        old_cost = Decimal(
            (old_image or {}).get("running_cost", {}).get("N", "0")
        )
        new_cost = Decimal(
            (new_image or {}).get("running_cost", {}).get("N", "0")
        )

        if event_name == "REMOVE":
            amount = old_cost
        else:
            amount = new_cost - old_cost

        if amount <= 0:
            print(f"ℹ️ No storage cost change for {email_id}")
            continue

        updated_time = datetime.now(IST).isoformat()

        try:
            # 🔐 ATOMIC WALLET UPDATE (NO IDENTITY FIELDS STORED)
            response = wallet_table.update_item(
                Key={"email_id": email_id},
                UpdateExpression="""
                    SET previous_balance = current_balance,
                        current_balance = current_balance - :amount,
                        cb_last_updated = :now
                """,
                ConditionExpression="current_balance >= :amount",
                ExpressionAttributeValues={
                    ":amount": amount,
                    ":now": updated_time
                },
                ReturnValues="UPDATED_NEW"
            )

            prev_balance = response["Attributes"]["previous_balance"]
            curr_balance = response["Attributes"]["current_balance"]

            record_out = {
                "email_id": email_id,
                "amount": float(amount),
                "balance_before": float(prev_balance),
                "balance_after": float(curr_balance),
                "source": "storage",
                "status": "SUCCESS",
                "updated_time": updated_time
            }

            print(f"✅ Storage cost deducted: {prev_balance} → {curr_balance}")
            results.append(record_out)

        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                print(f"❌ Insufficient balance for {email_id}")
            else:
                raise

    # ---- INVOKE LEDGER LAMBDA ----
    if results:
        payload = {"records": results}

        print("🚀 Invoking Storage Ledger Lambda")
        print(json.dumps(payload))

        lambda_client.invoke(
            FunctionName=LEDGER_LAMBDA_NAME,
            InvocationType="Event",
            Payload=json.dumps(payload).encode("utf-8")
        )
    else:
        print("⏭️ No storage charges to send")

    return {"status": "processed"}
