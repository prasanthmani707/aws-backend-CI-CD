import json
import boto3
from decimal import Decimal
from datetime import datetime
from zoneinfo import ZoneInfo
from botocore.exceptions import ClientError

# DynamoDB
dynamodb = boto3.resource("dynamodb")
ledger_table = dynamodb.Table("Wallet_ledger")

IST = ZoneInfo("Asia/Kolkata")

def store_ledger_entry(email_id, txn_id, amount, balance_before, balance_after, source, created_at):
    """Store ledger entry with dynamic txn_type based on source"""
    try:
        # 🔥 DYNAMIC txn_type logic:
        # compute/storage → "DEDUCT" | others → "ADD"  
        if source in ["compute", "storage"]:
            txn_type = "DEDUCT"
        else:
            txn_type = "PAY"
        
        ledger_table.put_item(
            Item={
                "email_id": email_id,        # PK
                "tnx_id": txn_id,            # SK  
                "txn_type": txn_type,        # DEDUCT or ADD
                "amount": amount,
                "balance_before": balance_before,
                "balance_after": balance_after,
                "source": source,
                "created_at": created_at
            },
            ConditionExpression="attribute_not_exists(tnx_id)"
        )
        
        print(f"✅ [{txn_type}] Ledger stored | {email_id} | {balance_before} → {balance_after}")
        return True
        
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            print(f"⚠️ Duplicate ledger ignored: {txn_id}")
            return True
        else:
            print(f"❌ Ledger storage failed: {e}")
            raise



def lambda_handler(event, context):
    print(json.dumps(event, indent=2))

    records = event.get("records", [])

    if not records:
        print("ℹ️ No records received")
        return {"status": "NO_RECORDS"}

    for rec in records:

        if rec.get("status") != "SUCCESS":
            continue

        email_id = rec["email_id"]
        amount = Decimal(str(rec["amount"]))
        balance_before = Decimal(str(rec["balance_before"]))
        balance_after = Decimal(str(rec["balance_after"]))
        source = rec.get("source")
        txn_id = f"{rec['updated_time']}"
        created_at = datetime.utcnow().isoformat()

        if store_ledger_entry(email_id, txn_id, amount, balance_before, balance_after, source, created_at):
            print(f"✅ Ledger entry written | {email_id} | {balance_before} → {balance_after}")

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Storage ledger processed"})
    }
