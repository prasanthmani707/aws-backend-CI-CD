import boto3
import json

dynamodb = boto3.client('dynamodb')
WALLET_TABLE = "UserWallet"

def lambda_handler(event, context):
    print("📥 Incoming event:", event)

    # Step 1: Extract input values
    email = event.get("email")
    id_value = event.get("id")                        # 🆕 new input
    course_id = event.get("course_id")
    source_id = event.get("template_file")           # maps to source_id in table
    instance_id = event.get("instance_id")
    status = event.get("status")
    unique_id = event.get("unique_id")               # match based on this
    start_date = event.get("start_date")
    created = event.get("created")

    # Step 2: Validate required fields
    if not all([email and email.strip(), id_value, source_id and source_id.strip()]):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing one or more required fields (email, id, source_id)."})
        }

    # Allow at least one action field to be present
    if not any([instance_id, status, start_date, created]):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Nothing to update — provide at least one of: instance_id, status, start_date, or created."})
        }

    try:
        # Step 3: Fetch current record using new PK + SK
        response = dynamodb.get_item(
            TableName=WALLET_TABLE,
            Key={
                "user_email": {"S": email},
                "id": {"S": id_value}          # 🆕 updated key
            }
        )

        if "Item" not in response:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "UserWallet entry not found."})
            }

        item = response["Item"]
        environment = item.get("environment", {}).get("L", [])

        updated_environment = []
        match_found = False

        # Step 4: Loop through environments and update the matched entry
        for env in environment:
            env_map = env.get("M", {})
            sid = env_map.get("source_id", {}).get("S", "")
            uid = env_map.get("unique_id", {}).get("S", "")

            if sid == source_id and uid == unique_id:
                match_found = True

                if instance_id:
                    existing_instances = env_map.get("instances", {}).get("L", [])
                    instance_ids = [i["S"] for i in existing_instances]

                    if instance_id not in instance_ids:
                        existing_instances.append({"S": instance_id})

                    env_map["instances"] = {"L": existing_instances}

                if status:
                    env_map["status"] = {"S": status}

                if start_date:
                    env_map["start_date"] = {"S": start_date}

                if created is not None:
                    created_bool = str(created).lower() == "true"
                    env_map["created"] = {"BOOL": created_bool}

            updated_environment.append({"M": env_map})

        if not match_found:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": f"source_id '{source_id}' with unique_id '{unique_id}' not found."})
            }

        # Step 5: Update DynamoDB
        dynamodb.update_item(
            TableName=WALLET_TABLE,
            Key={
                "user_email": {"S": email},
                "id": {"S": id_value}       # 🆕 updated key
            },
            UpdateExpression="SET environment = :env",
            ExpressionAttributeValues={
                ":env": {"L": updated_environment}
            }
        )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": f"Updated source_id {source_id} for email={email}, id={id_value}"
            })
        }

    except Exception as e:
        print("❌ Exception occurred:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
