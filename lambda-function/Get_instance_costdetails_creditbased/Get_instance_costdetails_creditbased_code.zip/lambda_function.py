import json
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Pricing_catalog_creditbased')

def lambda_handler(event, context):

    body = json.loads(event['body'])
    instance_type = body['instance_type']

    resource_type = f"ec2#sa-east-1#{instance_type}"
    ebs_resource_type = "EBS#sa-east-1#gp3"

    response1 = table.query(
        KeyConditionExpression=Key('resource_type').eq(resource_type)
    )

    response2 = table.query(
        KeyConditionExpression=Key('resource_type').eq(ebs_resource_type)
    )

    ins_type_price_per_hour = None
    ebs_price_per_hour = None

    if response1['Items']:
        ins_type_price_per_hour = response1['Items'][0]['final_price_per_hour']
        platform_fee = response1['Items'][0]['platform_fee']

    if response2['Items']:
        ebs_price_per_hour = response2['Items'][0]['final_price_per_hour']

    return {
        'statusCode': 200,
        'body': json.dumps({
            'instance_type': instance_type,
            'ins_type_price_per_hour': ins_type_price_per_hour,
            'platform_fee': platform_fee,
            'EBS_price_per_hour': ebs_price_per_hour
        })
    }