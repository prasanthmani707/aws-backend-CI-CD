import boto3
from decimal import Decimal
import logging

# -----------------------------------
# LOGGING
# -----------------------------------

logging.basicConfig(level=logging.INFO)

# -----------------------------------
# DYNAMODB
# -----------------------------------

dynamodb = boto3.resource('dynamodb')

# OLD TABLE
source_table = dynamodb.Table('storagetestdb')

# NEW TABLE
target_table = dynamodb.Table('Storage_Credits_Creditbased')


# -----------------------------------
# HELPERS
# -----------------------------------

def to_decimal(value):

    if value is None:
        return Decimal("0")

    if value == "":
        return Decimal("0")

    return Decimal(str(value))


# MULTIPLY BY 100
def convert_to_credits(value):

    return to_decimal(value) * Decimal("100")


# -----------------------------------
# TRANSFORM OLD -> NEW
# -----------------------------------

def transform_item(old_item):

    new_item = {

        # SAME FIELDS
        "volume_id": old_item.get("volume_id"),

        "email_id": old_item.get("email_id"),

        "end_time": old_item.get("end_time"),

        "instance_id": old_item.get("instance_id"),

        "instance_name": old_item.get("instance_name"),

        "last_duration_seconds": old_item.get(
            "last_duration_seconds"
        ),

        "last_updated_time": old_item.get(
            "last_updated_time"
        ),

        "size_gb": old_item.get("size_gb"),

        "start_time": old_item.get("start_time"),

        "status": old_item.get("status"),

        "total_duration_seconds": old_item.get(
            "total_duration_seconds"
        ),

        "volume_type": old_item.get("volume_type"),

        # -----------------------------------
        # CONVERT COST -> CREDITS
        # -----------------------------------

        "credits_per_gb_hr": convert_to_credits(
            old_item.get("price_per_gb_hr", 0)
        ),

        "running_credits": convert_to_credits(
            old_item.get("running_cost", 0)
        ),
    }

    # REMOVE NONE VALUES
    cleaned_item = {
        k: v for k, v in new_item.items()
        if v is not None
    }

    return cleaned_item


# -----------------------------------
# MAIN MIGRATION
# -----------------------------------

def migrate_data():

    scan_kwargs = {}

    done = False

    start_key = None

    total_processed = 0

    logging.info("Migration started...")

    with target_table.batch_writer() as batch:

        while not done:

            # PAGINATION
            if start_key:

                scan_kwargs["ExclusiveStartKey"] = start_key

            # READ FROM OLD TABLE
            response = source_table.scan(**scan_kwargs)

            items = response.get("Items", [])

            logging.info(
                f"Fetched {len(items)} items"
            )

            for item in items:

                try:

                    # TRANSFORM
                    new_item = transform_item(item)

                    # WRITE TO NEW TABLE
                    batch.put_item(Item=new_item)

                    total_processed += 1

                    # LOG EVERY 1000
                    if total_processed % 1000 == 0:

                        logging.info(
                            f"Processed {total_processed} items"
                        )

                except Exception as e:

                    logging.error(
                        f"Error processing item: {str(e)}"
                    )

            # NEXT PAGE
            start_key = response.get(
                "LastEvaluatedKey",
                None
            )

            done = start_key is None

    logging.info(
        f"Migration completed. Total processed: {total_processed}"
    )


# -----------------------------------
# LAMBDA ENTRY
# -----------------------------------

def lambda_handler(event, context):

    try:

        migrate_data()

        return {
            "statusCode": 200,
            "body": "Migration completed successfully"
        }

    except Exception as e:

        logging.error(str(e))

        return {
            "statusCode": 500,
            "body": str(e)
        }


# -----------------------------------
# LOCAL RUN
# -----------------------------------
