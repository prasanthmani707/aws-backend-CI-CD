import json
import boto3
import urllib.request
import os

# Clients
lambda_client = boto3.client('lambda')
ssm = boto3.client('ssm')

converter_key = os.environ["COVERTER_KEY"]
target_lambda = "EC2_user_quota_checker_creditbased"

# SSM parameter names
USD_TO_INR_PARAM = "/exchange/usd_to_inr"
INR_TO_USD_PARAM = "/exchange/inr_to_usd"


def get_rate(base_currency, target_currency):

    url = f"https://v6.exchangerate-api.com/v6/{converter_key}/latest/{base_currency}"

    with urllib.request.urlopen(url) as response:
        data = json.loads(response.read())

    return str(data["conversion_rates"][target_currency])


def lambda_handler(event, context):

    # Fetch exchange rates
    usd_to_inr = get_rate("USD", "INR")
    inr_to_usd = get_rate("INR", "USD")

    # -----------------------------
    # Store in SSM Parameter Store
    # -----------------------------
    ssm.put_parameter(
        Name=USD_TO_INR_PARAM,
        Value=usd_to_inr,
        Type="String",
        Overwrite=True
    )

    ssm.put_parameter(
        Name=INR_TO_USD_PARAM,
        Value=inr_to_usd,
        Type="String",
        Overwrite=True
    )

    # -----------------------------------
    # Update environment variable in Lambda
    # -----------------------------------
    response = lambda_client.get_function_configuration(
        FunctionName=target_lambda
    )

    env_vars = response.get("Environment", {}).get("Variables", {})

    # Add/Update env variable
    env_vars["USD_PER_INR"] = inr_to_usd

    lambda_client.update_function_configuration(
        FunctionName=target_lambda,
        Environment={
            "Variables": env_vars
        }
    )

    return {
        "statusCode": 200,
        "USD_to_INR": usd_to_inr,
        "INR_to_USD": inr_to_usd
    }
    