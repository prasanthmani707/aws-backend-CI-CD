import boto3
from decimal import Decimal

region = "us-west-2"
dynamodb = boto3.resource('dynamodb', region_name=region)
table = dynamodb.Table('CommunityMembers')

def apply_member_discount(email_id, amount):
    """
    Returns:
        final_amount (Decimal): amount after discount
        discount_amount (Decimal): discount applied
    """
    response = table.get_item(Key={'email': email_id})
    
    if response.get('Item'):
        # 25% discount
        discount_amount = amount * Decimal('0.25')
        final_amount = amount - discount_amount
        print(f"Community member discount applied: ${discount_amount}, final amount: ${final_amount}")
    else:
        final_amount = amount
        discount_amount = Decimal('0')
        print(f"No discount applied, amount to pay: ${final_amount}")
    
    return final_amount, discount_amount