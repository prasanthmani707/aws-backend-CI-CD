import json
import boto3
from decimal import Decimal
from datetime import datetime
from zoneinfo import ZoneInfo
from botocore.exceptions import ClientError
from community_member_check import apply_member_discount

dynamodb = boto3.resource("dynamodb")
wallet_table = dynamodb.Table("user_wallet_creditbased")

# Lambda client
lambda_client = boto3.client("lambda")

HISTORY_LAMBDA_NAME = "history_tracker_creditbased"
INSTANCE_TRACKER_LAMBDA_NAME = "Instance_tracker_creditbased"


def lambda_handler(event, context):
    print("🔔 DynamoDB Stream Event")
    print(json.dumps(event))

    results = []

    for record in event.get("Records", []):

        if record.get("eventSource") != "aws:dynamodb":
            continue

        event_name = record.get("eventName")
        if event_name not in ("MODIFY","REMOVE"):
            continue

        dynamodb_data = record.get("dynamodb", {})
        old_image = dynamodb_data.get("OldImage")
        new_image = dynamodb_data.get("NewImage")
        instance_id = ((new_image or {}).get("instance_id", {}).get("S")or (old_image or {}).get("instance_id", {}).get("S"))
        instance_name = (new_image or {}).get("instance_name", {}).get("S")
        last_duration_seconds = (new_image or {}).get("last_duration_seconds", {}).get("N")
        print(f"time duration for cost {last_duration_seconds}")
        # ---- EMAIL ID ----
        email_id = (
            (new_image or {}).get("email_id", {}).get("S")
            or (old_image or {}).get("email_id", {}).get("S")
        )
        email_id = email_id.lower()

        if not email_id:
            continue

        # ---- STORAGE COST CALCULATION ----
        old_cost = Decimal(
            (old_image or {}).get("running_cost", {}).get("N", "0")
        )
        new_cost = Decimal(
            (new_image or {}).get("running_cost", {}).get("N", "0")
        )

        if event_name == "REMOVE":
            amount = old_cost
        else:
            amount = new_cost - old_cost

        if amount <= 0:
            print(f"ℹ️ No storage cost change for {email_id}")
            continue

        updated_time = datetime.utcnow().isoformat()
        print(f"💰 Calculated storage cost: ${amount}")
        original_amount = amount  # Save the original cost before discount
        amount, discount_amount = apply_member_discount(email_id, amount)
        print(f"Original amount: ${original_amount}, Discount applied: ${discount_amount}, Final amount to charge: ${amount}")
        print(f"Amount to pay: ${amount}")
        try:
            # 🔐 ATOMIC WALLET UPDATE (NO IDENTITY FIELDS STORED)
            response = wallet_table.update_item(
                Key={"email_id": email_id},
                UpdateExpression="""
                    SET previous_balance = current_balance,
                        current_balance = current_balance - :amount,
                        cb_last_updated = :now
                """,
                ConditionExpression="current_balance >= :amount",
                ExpressionAttributeValues={
                    ":amount": amount,
                    ":now": updated_time
                },
                ReturnValues="UPDATED_NEW"
            )

            prev_balance = response["Attributes"]["previous_balance"]
            curr_balance = response["Attributes"]["current_balance"]

            record_out = {
                "email_id": email_id,
                "instance_id": instance_id,
                "instance_name": instance_name,
                "amount": float(amount),
                "used_time":last_duration_seconds,
                "original_amount": float(original_amount),   # <-- original
                "discount_amount": float(discount_amount),  
                "balance_before": float(prev_balance),
                "balance_after": float(curr_balance),
                "source": "storage",
                "status": "SUCCESS",
                "updated_time": updated_time
            }
            

            print(f"✅ Storage cost deducted: {prev_balance} → {curr_balance}")
            results.append(record_out)

        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                print(f"❌ Insufficient balance for {email_id}")
            else:
                raise

    # ---- INVOKE LEDGER LAMBDA ----
    if results:
        print(f"🚀 Invoking Ledger with {len(results)} successful charges")
        payload = json.dumps({"records": results}).encode("utf-8")
        lambda_name =[
            HISTORY_LAMBDA_NAME,
            INSTANCE_TRACKER_LAMBDA_NAME,
        ]
        print(f"Invoke → lambda_name: {len(lambda_name)}")
        for name in lambda_name:
            lambda_client.invoke(
                FunctionName=name,
                InvocationType="Event",
                Payload=payload,
            )
    else:
        print("ℹ️ No wallet updates done")

    return {"status": "processed"}
