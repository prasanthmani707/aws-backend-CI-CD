import json
import boto3
import uuid
from urllib.parse import parse_qs
from datetime import datetime

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("SplunkVersions")

def response(code, body):
    return {
        "statusCode": code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body)
    }

def parse_body(raw_body):
    if raw_body is None:
        return {}
    if isinstance(raw_body, (dict, list)):
        return raw_body

    body_str = str(raw_body).strip()
    if not body_str:
        return {}

    # Try JSON string first
    try:
        return json.loads(body_str)
    except Exception:
        pass

    # Fallback: key=value&key2=value2 (string form)
    parsed = parse_qs(body_str, keep_blank_values=True)
    return {k: (v[0] if len(v) == 1 else v) for k, v in parsed.items()}

def lambda_handler(event, context):
    method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method") or event.get("method")
    if not method:
        return response(400, {"error": "httpMethod missing. Expected API Gateway event or include method in test event."})
    path_id = event.get("pathParameters", {}).get("id")

    try:

        # CREATE
        if method == "POST":
            body = parse_body(event.get("body"))

            required = ["splunk_version", "os_type", "region", "account_id"]
            for r in required:
                if r not in body:
                    return response(400, {"error": f"{r} required"})

            item = {
                "package_id": str(uuid.uuid4()),
                "splunk_version": body["splunk_version"],
                "os_type": body["os_type"],
                "description": body.get("description", ""),
                "ami_id": body.get("ami_id", ""),
                "template_files": body.get("template_files", []),
                "region": body["region"],
                "account_id": body["account_id"],
                "status": "active",
                "created_at": datetime.utcnow().isoformat(),
                "updated_at": datetime.utcnow().isoformat()
            }

            table.put_item(Item=item)
            return response(201, item)

        # LIST
        if method == "GET" and not path_id:
            data = table.scan()
            return response(200, data["Items"])

        # READ
        if method == "GET" and path_id:
            data = table.get_item(Key={"package_id": path_id})
            return response(200, data.get("Item", {}))

        # UPDATE
        if method == "PUT":
            body = parse_body(event.get("body"))

            # Ensure package_id exists before updating
            existing = table.get_item(Key={"package_id": path_id})
            if "Item" not in existing:
                return response(404, {"error": "package_id not available"})

            # Only update fields provided in the request body
            updatable_fields = ["splunk_version", "os_type", "description", "ami_id", "template_files", "region", "account_id"]
            set_clauses = []
            expr_values = {}
            expr_names = {}

            for field in updatable_fields:
                if field in body:
                    name_key = f"#{field}" if field == "region" else None
                    value_key = f":{field}"

                    if name_key:
                        expr_names[name_key] = field
                        set_clauses.append(f"{name_key}={value_key}")
                    else:
                        set_clauses.append(f"{field}={value_key}")

                    expr_values[value_key] = body[field]

            # Always update updated_at
            set_clauses.append("updated_at=:u")
            expr_values[":u"] = datetime.utcnow().isoformat()

            if len(set_clauses) == 1:  # only updated_at present
                return response(400, {"error": "No updatable fields provided"})

            update = table.update_item(
                Key={"package_id": path_id},
                UpdateExpression="SET " + ", ".join(set_clauses),
                ExpressionAttributeNames=expr_names if expr_names else None,
                ExpressionAttributeValues=expr_values,
                ReturnValues="ALL_NEW"
            )

            return response(200, update["Attributes"])

        # DELETE
        if method == "DELETE":
            table.delete_item(Key={"package_id": path_id})
            return response(200, {"message": "Deleted"})

        return response(400, {"error": "Invalid request"})

    except Exception as e:
        return response(500, {"error": str(e)})
