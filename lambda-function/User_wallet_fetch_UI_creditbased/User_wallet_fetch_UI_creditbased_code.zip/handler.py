import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('user_wallet_creditbased')

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        email_id = body.get('email_id')

        if not email_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid Request')
            }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid Request')
        }

    try:
        response = table.get_item(
            Key={'email_id': email_id}
        )

        if 'Item' in response:
            current_balance = response['Item'].get('current_balance', 0)
            expire_at = response['Item'].get('expire_at',"")
            # Convert Decimal to float
            if isinstance(current_balance, Decimal):
                current_balance = float(current_balance)

            return {
                'statusCode': 200,
                'body': json.dumps({
                    'current_balance': current_balance,
                    'expire_at':expire_at

                })
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps('Email ID does not exist')
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error', 'details': str(e)})
        }
