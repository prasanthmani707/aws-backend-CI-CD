import boto3
import json
import os

def lambda_handler(event, context):
    print(f"📩 State-change event: {json.dumps(event)}")

    try:
        instance_id = event['detail']['instance-id']
        region = event['region']
        state = event['detail']['state']

        # Clean only if stopped or terminated
        if state not in ["stopped", "terminated"]:
            print(f"Ignoring state: {state}")
            return {
                'statusCode': 200,
                'body': f"Ignored state {state}"
            }

        print(f"🔍 Instance {instance_id} is {state}. Beginning cleanup...")

        events = boto3.client('events', region_name=region)
        scheduler = boto3.client('scheduler', region_name=region)

        prefix = f"Stop-{instance_id}-"
        print(f"Searching rules and schedules with prefix: {prefix}")

        # ----------------------------------------------------
        # 1️⃣ DELETE EventBridge Scheduler Schedules (NEW)
        # ----------------------------------------------------
        try:
            schedule_pages = scheduler.list_schedules(NamePrefix=prefix)

            if "Schedules" in schedule_pages:
                for schedule in schedule_pages["Schedules"]:
                    schedule_name = schedule["Name"]
                    print(f"🗑 Found Scheduler schedule: {schedule_name}")

                    try:
                        scheduler.delete_schedule(Name=schedule_name)
                        print(f"✔ Deleted Scheduler schedule: {schedule_name}")
                    except scheduler.exceptions.ResourceNotFoundException:
                        print(f"⚠ Scheduler schedule not found: {schedule_name}")
                    except Exception as e:
                        print(f"❌ Error deleting schedule {schedule_name}: {e}")
        except Exception as e:
            print(f"⚠ Scheduler lookup error: {e}")

        # ----------------------------------------------------
        # 2️⃣ DELETE EventBridge Rules (OLD)
        # ----------------------------------------------------
        paginator = events.get_paginator('list_rules')

        for page in paginator.paginate(NamePrefix=prefix):
            for rule in page.get('Rules', []):
                rule_name = rule['Name']
                print(f"🗑 Found EventBridge rule: {rule_name}")

                # Remove targets safely
                try:
                    targets = events.list_targets_by_rule(Rule=rule_name)
                    if targets["Targets"]:
                        target_ids = [t["Id"] for t in targets["Targets"]]
                        events.remove_targets(Rule=rule_name, Ids=target_ids)
                        print(f"✔ Removed targets from rule: {rule_name}")
                except Exception as e:
                    print(f"⚠ Error removing targets: {e}")

                # Delete rule
                try:
                    events.delete_rule(Name=rule_name)
                    print(f"✔ Deleted EventBridge rule: {rule_name}")
                except Exception as e:
                    print(f"❌ Error deleting rule {rule_name}: {e}")

        return {
            'statusCode': 200,
            'body': f"Cleanup completed for instance {instance_id}"
        }

    except Exception as e:
        print(f"❌ Error: {e}")
        return {
            'statusCode': 500,
            'body': f"Error: {str(e)}"
        }
