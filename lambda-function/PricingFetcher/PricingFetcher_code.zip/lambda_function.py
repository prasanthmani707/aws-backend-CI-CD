import boto3
import json
import requests
import os
from datetime import datetime

# -------------------------------------------------
# AWS PRICING CLIENT
# -------------------------------------------------
LAMBDA_REGION = os.environ.get("AWS_REGION")
pricing = boto3.client("pricing", region_name=LAMBDA_REGION)

# -------------------------------------------------
# INSTANCE CONFIG
# -------------------------------------------------
INSTANCE_CONFIG = {
    "t3.medium": {
        "os": "RHEL",
        "location": "US West (N. California)"
    },
    "t3.xlarge": {
        "os": "RHEL",
        "location": "US West (N. California)"
    },
    "m4.large": {
        "os": "Windows",
        "location": "US West (N. California)"
    }
}

# -------------------------------------------------
# ZOHO ENV VARIABLES
# -------------------------------------------------
ZOHO_CLIENT_ID = os.environ["ZOHO_CLIENT_ID"]
ZOHO_CLIENT_SECRET = os.environ["ZOHO_CLIENT_SECRET"]
ZOHO_REFRESH_TOKEN = os.environ["ZOHO_REFRESH_TOKEN"]
ZOHO_SHEET_ID = os.environ["ZOHO_SHEET_ID"]

# -------------------------------------------------
# GET ZOHO ACCESS TOKEN
# -------------------------------------------------
def get_zoho_access_token():
    url = "https://accounts.zoho.in/oauth/v2/token"
    params = {
        "client_id": ZOHO_CLIENT_ID,
        "client_secret": ZOHO_CLIENT_SECRET,
        "refresh_token": ZOHO_REFRESH_TOKEN,
        "grant_type": "refresh_token"
    }

    response = requests.post(url, params=params, timeout=10)
    data = response.json()

    if "access_token" not in data:
        raise Exception(f"Zoho OAuth failed: {data}")

    return data["access_token"]

# -------------------------------------------------
# GET EC2 PRICE (LICENSE INCLUDED - FIXED)
# -------------------------------------------------
def get_ec2_price(instance_type):
    cfg = INSTANCE_CONFIG[instance_type]

    filters = [
        {"Type": "TERM_MATCH", "Field": "instanceType", "Value": instance_type},
        {"Type": "TERM_MATCH", "Field": "location", "Value": cfg["location"]},
        {"Type": "TERM_MATCH", "Field": "operatingSystem", "Value": cfg["os"]},
        {"Type": "TERM_MATCH", "Field": "preInstalledSw", "Value": "NA"},
        {"Type": "TERM_MATCH", "Field": "tenancy", "Value": "Shared"},
        {"Type": "TERM_MATCH", "Field": "capacitystatus", "Value": "Used"}
    ]

    # ✅ Windows-only license filter (CORRECT VALUE)
    if cfg["os"] == "Windows":
        filters.append({
            "Type": "TERM_MATCH",
            "Field": "licenseModel",
            "Value": "No License required"
        })

    response = pricing.get_products(
        ServiceCode="AmazonEC2",
        Filters=filters,
        MaxResults=1
    )

    if not response.get("PriceList"):
        raise Exception(
            f"No pricing data found for {instance_type} ({cfg['os']})"
        )

    price_item = json.loads(response["PriceList"][0])
    terms = price_item["terms"]["OnDemand"]

    for term in terms.values():
        for dim in term["priceDimensions"].values():
            return float(dim["pricePerUnit"]["USD"])

# -------------------------------------------------
# USD → INR (GOOGLE-LIKE RATE - FIXED)
# -------------------------------------------------
def get_usd_to_inr():
    url = "https://api.frankfurter.app/latest?from=USD&to=INR"
    response = requests.get(url, timeout=10)
    data = response.json()

    inr = data.get("rates", {}).get("INR")
    if not inr:
        raise Exception(f"INR rate not found in response: {data}")

    return float(inr)

# -------------------------------------------------
# EBS gp3 PRICE (California)
# -------------------------------------------------
def get_ebs_gp3_price():
    response = pricing.get_products(
        ServiceCode="AmazonEC2",
        Filters=[
            {"Type": "TERM_MATCH", "Field": "productFamily", "Value": "Storage"},
            {"Type": "TERM_MATCH", "Field": "volumeApiName", "Value": "gp3"},
            {"Type": "TERM_MATCH", "Field": "location", "Value": "US West (N. California)"}
        ],
        MaxResults=1
    )

    price_item = json.loads(response["PriceList"][0])
    terms = price_item["terms"]["OnDemand"]

    for term in terms.values():
        for dim in term["priceDimensions"].values():
            return float(dim["pricePerUnit"]["USD"])

# -------------------------------------------------
# UPDATE EC2 ROWS
# -------------------------------------------------
def update_zoho_sheet(rows, access_token):
    headers = {
        "Authorization": f"Zoho-oauthtoken {access_token}",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    base_url = f"https://sheet.zoho.in/api/v2/{ZOHO_SHEET_ID}"
    column_array = [1, 2, 3, 4, 5]
    start_row = 2

    for index, row in enumerate(rows):
        payload = {
            "method": "row.content.set",
            "worksheet_name": "AWS EC2 Live Cost",
            "row": start_row + index,
            "column_array": json.dumps(column_array),
            "data_array": json.dumps([
                row["Instance_Type"],
                row["Operating_System"],
                row["Region"],
                str(row["Cost_Per_Hour_USD"]),
                row["Last_Updated"]
            ])
        }

        requests.post(base_url, headers=headers, data=payload, timeout=10)

# -------------------------------------------------
# UPDATE EBS + CURRENCY
# -------------------------------------------------
def update_ebs_currency(access_token, usd_inr, gp3_month):
    headers = {
        "Authorization": f"Zoho-oauthtoken {access_token}",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    payload = {
        "method": "row.content.set",
        "worksheet_name": "AWS EC2 Live Cost",
        "row": 2,
        "column_array": json.dumps([6, 7]),
        "data_array": json.dumps([
            round(usd_inr, 2),
            round(gp3_month, 4)
        ])
    }

    requests.post(
        f"https://sheet.zoho.in/api/v2/{ZOHO_SHEET_ID}",
        headers=headers,
        data=payload,
        timeout=10
    )

# -------------------------------------------------
# LAMBDA HANDLER
# -------------------------------------------------
def lambda_handler(event, context):
    access_token = get_zoho_access_token()
    today = datetime.utcnow().strftime("%Y-%m-%d")

    rows = []
    for instance_type, cfg in INSTANCE_CONFIG.items():
        rows.append({
            "Instance_Type": instance_type,
            "Operating_System": cfg["os"],
            "Region": cfg["location"],
            "Cost_Per_Hour_USD": get_ec2_price(instance_type),
            "Last_Updated": today
        })

    update_zoho_sheet(rows, access_token)

    usd_inr = get_usd_to_inr()
    gp3_month = get_ebs_gp3_price()
    update_ebs_currency(access_token, usd_inr, gp3_month)

    return {"status": "SUCCESS"}
