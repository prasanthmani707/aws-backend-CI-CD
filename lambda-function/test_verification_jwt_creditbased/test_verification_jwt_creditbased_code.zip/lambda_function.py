import json
import jwt

SECRET_KEY = "my-secret-key"


def lambda_handler(event, context):

    try:
        print("EVENT RECEIVED:", json.dumps(event))

        # Get headers
        headers = event.get("headers", {})
        print("HEADERS:", headers)

        cookie = headers.get("Cookie", "")
        print("COOKIE STRING:", cookie)

        token = None

        # Extract token from cookie
        for item in cookie.split(";"):
            print("COOKIE PART:", item)

            if "token=" in item:
                token = item.split("=")[1].strip()
                print("EXTRACTED TOKEN:", token)

        if not token:
            print("TOKEN NOT FOUND")
            return {
                "statusCode": 401,
                "body": json.dumps({"message": "Token missing"})
            }

        # Decode BEFORE verification (DEBUG ONLY)
        try:
            decoded_preview = jwt.decode(token, options={"verify_signature": False})
            print("TOKEN PAYLOAD (NO VERIFY):", decoded_preview)
        except Exception as e:
            print("DECODE PREVIEW ERROR:", str(e))

        # Verify JWT
        decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        print("TOKEN VERIFIED PAYLOAD:", decoded)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Token valid",
                "user": decoded
            })
        }

    except jwt.ExpiredSignatureError:
        print("TOKEN EXPIRED")
        return {
            "statusCode": 401,
            "body": json.dumps({"message": "Token expired"})
        }

    except jwt.InvalidTokenError:
        print("INVALID TOKEN")
        return {
            "statusCode": 401,
            "body": json.dumps({"message": "Invalid token"})
        }

    except Exception as e:
        print("ERROR:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"message": str(e)})
        }