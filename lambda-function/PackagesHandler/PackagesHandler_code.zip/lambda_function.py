import json
import boto3
import os
import logging

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.client('dynamodb')
TABLE_NAME = os.environ.get('TABLE_NAME', 'Packages')


def lambda_handler(event, context):
    logger.info("=== Lambda Triggered ===")
    logger.info(f"Incoming Event: {json.dumps(event)}")

    method = event.get("requestContext", {}).get("http", {}).get("method", "").upper()
    logger.info(f"HTTP Method: {method}")

    body = {}
    if event.get("body"):
        try:
            body = json.loads(event["body"])
            logger.info("Parsed JSON body successfully.")
        except Exception as e:
            logger.error(f"Invalid JSON in request body: {str(e)}")
            return respond(400, f"Invalid JSON body: {str(e)}")

    env_id = event.get("queryStringParameters", {}).get("environment_id")

    try:
        if method == 'GET':
            return get_package(env_id)

        elif method == 'POST':
            if not body:
                logger.warning("POST request missing body")
                return respond(400, "Request body is empty")
            return create_package(body)

        elif method == 'PUT':
            if not body:
                logger.warning("PUT request missing body")
                return respond(400, "Request body is empty")
            return update_package(body)

        elif method == 'DELETE':
            if not env_id:
                logger.warning("DELETE request missing environment_id")
                return respond(400, "Missing environment_id in query params")
            return delete_package(env_id)

        logger.warning(f"Unsupported HTTP method: {method}")
        return respond(405, f"Method {method} not allowed")

    except Exception as e:
        logger.exception("Unhandled error occurred during execution")
        return respond(500, f"Internal Server Error: {str(e)}")


# ---------- CRUD FUNCTIONS ----------

def get_package(env_id):
    try:
        if env_id:
            # Fetch single environment
            logger.info(f"Fetching item with environment_id: {env_id}")
            resp = dynamodb.get_item(
                TableName=TABLE_NAME,
                Key={'environment_id': {'S': env_id}}
            )
            item = resp.get('Item')
            if not item:
                logger.warning(f"No package found for ID: {env_id}")
                return respond(404, "Package not found")
            logger.info("Package retrieved successfully.")
            return respond(200, convert_dynamo_to_json(item))
        else:
            # Fetch all environments
            logger.info("Fetching all environments")
            resp = dynamodb.scan(TableName=TABLE_NAME)
            items = resp.get('Items', [])
            all_data = [convert_dynamo_to_json(item) for item in items]
            logger.info(f"Total environments fetched: {len(all_data)}")
            return respond(200, all_data)

    except Exception as e:
        logger.exception("Error while retrieving package")
        return respond(500, f"Get error: {str(e)}")


def create_package(data):
    try:
        logger.info(f"Creating package: {data.get('environment_id')}")
        item = convert_json_to_dynamo(data)
        logger.debug(f"DynamoDB formatted item: {item}")
        dynamodb.put_item(
            TableName=TABLE_NAME,
            Item=item
        )
        logger.info("Package created successfully.")
        return respond(201, "Package created successfully")
    except Exception as e:
        logger.exception("Error while creating package")
        return respond(500, f"Create error: {str(e)}")


def update_package(data):
    try:
        logger.info(f"Updating package: {data.get('environment_id')}")
        item = convert_json_to_dynamo(data)
        logger.debug(f"DynamoDB formatted item: {item}")
        dynamodb.put_item(
            TableName=TABLE_NAME,
            Item=item
        )
        logger.info("Package updated successfully.")
        return respond(200, "Package updated successfully")
    except Exception as e:
        logger.exception("Error while updating package")
        return respond(500, f"Update error: {str(e)}")

def delete_package(env_id):
    try:
        logger.info(f"Deleting package with environment_id: {env_id}")

        # First, check if the item exists
        existing = dynamodb.get_item(
            TableName=TABLE_NAME,
            Key={'environment_id': {'S': env_id}}
        )

        if 'Item' not in existing:
            logger.warning(f"Package with environment_id '{env_id}' not found for deletion")
            return respond(404, f"Package with environment_id '{env_id}' does not exist")

        # Proceed to delete
        dynamodb.delete_item(
            TableName=TABLE_NAME,
            Key={'environment_id': {'S': env_id}}
        )
        logger.info("Package deleted successfully.")
        return respond(200, "Package deleted successfully")

    except Exception as e:
        logger.exception("Error while deleting package")
        return respond(500, f"Delete error: {str(e)}")

# ---------- HELPERS ----------

def respond(code, message):
    """Unified response formatter"""
    logger.info(f"Responding with status {code}")
    return {
        "statusCode": code,
        "body": json.dumps({"message": message} if isinstance(message, str) else message),
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        }
    }


def convert_json_to_dynamo(data):
    """Recursively convert JSON to DynamoDB format."""
    def convert(value):
        if isinstance(value, str):
            return {'S': value}
        elif isinstance(value, bool):
            return {'BOOL': value}
        elif isinstance(value, int) or isinstance(value, float):
            return {'N': str(value)}
        elif isinstance(value, list):
            return {'L': [convert(v) for v in value]}
        elif isinstance(value, dict):
            return {'M': {k: convert(v) for k, v in value.items()}}
        else:
            return {'NULL': True}
    converted = {k: convert(v) for k, v in data.items()}
    logger.debug(f"Converted JSON to DynamoDB format: {converted}")
    return converted


def convert_dynamo_to_json(dynamo_item):
    """Recursively convert DynamoDB item to JSON."""
    def convert(val):
        if 'S' in val:
            return val['S']
        elif 'N' in val:
            return float(val['N']) if '.' in val['N'] else int(val['N'])
        elif 'BOOL' in val:
            return val['BOOL']
        elif 'L' in val:
            return [convert(v) for v in val['L']]
        elif 'M' in val:
            return {k: convert(v) for k, v in val['M'].items()}
        elif 'NULL' in val:
            return None
    converted = {k: convert(v) for k, v in dynamo_item.items()}
    logger.debug(f"Converted DynamoDB to JSON: {converted}")
    return converted
