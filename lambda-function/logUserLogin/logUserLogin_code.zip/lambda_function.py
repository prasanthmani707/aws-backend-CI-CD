import json
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('GoogleLogins')

def lambda_handler(event, context):
    print("📩 Received event:", event)

    try:
        body = json.loads(event['body'])
        email = body.get('email')
        name = body.get('name')
        login_time = body.get('login_time') or datetime.utcnow().isoformat()

        print(f"🔐 Login request - Email: {email}, Name: {name}, Time: {login_time}")

        if not email or not name:
            print("⚠️ Missing email or name in request")
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing email or name'})}

        print(f"📊 Updating login data in DynamoDB for {email}")

        response = table.update_item(
            Key={'email': email},
            UpdateExpression="""
                SET #nm = :name,
                    last_login = :login,
                    logins = if_not_exists(logins, :zero) + :inc
            """,
            ExpressionAttributeNames={'#nm': 'name'},
            ExpressionAttributeValues={
                ':name': name,
                ':login': login_time,
                ':zero': 0,
                ':inc': 1
            }
        )
        print(f"📦 DynamoDB update response: {response}")

        print("✅ Login tracked and DynamoDB updated.")
        return {'statusCode': 200, 'body': json.dumps({'message': 'Login tracked'})}

    except Exception as e:
        print("❌ Exception occurred:", str(e))
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}
