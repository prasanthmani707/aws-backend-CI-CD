import boto3
import json
from boto3.dynamodb.types import TypeDeserializer

def lambda_handler(event, context):
    # S3 bucket region
    s3 = boto3.client('s3', region_name='us-east-1')

    # DynamoDB table region
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    bucket = "splunklab-dev"
    tables = ["Admin", "SplunkVersions", "ManageEC2Instances", "Packages", "ProvisioningStatus","UserWallet"]

    deserializer = TypeDeserializer()

    for table_name in tables:
        table = dynamodb.Table(table_name)
        key = f"dynamodb-table-backup/{table_name}/{table_name}_data.json"
        
        # Download JSON from S3 and decode safely
        response = s3.get_object(Bucket=bucket, Key=key)
        data = json.loads(response['Body'].read().decode('utf-8', errors='ignore'))
        
        # Extract actual items
        items = data.get("Items", [])
        
        # Import into DynamoDB
        with table.batch_writer() as batch:
            for item in items:
                # Convert DynamoDB JSON types to Python native types
                python_item = {k: deserializer.deserialize(v) for k, v in item.items()}
                batch.put_item(Item=python_item)
        
        print(f"{table_name} imported successfully")
    
    return {
        "statusCode": 200,
        "body": json.dumps("All tables imported successfully!")
    }
