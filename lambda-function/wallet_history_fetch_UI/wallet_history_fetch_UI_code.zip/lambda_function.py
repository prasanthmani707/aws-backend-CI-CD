import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal

dynamo = boto3.resource('dynamodb')
table = dynamo.Table('Wallet_ledger')

def decimal_to_native(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, list):
        return [decimal_to_native(i) for i in obj]
    if isinstance(obj, dict):
        return {k: decimal_to_native(v) for k, v in obj.items()}
    return obj

def lambda_handler(event, context):
    try:
        body = event.get('body', event)
        if isinstance(body, str):
            body = json.loads(body)
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid request body')
        }

    try:
        email = body['email_id']

        response = table.query(
            KeyConditionExpression=Key('email_id').eq(email),
            ScanIndexForward=False  # newest first
        )

        items = decimal_to_native(response.get('Items', []))

        return {
            'statusCode': 200,
            'body': json.dumps(items)
        }

    except Exception as e:
        print("Error:", e)
        return {
            'statusCode': 500,
            'body': json.dumps(str(e))
        }
