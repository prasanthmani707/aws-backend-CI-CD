import json
import re
import requests
import time

ZOHO_WEBHOOK = "https://flow.zoho.in/60031326371/flow/webhook/incoming?zapikey=1001.bbc7fcbf21329f7816a3d503449283f0.67feec03efe84f791829ea9f7510e89d&isdebug=false"


# -----------------------------
# Helper: normalize course_name
# -----------------------------
def normalize_course_name(value):
    if isinstance(value, list) and value:
        return value[0]
    return value


def lambda_handler(event, context):

    # -----------------------------------
    # Handle API Gateway / direct invoke
    # -----------------------------------
    if "body" in event:
        try:
            event = json.loads(event["body"])
        except Exception:
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Invalid JSON body"})
            }

    # -------- RAW INPUT --------
    raw_emails = event.get("email", "")
    raw_environment = event.get("environment", "")
    premium_raw = event.get("premium_bundle_lab", "false")
    course_name = normalize_course_name(event.get("course_name", ""))

    # Ensure email is provided
    if not raw_emails:
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Email is required"})
        }

    # -------- EMAIL SPLIT --------
    emails = re.findall(
        r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        raw_emails
    )

    # -------- ENVIRONMENT CLEAN --------
    environments = re.findall(
        r"[a-zA-Z0-9_\-]+\.template",
        raw_environment
    )

    # Ensure valid environment
    if not environments:
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Valid environment is required"})
        }

    # -------- PREMIUM FLAG --------
    premium_bundle_lab = str(premium_raw).strip().lower() == "true"

    results = []

    # -------- LOOP → WEBHOOK CALL --------
    for email in emails:
        payload = {
            "user_email": email,
            "course_id": course_name,
            "premium_bundle_lab": premium_bundle_lab,
            "environment": environments
        }

        try:
            response = requests.post(
                ZOHO_WEBHOOK,
                json=payload,
                timeout=10
            )

            if response.status_code != 200:
                results.append({
                    "user_email": email,
                    "status": response.status_code,
                    "error_message": response.text
                })
            else:
                results.append({
                    "user_email": email,
                    "status": response.status_code
                })

        except requests.RequestException as e:
            results.append({
                "user_email": email,
                "status": "error",
                "error_message": str(e)
            })

        # Delay to avoid Zoho rate limiting
        time.sleep(0.5)

    # -------- FINAL RESPONSE --------
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Zoho webhook triggered per user",
            "triggered_count": len(results),
            "results": results
        })
    }
