import boto3
import json
from concurrent.futures import ThreadPoolExecutor

def lambda_handler(event, context):
    # ✅ Define limited top regions
    top_regions = [
        'us-east-1',
    ]

    try:
        print("📦 Incoming event:", json.dumps(event))

        # Extract user email
        headers = event.get('headers', {})
        auth = headers.get('Authorization', '') or headers.get('authorization', '')
        email = auth.replace("Bearer ", "").strip()
        print(f"🔐 Extracted email: '{email}'")

        all_instances = []

        def fetch_region(region):
            print(f"🔍 Checking region: {region}")
            local_instances = []
            try:
                ec2 = boto3.client('ec2', region_name=region)
                response = ec2.describe_instances(Filters=[
                    {'Name': 'tag:Owner', 'Values': [email]}
                ])

                for reservation in response['Reservations']:
                    for instance in reservation['Instances']:
                        tags = instance.get('Tags', [])

                        # ✅ Only include instances with Product=mother-portal
                        if not any(tag['Key'] == 'Product' and tag['Value'] == 'mother-portal' for tag in tags):
                            continue

                        instance_id = instance['InstanceId']
                        state = instance['State']['Name']
                        private_ip = instance.get('PrivateIpAddress', '')
                        public_ip = instance.get('PublicIpAddress', '')
                        public_dns = instance.get('PublicDnsName', '')
                        key_name = instance.get('KeyName', '')

                        name_tag = next((tag['Value'] for tag in tags if tag['Key'] == 'Name'), '')
                        service_type = next((tag['Value'] for tag in tags if tag['Key'] == 'ServiceType'), 'Unknown')

                        # ✅ NEW: Extract course/module/topic from tags
                        course_id = next((tag['Value'] for tag in tags if tag['Key'] == 'course_id'), '')
                        module_id = next((tag['Value'] for tag in tags if tag['Key'] == 'module_id'), '')
                        topic = next((tag['Value'] for tag in tags if tag['Key'] == 'topic'), '')

                        ssh_user = 'ec2-user'

                        # Check by name tag
                        if 'ubuntu' in name_tag.lower():
                            ssh_user = 'ubuntu'
                        else:
                            image_id = instance.get('ImageId')
                            if image_id:
                                try:
                                    image_response = ec2.describe_images(ImageIds=[image_id])
                                    ami_name = image_response['Images'][0].get('Name', '').lower()
                                    if 'ubuntu' in ami_name:
                                        ssh_user = 'ubuntu'
                                except Exception as ami_err:
                                    print(f"⚠️ Failed to fetch AMI name for {image_id}: {ami_err}")

                        ssh_command = f'ssh -i \"{key_name}.pem\" {ssh_user}@{public_dns}' if key_name and public_dns else "-"

                        local_instances.append({
                            "InstanceId": instance_id,
                            "Name": name_tag,
                            "State": state,
                            "PrivateIp": private_ip,
                            "PublicIp": public_ip,
                            "PublicDns": public_dns,
                            "KeyName": key_name,
                            "SSHCommand": ssh_command,
                            "Region": region,
                            "ServiceType": service_type,
                            "CourseId": course_id,
                            "ModuleId": module_id,
                            "Topic": topic
                        })
            except Exception as e:
                print(f"⚠️ Error processing region {region}: {str(e)}")
            print(f"🔍 Found {len(local_instances)} instance(s) in region {region} for owner {email}")
            return local_instances

        # ✅ Limit to 3 threads to avoid memory issues
        with ThreadPoolExecutor(max_workers=3) as executor:
            results = executor.map(fetch_region, top_regions)

        for region_result in results:
            all_instances.extend(region_result)

        print(f"✅ Returning {len(all_instances)} instance(s) from top regions.")

        return {
            'statusCode': 200,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS"
            },
            'body': json.dumps(all_instances)
        }

    except Exception as e:
        print("❌ Lambda Error:", str(e))
        return {
            'statusCode': 500,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS"
            },
            'body': json.dumps({"message": "Internal Server Error", "error": str(e)})
        }
