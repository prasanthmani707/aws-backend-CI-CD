import boto3
import json

ec2 = boto3.client("ec2")

def lambda_handler(event, context):
    try:
        print("RAW EVENT:", json.dumps(event))

        # Handle HTTP API v2 body
        if "body" in event:
            try:
                event = json.loads(event["body"])
            except:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"message": "Invalid JSON body"})
                }

        instance_ids = event.get("instanceIds", [])
        service_type = event.get("serviceType")
        category_payload = event.get("category", "")  # ⭐ Category from payload
        plan_start_date = event.get("planStartDate")
        extend_hours = int(event.get("extendHours", 0))

        # Validate required fields
        if not instance_ids or not service_type or not plan_start_date:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "message": "instanceIds, serviceType, planStartDate are required"
                })
            }

        # Allowed category prefixes
        valid_categories = [
            "linux", "windows", "jenkins",
            "openvpn", "mysql", "syslog-ng", "microsoft-sql",
            "splunk"
        ]

        results = []

        # Validate each instance
        for instance_id in instance_ids:
            response = ec2.describe_instances(InstanceIds=[instance_id])

            if not response["Reservations"]:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"message": f"Instance not found: {instance_id}"})
                }

            instance = response["Reservations"][0]["Instances"][0]
            tags = {t["Key"]: t["Value"] for t in instance.get("Tags", [])}

            # STRICT ServiceType match
            if tags.get("ServiceType") != service_type:
                return {
                    "statusCode": 400,
                    "body": json.dumps({
                        "message": f"ServiceType mismatch for {instance_id}"
                    })
                }

            # STRICT PlanStartDate match
            if tags.get("PlanStartDate") != plan_start_date:
                return {
                    "statusCode": 400,
                    "body": json.dumps({
                        "message": f"PlanStartDate mismatch for {instance_id}"
                    })
                }

            # ⭐ CATEGORY VALIDATION ONLY FOR DATASOURCES
            if service_type == "DataSources":

                # category must be in payload
                if not category_payload:
                    return {
                        "statusCode": 400,
                        "body": json.dumps({
                            "message": "Category is required in payload for DataSources"
                        })
                    }

                category_payload = category_payload.lower()
                category_instance = tags.get("Category", "").lower()

                # Identify prefix in payload
                payload_prefix = next(
                    (p for p in valid_categories if p in category_payload),
                    None
                )

                # Identify prefix in instance tag
                instance_prefix = next(
                    (p for p in valid_categories if p in category_instance),
                    None
                )

                # Both MUST exist and MUST match EXACTLY
                if not payload_prefix or not instance_prefix or payload_prefix != instance_prefix:
                    return {
                        "statusCode": 400,
                        "body": json.dumps({
                            "message": (
                                f"Category mismatch for {instance_id}. "
                                f"Payload='{category_payload}', Instance='{category_instance}'. "
                                f"Both must contain the same category prefix from: {valid_categories}"
                            )
                        })
                    }

            # Calculate new quota hours
            existing_hours = int(tags.get("RunQuotaHours", "0"))
            new_hours = existing_hours + extend_hours

            results.append({
                "instanceId": instance_id,
                "oldHours": existing_hours,
                "addedHours": extend_hours,
                "newHours": new_hours
            })

        # Update all instances after validation
        for r in results:
            ec2.create_tags(
                Resources=[r["instanceId"]],
                Tags=[{"Key": "RunQuotaHours", "Value": str(r["newHours"])}]
            )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "RunQuotaHours updated for all instances",
                "updated": results
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
