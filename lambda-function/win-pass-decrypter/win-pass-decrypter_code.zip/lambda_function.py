import boto3
import base64
import json
import logging
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from auth_utils import get_email_from_event


s3 = boto3.client('s3')
ec2 = boto3.client('ec2')

S3_BUCKET = "splunklab-dev"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def log_event(action, **kwargs):
    log_entry = {"action": action}
    log_entry.update(kwargs)
    logger.info(json.dumps(log_entry))

def lambda_handler(event, context):
    try:
        log_event("event_received", raw_event=event)
        print("📩 Received event")

        # ✅ Handle both API Gateway and Lambda test event
        if "body" in event and isinstance(event["body"], str):
            body = json.loads(event["body"])  # API Gateway
        elif "instance_id" in event:
            body = event  # Direct Lambda test
        else:
            log_event("invalid_input", error="Missing or invalid input")
            print("❌ Missing or invalid input")
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing or invalid input"})
            }

        instance_id = body.get("instance_id")
        # user_email = body.get("email")

        # 2. Extract email from Authorization header
        user_email, error = get_email_from_event(event)
        print(f"email id : {user_email}")
        if error:
            return error  

        if not instance_id or not user_email:
            print("❌ Missing instance_id or email")
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing instance_id or email"})
            }

        # 🔹 Get the KeyName used to launch the instance
        print(f"🔄 Fetching EC2 details for {instance_id}")
        reservations = ec2.describe_instances(InstanceIds=[instance_id])['Reservations']
        instance = reservations[0]['Instances'][0]
        key_name = instance['KeyName']
        region=instance['Placement']['AvailabilityZone'][:-1]

        log_event("ec2_details_fetched", instance_id=instance_id, email=user_email, region=region, key_name=key_name)

        # 🔹 Download PEM file from S3
        s3_key = f"clients/{user_email}/keys/{key_name}.pem"
        print(f"📥 Downloading PEM from S3: {s3_key}")
        pem_file = s3.get_object(Bucket=S3_BUCKET, Key=s3_key)
        pem_content = pem_file['Body'].read()

        log_event("pem_downloaded", instance_id=instance_id, email=user_email, region=region, s3_key=s3_key)

        # 🔹 Get the encrypted Windows password
        print("🔄 Retrieving encrypted password")
        password_data = ec2.get_password_data(InstanceId=instance_id)
        if not password_data['PasswordData']:
            print("⚠️ Password not available yet")
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Password not available yet. Try again in a few minutes."})
            }

        encrypted_password = base64.b64decode(password_data['PasswordData'])

        # 🔹 Decrypt password
        key = RSA.import_key(pem_content)
        cipher = PKCS1_v1_5.new(key)
        decrypted_password = cipher.decrypt(encrypted_password, None)

        if not decrypted_password:
            print("❌ Password decryption failed")
            return {
                "statusCode": 500,
                "body": json.dumps({"error": "Failed to decrypt password. Invalid key or password."})
            }

        log_event("password_decrypted", instance_id=instance_id, email=user_email, region=region)

        print("✅ Password decrypted successfully")
        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "success",
                "instance_id": instance_id,
                "decrypted_password": decrypted_password.decode('utf-8')
            })
        }

    except Exception as e:
        log_event("error", details=str(e))
        print("❌ Error:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal Server Error", "details": str(e)})
        }
