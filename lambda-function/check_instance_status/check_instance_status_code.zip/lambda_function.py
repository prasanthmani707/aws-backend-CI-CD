import boto3
import json
from botocore.exceptions import ClientError

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    print("📥 Incoming event:", event)

    # ✅ 1. Parse input
    if "body" in event:
        try:
            body = json.loads(event["body"])
        except:
            body = {}
    else:
        body = event

    # ✅ 2. Accept either string or list
    instance_ids = body.get("instance_id")
    if not instance_ids:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing 'instance_id'"})
        }

    if isinstance(instance_ids, str):
        instance_ids = [instance_ids]
    elif not isinstance(instance_ids, list):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "'instance_id' must be string or list"})
        }

    results = []

    # ✅ Track which IDs failed individually
    invalid_ids = set()

    try:
        # Try describe_instances
        response = ec2.describe_instances(InstanceIds=instance_ids)
        instance_states = {}

        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                instance_id = instance['InstanceId']
                state = instance['State']['Name']
                instance_states[instance_id] = state

        print("🖥️ Accurate instance states:", instance_states)

        # ✅ Build results
        for instance_id in instance_ids:
            if instance_id in instance_states:
                state = instance_states[instance_id]
                message = "Server is dead" if state == "terminated" else "Server is alive"
            else:
                state = "terminated"
                message = "Server is dead"

            results.append({
                "instance_id": instance_id,
                "state": state,
                "message": message
            })

        return {
            "statusCode": 200,
            "body": json.dumps(results)
        }

    except ClientError as e:
        error_message = str(e)
        print("❌ ClientError:", error_message)

        if "InvalidInstanceID.Malformed" in error_message or "InvalidInstanceID.NotFound" in error_message:
            # ✅ Identify which are valid vs not found
            found_ids = []
            try:
                paginator = ec2.get_paginator('describe_instances')
                for page in paginator.paginate():
                    for reservation in page['Reservations']:
                        for instance in reservation['Instances']:
                            found_ids.append(instance['InstanceId'])
            except:
                pass  # If describe fails here, fallback to mark all as terminated

            for instance_id in instance_ids:
                state = "running" if instance_id in found_ids else "terminated"
                message = "Server is dead" if state == "terminated" else "Server is alive"
                results.append({
                    "instance_id": instance_id,
                    "state": state,
                    "message": message
                })

            return {
                "statusCode": 200,
                "body": json.dumps(results)
            }

        return {
            "statusCode": 500,
            "body": json.dumps({"error": error_message})
        }

    except Exception as e:
        print("❌ Unknown Error:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
