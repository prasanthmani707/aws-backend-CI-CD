# Configuration settings for AWS Billing Notification System
REGION = "us-east-1"
SENDER = "labsupport@softmania.in"
RECIPIENTS = ["kaliyappan.rangan@softmania.in"]
