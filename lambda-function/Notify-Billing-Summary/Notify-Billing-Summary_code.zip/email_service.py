import boto3
from config import REGION, SENDER, RECIPIENTS

ses = boto3.client('ses', region_name=REGION)

def send_mail(subject, body_html, body_text=""):
    try:
        ses.send_email(
            Source=SENDER,
            Destination={'ToAddresses': RECIPIENTS},
            Message={
                'Subject': {'Data': subject},
                'Body': {
                    'Html': {'Data': body_html},
                    'Text': {'Data': body_text if body_text else "Please enable HTML to view this email."}
                }
            }
        )
        print(f"Email sent successfully: {subject}")
    except Exception as e:
        print(f"Error sending email: {str(e)}")
