import json
from datetime import date
from report_generator import generate_daily_report, generate_monthly_report

def lambda_handler(event, context):
    """
    Main Lambda entrypoint. Designed to cleanly route event data to the appropriate report generator.
    """
    print(f"Received Event: {json.dumps(event)}")
    today = date.today()
    
    report_type = event.get('report')
    
    if report_type == 'daily':
        generate_daily_report(today)
    elif report_type == 'monthly':
        generate_monthly_report(today)
    else:
        # Default schedule logic
        generate_daily_report(today)
        if today.day == 1:
            generate_monthly_report(today)
            
    return {"status": "success"}
