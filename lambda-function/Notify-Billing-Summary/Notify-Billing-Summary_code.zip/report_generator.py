from datetime import timedelta
from cost_service import get_account_names, get_cost_data, extract_groups
from email_service import send_mail
from template_service import get_html_template, get_text_template

def generate_daily_report(today):
    end_date = today
    start_date = today - timedelta(days=1)
    
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    
    # 1. Overall Cost For the Given Period (Yesterday)
    overall_data = get_cost_data(start_str, end_str, granularity='DAILY')
    daily_cost = 0.0
    if overall_data:
        daily_cost = float(overall_data[0]['Total']['NetUnblendedCost']['Amount'])
        
    # 2. Month-to-Date Cost
    mtd_start = start_date.replace(day=1)
    mtd_start_str = mtd_start.strftime('%Y-%m-%d')
    mtd_data = get_cost_data(mtd_start_str, end_str, granularity='MONTHLY')
    mtd_cost = 0.0
    if mtd_data:
        for d in mtd_data:
            mtd_cost += float(d['Total']['NetUnblendedCost']['Amount'])
    
    # Optional: Skip sending email if both are 0
    if daily_cost == 0 and mtd_cost == 0:
        print("Daily cost and MTD cost are both $0. Skipping daily email.")
        return

    # Pre-fetch Account Names Dimension
    account_map = get_account_names(start_str, end_str)

    # 3. Linked Accounts
    account_data = get_cost_data(start_str, end_str, group_by='LINKED_ACCOUNT', granularity='DAILY')
    accounts = []
    account_ids = []
    
    for group in extract_groups(account_data):
        acc_id = group['Keys'][0]
        amt = float(group['Metrics']['NetUnblendedCost']['Amount'])
        if amt > 0:
            acc_name = account_map.get(acc_id, acc_id)
            if acc_name != acc_id and acc_name:
                display_name = f"{acc_name} ({acc_id})"
            else:
                display_name = acc_id
            accounts.append({'name': display_name, 'amount': amt, 'id': acc_id})
            account_ids.append(acc_id)
            
    accounts.sort(key=lambda x: x['amount'], reverse=True)
        
    # 4. Last 30 Days Cost (Grouped by Account)
    thirty_days_ago = end_date - timedelta(days=30)
    thirty_days_str = thirty_days_ago.strftime('%Y-%m-%d')
    last_30_data = get_cost_data(thirty_days_str, end_str, group_by='LINKED_ACCOUNT', granularity='DAILY')
    
    day_wise_per_acc = {}
    if last_30_data:
        for day_data in last_30_data:
            date_str = day_data['TimePeriod']['Start']
            for group in day_data.get('Groups', []):
                acc_id = group['Keys'][0]
                amt = float(group['Metrics']['NetUnblendedCost']['Amount'])
                if amt > 0:
                    if acc_id not in day_wise_per_acc:
                        day_wise_per_acc[acc_id] = []
                    day_wise_per_acc[acc_id].append({'date': date_str, 'amount': amt})
                    
    for acc_id in day_wise_per_acc:
        day_wise_per_acc[acc_id].sort(key=lambda x: x['date'], reverse=True)
        
    # 5. Region-wise (Grouped by Account and Region)
    region_data = get_cost_data(start_str, end_str, group_by=['LINKED_ACCOUNT', 'REGION'], granularity='DAILY')
    regions_per_acc = {}
    
    if region_data:
        for day_data in region_data:
            for group in day_data.get('Groups', []):
                if len(group['Keys']) >= 2:
                    acc_id = group['Keys'][0]
                    region_name = group['Keys'][1]
                    amt = float(group['Metrics']['NetUnblendedCost']['Amount'])
                    if amt > 0:
                        if acc_id not in regions_per_acc:
                            regions_per_acc[acc_id] = []
                        regions_per_acc[acc_id].append({'name': region_name, 'amount': amt})
                        
    for acc_id in regions_per_acc:
        regions_per_acc[acc_id].sort(key=lambda x: x['amount'], reverse=True)
        
    # Bind to accounts array
    for acc in accounts:
        acc_id = acc['id']
        acc['regions'] = regions_per_acc.get(acc_id, [])
        acc['day_wise'] = day_wise_per_acc.get(acc_id, [])
    
    html_body = get_html_template('Daily', start_str, 'Daily Cost', daily_cost, 'Month-to-Date', mtd_cost, accounts=accounts)
    text_body = get_text_template('Daily', start_str, 'Daily Cost', daily_cost, 'Month-to-Date', mtd_cost, accounts=accounts)
    
    accounts_str = ", ".join(account_ids)
    subject = f"[AWS] Daily Cost Report - {start_str}"
    if accounts_str:
        subject += f" | Acc: {accounts_str}"

    send_mail(subject, html_body, text_body)

def generate_monthly_report(today):
    if today.day == 1:
        # Triggered on 1st -> Report for entire previous month
        last_day_prev_month = today - timedelta(days=1)
        start_date = last_day_prev_month.replace(day=1)
        end_date = today
    else:
        # Month-To-Date (MTD)
        start_date = today.replace(day=1)
        end_date = today
        
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    report_month = start_date.strftime('%B %Y') 
    
    # Pre-fetch Account Names Dimension
    account_map = get_account_names(start_str, end_str)
    
    # 1. Total Cost
    daily_data = get_cost_data(start_str, end_str, granularity='DAILY')
    total_cost = 0.0
    for d in daily_data:
        amt = float(d['Total']['NetUnblendedCost']['Amount'])
        total_cost += amt
        
    if total_cost == 0:
        print("Total monthly cost is $0. Skipping monthly email.")
        return
        
    # 2. Linked Accounts
    account_data = get_cost_data(start_str, end_str, group_by='LINKED_ACCOUNT', granularity='MONTHLY')
    accounts = []
    account_ids = []
    
    for group in extract_groups(account_data):
        acc_id = group['Keys'][0]
        amt = float(group['Metrics']['NetUnblendedCost']['Amount'])
        if amt > 0:
            acc_name = account_map.get(acc_id, acc_id)
            if acc_name != acc_id and acc_name:
                display_name = f"{acc_name} ({acc_id})"
            else:
                display_name = acc_id
            accounts.append({'name': display_name, 'amount': amt, 'id': acc_id})
            account_ids.append(acc_id)
            
    accounts.sort(key=lambda x: x['amount'], reverse=True)
                
    # 3. Last 30 Days Cost (Grouped by Account) (Actual Day-wise)
    day_wise_per_acc = {}
    if daily_data:
        # Re-fetch daily data grouped by account to get account-specific days
        day_acc_data = get_cost_data(start_str, end_str, group_by='LINKED_ACCOUNT', granularity='DAILY')
        if day_acc_data:
            for day_data in day_acc_data:
                date_str = day_data['TimePeriod']['Start']
                for group in day_data.get('Groups', []):
                    acc_id = group['Keys'][0]
                    amt = float(group['Metrics']['NetUnblendedCost']['Amount'])
                    if amt > 0:
                        if acc_id not in day_wise_per_acc:
                            day_wise_per_acc[acc_id] = []
                        day_wise_per_acc[acc_id].append({'date': date_str, 'amount': amt})
                        
    for acc_id in day_wise_per_acc:
        day_wise_per_acc[acc_id].sort(key=lambda x: x['date'], reverse=True)

    # 4. Region Breakdown (DYNAMIC, Skip 0) by account
    region_data = get_cost_data(start_str, end_str, group_by=['LINKED_ACCOUNT', 'REGION'], granularity='MONTHLY')
    regions_per_acc = {}
    
    for group in extract_groups(region_data):
        if len(group['Keys']) >= 2:
            acc_id = group['Keys'][0]
            region_name = group['Keys'][1]
            amt = float(group['Metrics']['NetUnblendedCost']['Amount'])
            if amt > 0:
                if acc_id not in regions_per_acc:
                    regions_per_acc[acc_id] = []
                regions_per_acc[acc_id].append({'name': region_name, 'amount': amt})
            
    for acc_id in regions_per_acc:
        regions_per_acc[acc_id].sort(key=lambda x: x['amount'], reverse=True)
                
    # Bind to accounts array
    for acc in accounts:
        acc_id = acc['id']
        acc['regions'] = regions_per_acc.get(acc_id, [])
        acc['day_wise'] = day_wise_per_acc.get(acc_id, [])
        
    html_body = get_html_template('Monthly', report_month, 'Total Cost', total_cost, accounts=accounts)
    text_body = get_text_template('Monthly', report_month, 'Total Cost', total_cost, accounts=accounts)
        
    accounts_str = ", ".join(account_ids)
    subject = f"[AWS] Monthly Cost Report - {report_month}"
    if accounts_str:
        subject += f" | Acc: {accounts_str}"

    send_mail(subject, html_body, text_body)
