import boto3
import json
from config import REGION

# MUST use us-east-1 for Cost Explorer
ce = boto3.client('ce', region_name=REGION)

def get_account_names(start_date, end_date):
    """
    Fetch linked account names dynamically from Cost Explorer using get_dimension_values
    """
    mapping = {}
    try:
        response = ce.get_dimension_values(
            TimePeriod={'Start': start_date, 'End': end_date},
            Dimension='LINKED_ACCOUNT'
        )
        for val in response.get('DimensionValues', []):
            acc_id = val.get('Value')
            # Name is usually stored in the 'description' attribute
            acc_name = val.get('Attributes', {}).get('description')
            mapping[acc_id] = acc_name if acc_name else acc_id
    except Exception as e:
        print(f"Error fetching account names mapping: {e}")
    return mapping

def get_cost_data(start_date, end_date, group_by=None, granularity='DAILY'):
    """
    Fetch dynamic cost data matching the exact Filters and requirements.
    """
    kwargs = {
        'TimePeriod': {'Start': start_date, 'End': end_date},
        'Granularity': granularity,
        'Metrics': ['NetUnblendedCost'],
        'Filter': {
            "Not": {
                "Dimensions": {
                    "Key": "RECORD_TYPE",
                    "Values": ["Credit", "Refund"]
                }
            }
        }
    }
    
    if group_by:
        if isinstance(group_by, list):
            kwargs['GroupBy'] = [{'Type': 'DIMENSION', 'Key': k} for k in group_by]
        else:
            kwargs['GroupBy'] = [{'Type': 'DIMENSION', 'Key': group_by}]
        
    try:
        response = ce.get_cost_and_usage(**kwargs)
        # Log response to CloudWatch as per requirement "Log raw response in CloudWatch"
        print(f"Cost Explorer API Response ({group_by or 'Total'}):", json.dumps(response))
        return response.get('ResultsByTime', [])
    except Exception as e:
        print(f"Error fetching cost data: {e}")
        return []

def extract_groups(data_list: list) -> list:
    """Safely extract Groups list from Boto3 response to assist type-checkers"""
    if data_list and isinstance(data_list[0], dict):
        return data_list[0].get('Groups', [])
    return []
