# AWS Billing Notification System

## Overview
A dynamic, serverless AWS Lambda application that generates beautifully formatted daily and monthly AWS billing reports via email. It strictly uses native Cost Explorer (ce) calls to fetch, group, and display organizational costs accurately.

### Key Features
- **Account-Aware Splitting**: Automatically identifies linked accounts and groups the Region Breakdown and Last 30 Days Cost Details dynamically per account.
- **Beautiful HTML Emails**: Responsive, professionally styled HTML email reports with summary boxes and structured data tables.
- **Month-to-Date Context**: Daily emails automatically include Month-To-Date (MTD) accumulated cost side-by-side with the daily cost.
- **Smart Data Handling**: Filters out `Credit` and `Refund` record types, skips $0 metrics, and natively sorts high-cost components first.

## File Structure

- `lambda_function.py` - Main Lambda entrypoint managing the EventBridge trigger routing.
- `report_generator.py` - Core logic for Daily and Monthly reporting, managing date intervals and data aggregation.
- `cost_service.py` - AWS Cost Explorer integrations and dynamic ID mapping logic with multi-dimension grouping.
- `template_service.py` - HTML and Text template rendering engine enforcing the UI aesthetics.
- `email_service.py` - Amazon SES client interface supporting both HTML and Text payload deliveries.
- `config.py` - Configuration constants (Regions, Sender, Recipients).

## Deployment Instructions
1. Package these files into a ZIP archive along with dependencies if applicable.
2. Deploy to AWS Lambda under a Python runtime environment.
3. Attach the following IAM permissions to the execution role:
   - `ce:GetCostAndUsage`
   - `ce:GetDimensionValues`
   - `ses:SendEmail`
4. Schedule EventBridge triggers:
   - **Daily Trigger** (e.g., `cron(0 9 * * ? *)`) with basic target logic.
   - **Monthly Trigger** automatically evaluates natively via the internally checked `today.day == 1` logic.
