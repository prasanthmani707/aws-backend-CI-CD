def get_html_template(report_type, date_str, main_cost_label, main_cost_val, sec_cost_label=None, sec_cost_val=None, regions=None, accounts=None, day_wise=None):
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #333; }}
            .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
            .header {{ background-color: #232f3e; color: #ffffff; padding: 20px; text-align: center; }}
            .header h2 {{ margin: 0; font-size: 24px; }}
            .content {{ padding: 30px 20px; }}
            .summary-box {{ display: flex; justify-content: space-around; background: #eef2f6; padding: 20px; border-radius: 6px; margin-bottom: 25px; }}
            .summary-item {{ text-align: center; flex: 1; }}
            .summary-item:not(:last-child) {{ border-right: 1px solid #d1d9e6; }}
            .summary-label {{ font-size: 14px; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }}
            .summary-value {{ font-size: 24px; font-weight: bold; color: #232f3e; margin-top: 5px; }}
            .section-title {{ font-size: 16px; margin-bottom: 15px; color: #232f3e; border-bottom: 2px solid #ff9900; padding-bottom: 5px; display: inline-block; font-weight:bold; }}
            .table {{ width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 14px; }}
            .table th, .table td {{ padding: 10px 15px; text-align: left; border-bottom: 1px solid #e1e4e8; }}
            .table th {{ background-color: #f8f9fa; font-weight: 600; color: #555; text-transform: uppercase; font-size: 12px; }}
            .table tr:hover {{ background-color: #f1f3f5; }}
            .amount {{ font-weight: bold; color: #232f3e; text-align: left; }}
            .footer {{ background-color: #f8f9fa; text-align: center; padding: 15px; font-size: 12px; color: #777; border-top: 1px solid #e1e4e8; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>AWS Cost Report</h2>
            </div>
            <div class="content">
                <p style="font-size: 15px; color: #555;">Here is your AWS cost summary for <strong>{date_str}</strong>.</p>
                
                <div class="summary-box">
                    <div class="summary-item">
                        <div class="summary-label">{main_cost_label}</div>
                        <div class="summary-value">${main_cost_val:.2f}</div>
                    </div>
    """
    if sec_cost_label is not None and sec_cost_val is not None:
        html += f"""
                    <div class="summary-item">
                        <div class="summary-label">{sec_cost_label}</div>
                        <div class="summary-value">${sec_cost_val:.2f}</div>
                    </div>
        """
        
    html += """
                </div>
    """

    if accounts and len(accounts) > 0:
        html += """
                <div class="section-title">🏢 Linked Accounts Summary</div>
                <table class="table">
                    <tr><th>Account</th><th style="text-align: left;">Cost (USD)</th></tr>
        """
        for a in accounts:
            html += f"<tr><td>{a['name']}</td><td class='amount'>${a['amount']:.2f}</td></tr>"
        html += "</table>"
        
        # Split per account if regions/day_wise exist inside accounts
        if any(a.get('regions') or a.get('day_wise') for a in accounts):
            for a in accounts:
                if not a.get('regions') and not a.get('day_wise'):
                    continue
                html += f"<div class='section-title' style='margin-top: 15px; color: #ff9900;'>📊 Account: {a['name']}</div>"
                
                if a.get('regions'):
                    html += """
                    <div style="font-weight: 600; margin: 10px 0; font-size: 14px; color: #555;">🌍 Region Breakdown</div>
                    <table class="table" style="margin-bottom: 15px;">
                        <tr><th>Region</th><th style="text-align: left;">Cost (USD)</th></tr>
                    """
                    for r in a['regions']:
                        html += f"<tr><td>{r['name']}</td><td class='amount'>${r['amount']:.2f}</td></tr>"
                    html += "</table>"
                    
                if a.get('day_wise'):
                    title = "📅 Last 30 Days Cost Details" if report_type == 'Daily' else "📅 Day-wise Cost"
                    html += f"""
                    <div style="font-weight: 600; margin: 10px 0; font-size: 14px; color: #555;">{title}</div>
                    <table class="table" style="margin-bottom: 25px;">
                        <tr><th>Date</th><th style="text-align: left;">Cost (USD)</th></tr>
                    """
                    for d in a['day_wise']:
                        html += f"<tr><td>{d['date']}</td><td class='amount'>${d['amount']:.2f}</td></tr>"
                    html += "</table>"
    else:
        # Fallback to global lists if accounts not present
        if regions and len(regions) > 0:
            html += """
                    <div class="section-title">🌍 Region Breakdown</div>
                    <table class="table">
                        <tr><th>Region</th><th style="text-align: left;">Cost (USD)</th></tr>
            """
            for r in regions:
                html += f"<tr><td>{r['name']}</td><td class='amount'>${r['amount']:.2f}</td></tr>"
            html += "</table>"
            
        if day_wise and len(day_wise) > 0:
            title = "📅 Last 30 Days Cost Details" if report_type == 'Daily' else "📅 Day-wise Cost"
            html += f"""
                    <div class="section-title">{title}</div>
                    <table class="table">
                        <tr><th>Date</th><th style="text-align: left;">Cost (USD)</th></tr>
            """
            for d in day_wise:
                if d['amount'] > 0:
                    html += f"<tr><td>{d['date']}</td><td class='amount'>${d['amount']:.2f}</td></tr>"
            html += "</table>"

    html += """
            </div>
            <div class="footer">
                This is an automated notification from your AWS Billing Notification System.<br>
            </div>
        </div>
    </body>
    </html>
    """
    return html


def get_text_template(report_type, date_str, main_cost_label, main_cost_val, sec_cost_label=None, sec_cost_val=None, regions=None, accounts=None, day_wise=None):
    text = f"AWS Cost Report\n"
    text += f"Date: {date_str}\n\n"
    text += f"{main_cost_label}: ${main_cost_val:.2f}\n"
    if sec_cost_label and sec_cost_val is not None:
        text += f"{sec_cost_label}: ${sec_cost_val:.2f}\n"
    
    if accounts and len(accounts) > 0:
        text += "\nLinked Accounts:\n"
        for a in accounts:
            text += f"- {a['name']} : ${a['amount']:.2f}\n"

        if any(a.get('regions') or a.get('day_wise') for a in accounts):
            for a in accounts:
                if not a.get('regions') and not a.get('day_wise'):
                    continue
                text += f"\n==================================\n"
                text += f"Account Details: {a['name']}\n"
                text += f"==================================\n"
                
                if a.get('regions'):
                    text += "Region Breakdown:\n"
                    for r in a['regions']:
                        text += f"- {r['name']} : ${r['amount']:.2f}\n"
                
                if a.get('day_wise'):
                    title = "Last 30 Days Cost Details:" if report_type == 'Daily' else "Day-wise Cost:"
                    text += f"\n{title}\n"
                    for d in a['day_wise']:
                        text += f"- {d['date']} : ${d['amount']:.2f}\n"
    else:
        if regions and len(regions) > 0:
            text += "\nRegion Breakdown:\n"
            for r in regions:
                text += f"- {r['name']} : ${r['amount']:.2f}\n"
                
        if day_wise and len(day_wise) > 0:
            title = "\nLast 30 Days Cost Details:\n" if report_type == 'Daily' else "\nDay-wise Cost:\n"
            text += title
            for d in day_wise:
                if d['amount'] > 0:
                    text += f"- {d['date']} : ${d['amount']:.2f}\n"
                
    return text
