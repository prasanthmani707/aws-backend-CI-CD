import json
import boto3
import logging
import uuid
from boto3.dynamodb.conditions import Key

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# DynamoDB connection
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('UserWallet')  # Update your table name here


# AUTO-INCREMENT ID BY USER EMAIL
def get_next_id(user_email):
    response = table.query(
        KeyConditionExpression=Key('user_email').eq(user_email),
        ScanIndexForward=False,
        Limit=1
    )

    items = response.get('Items', [])
    if not items:
        return 1

    return int(items[0].get('id', 0)) + 1


def normalize_to_list(value):
    # Case 1: Already a list
    if isinstance(value, list):
        return value

    # Case 2: String input
    if isinstance(value, str):
        cleaned = value.strip()

        # Remove wrapping [ ] if present
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1].strip()

        # Try JSON parsing FIRST (handles escaped JSON arrays)
        try:
            parsed = json.loads(f"[{cleaned}]" if not cleaned.startswith('"') else f"[{cleaned}]")
            if isinstance(parsed, list):
                return [str(v).strip() for v in parsed if str(v).strip()]
        except Exception:
            pass  # fallback below

        # Fallback: manual split (comma separated)
        return [
            v.strip().strip('"').strip("'")
            for v in cleaned.split(",")
            if v.strip()
        ]

    return value

def lambda_handler(event, context):
    try:
        logger.info("📥 Incoming event: %s", json.dumps(event))

        if 'body' not in event:
            raise ValueError("Missing request body")

        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON in request body")

        logger.info("📦 Parsed body: %s", json.dumps(body))

        required_fields = ['user_email', 'name', 'environment']
        for field in required_fields:
            if field not in body or not body[field]:
                raise ValueError(f"'{field}' is required and cannot be empty")

        user_email = body['user_email'].strip().lower().replace(" ", "")

        # DEFAULT premium_bundle_lab (FALSE)
        premium_bundle_lab = body.get('premium_bundle_lab', False)
        if not isinstance(premium_bundle_lab, bool):
            raise ValueError("'premium_bundle_lab' must be a boolean")

        # COURSE ID DEFAULT = general
        raw_course_id = normalize_to_list(body.get('course_id') or "General")

        if isinstance(raw_course_id, list):
            course_id = raw_course_id[0] if raw_course_id else "General"
        elif isinstance(raw_course_id, str):
            course_id = raw_course_id
        else:
            raise ValueError("'course_id' must be a string or a list")

        # FETCH EXISTING USER RECORDS
        response = table.query(
            KeyConditionExpression=Key('user_email').eq(user_email)
        )
        items = response.get('Items', [])

        # NAME LOGIC (reuse stored name)
        if items:
            name = items[0].get('name')
        else:
            name = body['name']

        name = name.strip()
        name = "-".join(name.split())

        # ENVIRONMENT NORMALIZATION
        environment_input = normalize_to_list(body['environment'])

        # ✅ NEW: Minimum 1 environment required
        if not isinstance(environment_input, list) or len(environment_input) < 1:
            raise ValueError("'environment' must contain at least one item")

        new_envs = []
        for env in environment_input:
            if isinstance(env, str):
                new_envs.append({
                    'source_id': env,
                    'unique_id': str(uuid.uuid4()),
                    'created': False
                })

            elif isinstance(env, dict):
                if 'source_id' not in env or not env['source_id']:
                    raise ValueError(
                        "Each 'environment' object must have a non-empty 'source_id'"
                    )

                new_env = {
                    'source_id': env['source_id'],
                    'unique_id': str(uuid.uuid4()),
                    'created': env.get('created', False)
                }

                for opt_field in ['start_date', 'end_date', 'package_hours']:
                    if opt_field in env and env[opt_field]:
                        new_env[opt_field] = env[opt_field]

                new_envs.append(new_env)
            else:
                raise ValueError(
                    "Each item in 'environment' must be either a string or an object"
                )

        # ✅ Check if same course_id exists for premium_bundle_lab=true
        existing_course_record_premium = None
        existing_envs_premium = []
        
        if premium_bundle_lab is True:
            for record in items:
                if record.get('course_id') == course_id and record.get('premium_bundle_lab') is True:
                    existing_course_record_premium = record
                    existing_envs_premium = record.get('environment', [])
                    break
        
        # If existing record found for same course_id (premium_bundle_lab=true)
        if existing_course_record_premium and premium_bundle_lab is True:
            logger.info("🔄 Updating existing premium course (premium_bundle_lab=true)")
            
            # Get existing source_ids
            existing_source_ids = {env.get('source_id') for env in existing_envs_premium if env.get('source_id')}
            
            # Filter new_envs to include only NEW source_ids (not already in existing)
            filtered_new_envs = []
            for new_env in new_envs:
                source_id = new_env.get('source_id')
                if source_id not in existing_source_ids:
                    filtered_new_envs.append(new_env)
                else:
                    logger.info(f"⚠️ Skipping source_id '{source_id}' as it already exists in the course")
            
            # If no new environments to add
            if not filtered_new_envs:
                return {
                    'statusCode': 400,
                    'body': json.dumps({
                        'error': 'All provided environment source_ids already exist in this course'
                    })
                }
            
            # Merge environments (keep existing, add only new ones)
            merged_envs = existing_envs_premium.copy()
            merged_envs.extend(filtered_new_envs)
            
            # Update the existing record with merged environments
            item = existing_course_record_premium.copy()
            item['environment'] = merged_envs
            
            # Update optional fields if provided
            for opt in ['start_date', 'end_date', 'package_hours']:
                value = body.get(opt)
                if value:
                    item[opt] = value
            
            # Keep the same ID (update existing record)
            table.put_item(Item=item)
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Premium course updated successfully',
                    'note': f'Added {len(filtered_new_envs)} new environment(s), skipped {len(new_envs) - len(filtered_new_envs)} duplicate(s)'
                })
            }
        
        # ✅ PREMIUM VALIDATION (ONE PER COURSE) - ONLY for NEW premium_bundle_lab = True
        if premium_bundle_lab is True:
            for record in items:
                if record.get('course_id') == course_id and record.get('premium_bundle_lab') is True:
                    # This case should have been handled above, but keeping as fallback
                    return {
                        'statusCode': 400,
                        'body': json.dumps({
                            'error': 'premium bundle free lab already added.'
                        })
                    }
        
        # ✅ NEW LOGIC: For premium_bundle_lab=false, check if same course_id exists
        existing_course_record_free = None
        existing_envs_free = []
        
        if premium_bundle_lab is False:
            for record in items:
                if record.get('course_id') == course_id and record.get('premium_bundle_lab') is False:
                    existing_course_record_free = record
                    existing_envs_free = record.get('environment', [])
                    break
        
        # If existing record found for same course_id (premium_bundle_lab=false), merge environments
        if existing_course_record_free and premium_bundle_lab is False:
            logger.info("🔄 Merging environments for existing course_id (premium_bundle_lab=false)")
            
            # ✅ MODIFIED: Always add all new environments regardless of source_id
            # No checking for duplicates - always append new environments
            merged_envs = existing_envs_free.copy()
            
            # Add ALL new environments to existing ones
            for new_env in new_envs:
                # Always generate a new unique_id for each new environment
                if 'unique_id' not in new_env or not new_env['unique_id']:
                    new_env['unique_id'] = str(uuid.uuid4())
                merged_envs.append(new_env)
            
            # Update the existing record with merged environments
            item = existing_course_record_free.copy()
            item['environment'] = merged_envs
            
            # Update optional fields if provided
            for opt in ['start_date', 'end_date', 'package_hours']:
                value = body.get(opt)
                if value:
                    item[opt] = value
            
            # Keep the same ID (update existing record)
            table.put_item(Item=item)
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'User wallet updated successfully (merged environments)',
                    'note': 'All new environments added without overriding existing ones'
                })
            }
        
        # For all other cases (new course_id for either premium or free), create new entry
        logger.info("💾 Creating new UserWallet entry")
        
        # BUILD FINAL ITEM
        item = {
            'user_email': user_email,
            'name': name,
            'course_id': course_id,
            'environment': new_envs,
            'premium_bundle_lab': premium_bundle_lab
        }

        for opt in ['start_date', 'end_date', 'package_hours']:
            value = body.get(opt)
            if value:
                item[opt] = value

        new_id = get_next_id(user_email)
        # updated item[id] with new_id:05d so that dynammdd store 00001
        item['id'] = f"{new_id:05d}"   # supports up to 99,999

        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'User wallet stored successfully'})
        }

    except ValueError as ve:
        logger.error("❌ Validation error: %s", str(ve))
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(ve)})
        }

    except Exception as e:
        logger.exception("💥 Internal server error", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }