import json
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from datetime import datetime
from get_backend_cost import get_backend_cost

# AWS clients
dynamodb = boto3.resource("dynamodb")
lambda_client = boto3.client("lambda")

# Tables
instance_table = dynamodb.Table("instance_registry_creditbased")
wallet_table = dynamodb.Table("user_wallet_creditbased")

# Other Lambdas
HISTORY_LAMBDA_NAME = "history_tracker_creditbased"

PLATFORM_FEE = get_backend_cost()
print(f"platform fee in usd {PLATFORM_FEE}")

def lambda_handler(event, context):

    processed_users = set()
    results = []

    now = datetime.utcnow().isoformat()


    # time complexcity was O(K1) hash lookup
    # ---- GET RUNNING INSTANCES ----
    running_response = instance_table.query(
        IndexName = "platform_fee",
        KeyConditionExpression=Key("state").eq("running")
    )
    # time complexcity was O(K2) hash lookup
    # ---- GET STOPPED INSTANCES ----
    stopped_response = instance_table.query(
        IndexName = "platform_fee",
        KeyConditionExpression=Key("state").eq("stopped")
    )
    # O(k1 +k2) Array/List concatenation
    items = running_response.get("Items", []) + stopped_response.get("Items", [])
    
    # n = k1 +k2 complexity O(n)
    for item in items:

        email_id = item.get("email_id")
        # set data structure using time was O(1)
        if email_id in processed_users:
            continue

        try:
            # in thuis time  DSA was hash table time was O(1)
            # ---- ATOMIC WALLET UPDATE ----
            response = wallet_table.update_item(
                Key={"email_id": email_id},
                UpdateExpression="""
                    SET previous_balance = current_balance,
                        current_balance = current_balance - :amount,
                        cb_last_updated = :now
                """,
                ConditionExpression="current_balance >= :amount",
                ExpressionAttributeValues={
                    ":amount": PLATFORM_FEE,
                    ":now": now
                },
                ReturnValues="UPDATED_NEW"
            )

            prev_balance = response["Attributes"]["previous_balance"]
            curr_balance = response["Attributes"]["current_balance"]

            # ---- RECORD FOR HISTORY ----
            record_out = {
                "email_id": email_id,
                "amount": float(PLATFORM_FEE),
                "balance_before": float(prev_balance),
                "balance_after": float(curr_balance),
                "source": "platform_fee",
                "status": "SUCCESS",
                "updated_time": now
            }

            results.append(record_out)

            print(f"✅ Platform fee deducted {email_id}: {prev_balance} → {curr_balance}")

        except ClientError as e:

            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                print(f"❌ Insufficient balance for {email_id}")

            else:
                raise

        processed_users.add(email_id)

    # ---- SEND HISTORY RECORDS ----
    if results:

        payload = json.dumps({"records": results}).encode("utf-8")

        lambda_client.invoke(
            FunctionName=HISTORY_LAMBDA_NAME,
            InvocationType="Event",
            Payload=payload
        )

        print(f"🚀 Sent {len(results)} records to history lambdas")

    else:
        print("ℹ️ No wallet updates")

    return {
        "status": "processed",
        "records": len(results)
    }