import json
import requests
from concurrent.futures import ThreadPoolExecutor

def check_splunk_web(ip):
    url = f"http://{ip}:8000"
    try:
        response = requests.get(url, timeout=5)
        if "Splunk" in response.text:
            return {"ip": ip, "status": "UP", "details": "Splunk Web UI detected"}
        else:
            return {"ip": ip, "status": "UNKNOWN", "details": "Port open but not Splunk"}
    except requests.exceptions.RequestException as e:
        return {"ip": ip, "status": "DOWN", "details": str(e)}

def lambda_handler(event, context=None):
    try:
        # Step 1: Extract body properly from API Gateway or raw
        body = event.get("body")
        if isinstance(body, str):
            body = json.loads(body)  # Parse JSON string
        elif body is None:
            body = event  # fallback if called directly with raw JSON (e.g., test invoke)

        # Step 2: Validate 'public_ips'
        public_ips = body.get("public_ips")
        if not isinstance(public_ips, list):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "'public_ips' must be a list of IPs"})
            }

        # Step 3: Run checks in parallel
        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(check_splunk_web, public_ips))

        return {
            "statusCode": 200,
            "body": json.dumps({"results": results})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
