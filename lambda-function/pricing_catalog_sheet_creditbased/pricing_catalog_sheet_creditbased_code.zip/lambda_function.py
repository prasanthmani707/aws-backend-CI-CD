import json
import urllib.request
import urllib.parse

def lambda_handler(event, context):
    oauthtoken = "1000.8f862bb74c6c9e59ae50f2820ab65dc2.df06c05c326d8400980c8cd8303e04c7"
    resourceId = "kqvfr3cd697ab7b3947e5a0173b5089295043"

    url = f"https://sheet.zoho.in/api/v2/{resourceId}"

    paramMap = {
        'method': 'worksheet.records.fetch',
        'worksheet_name': 'Sheet1',
        'header_row': 3,
        'records_start_index': 1,
        'count': 200  # set high number to get all rows
    }

    data = urllib.parse.urlencode(paramMap).encode('utf-8')

    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Zoho-oauthtoken {oauthtoken}'
    }

    req = urllib.request.Request(url, data=data, headers=headers, method='POST')

    try:
        with urllib.request.urlopen(req) as response:
            result = response.read().decode('utf-8')
            return {
                'statusCode': response.getcode(),
                'body': result
            }

    except urllib.error.HTTPError as e:
        return {
            'statusCode': e.code,
            'body': e.read().decode()
        }
