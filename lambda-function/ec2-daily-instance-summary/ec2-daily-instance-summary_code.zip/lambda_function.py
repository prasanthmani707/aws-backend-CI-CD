import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timedelta, timezone

def lambda_handler(event, context):
    regions = ['us-east-2', 'us-east-1', 'ap-northeast-1', 'us-west-1']
    sender = "kaliyappan.rangan@softmania.in"
    recipient = "eng-team@softmania.in"
    subject = "Daily EC2 Instance Summary (SoftMania DEV AWS)"

    # Get AWS Account ID
    sts = boto3.client('sts')
    account_id = sts.get_caller_identity()['Account']

    # IST time calculation
    ist_offset = timedelta(hours=5, minutes=30)
    ist_time = datetime.now(timezone.utc) + ist_offset
    current_time = ist_time.strftime('%Y-%m-%d %H:%M:%S IST')

    # ---------- DYNAMIC SUMMARY LOGIC ----------
    summary_rows = []
    
    for region in regions:
        ec2 = boto3.client('ec2', region_name=region)
        instances = ec2.describe_instances()

        for reservation in instances["Reservations"]:
            for instance in reservation["Instances"]:

                instance_id = instance["InstanceId"]
                instance_type = instance["InstanceType"]
                state = instance["State"]["Name"]

                # Extract Name tag
                name = "No-Name"
                if "Tags" in instance:
                    for t in instance["Tags"]:
                        if t["Key"] == "Name":
                            name = t["Value"]
                
                # Only stop running instances
                if state == "running":

                    # STOP INSTANCE
                    ec2.stop_instances(InstanceIds=[instance_id])

                    # Add into email table
                    summary_rows.append([
                        instance_id,
                        name,
                        region,
                        instance_type,
                        "Stopped"
                    ])
    # -------------------------------------------

    # Premium HTML Email Body
    html_body = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>EC2 Daily Automation Summary</title>
        <style>
            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}
            
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                line-height: 1.6;
                color: #333;
                background-color: #f8f9fa;
                padding: 20px;
            }}
            
            .email-container {{
                max-width: 800px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 12px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                overflow: hidden;
            }}
            
            .header {{
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }}
            
            .header h1 {{
                font-size: 28px;
                font-weight: 600;
                margin-bottom: 10px;
            }}
            
            .header .subtitle {{
                font-size: 16px;
                opacity: 0.9;
            }}
            
            .content {{
                padding: 30px;
            }}
            
            .info-section {{
                background: #f8f9fa;
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 25px;
                border-left: 4px solid #667eea;
            }}
            
            .info-row {{
                display: flex;
                justify-content: space-between;
                margin-bottom: 8px;
                padding: 8px 0;
                border-bottom: 1px solid #e9ecef;
            }}
            
            .info-label {{
                font-weight: 600;
                color: #495057;
            }}
            
            .info-value {{
                color: #212529;
                font-weight: 500;
            }}
            
            .summary-table {{
                width: 100%;
                border-collapse: collapse;
                margin: 25px 0;
                font-size: 14px;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }}
            
            .summary-table th {{
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 15px 12px;
                text-align: left;
                font-weight: 600;
                text-transform: uppercase;
                font-size: 12px;
                letter-spacing: 0.5px;
            }}
            
            .summary-table td {{
                padding: 14px 12px;
                border-bottom: 1px solid #e9ecef;
                color: #495057;
            }}
            
            .summary-table tr:nth-child(even) {{
                background-color: #f8f9fa;
            }}
            
            .summary-table tr:hover {{
                background-color: #e3f2fd;
                transition: background-color 0.2s ease;
            }}
            
            .status-badge {{
                display: inline-block;
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }}
            
            .status-stopped {{
                background-color: #ffeaa7;
                color: #e17055;
            }}
            
            .no-instances {{
                text-align: center;
                padding: 40px 20px;
                color: #6c757d;
                font-style: italic;
                background: #f8f9fa;
                border-radius: 8px;
                margin: 20px 0;
            }}
            
            .footer {{
                background: #343a40;
                color: #adb5bd;
                text-align: center;
                padding: 20px;
                font-size: 12px;
            }}
            
            .footer a {{
                color: #667eea;
                text-decoration: none;
            }}
            
            .instance-id {{
                font-family: 'Courier New', monospace;
                font-size: 12px;
                color: #495057;
            }}
            
            @media (max-width: 600px) {{
                .email-container {{
                    border-radius: 0;
                    box-shadow: none;
                }}
                
                .header {{
                    padding: 20px;
                }}
                
                .header h1 {{
                    font-size: 24px;
                }}
                
                .content {{
                    padding: 20px;
                }}
                
                .info-row {{
                    flex-direction: column;
                }}
                
                .summary-table {{
                    font-size: 12px;
                }}
                
                .summary-table th,
                .summary-table td {{
                    padding: 10px 8px;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="header">
                <h1>🚀 EC2 Daily Automation Summary</h1>
                <div class="subtitle">Renuka AWS - Automated Instance Management</div>
            </div>
            
            <div class="content">
                <div class="info-section">
                    <div class="info-row">
                        <span class="info-label">AWS Account ID:</span>
                        <span class="info-value">{account_id}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Execution Time:</span>
                        <span class="info-value">{current_time}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Regions Monitored:</span>
                        <span class="info-value">{', '.join(regions)}</span>
                    </div>
                </div>
    """

    if summary_rows:
        html_body += """
                <h3 style="color: #495057; margin-bottom: 20px; font-size: 18px;">
                    📊 Instance Management Summary
                </h3>
                <table class="summary-table">
                    <thead>
                        <tr>
                            <th>Instance ID</th>
                            <th>Instance Name</th>
                            <th>Region</th>
                            <th>Instance Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
        """
        
        for row in summary_rows:
            html_body += f"""
                        <tr>
                            <td><span class="instance-id">{row[0]}</span></td>
                            <td>{row[1]}</td>
                            <td>{row[2]}</td>
                            <td>{row[3]}</td>
                            <td><span class="status-badge status-stopped">{row[4]}</span></td>
                        </tr>
            """
        
        html_body += """
                    </tbody>
                </table>
        """
    else:
        html_body += """
                <div class="no-instances">
                    <h3 style="color: #6c757d; margin-bottom: 15px;">✅ All Systems Optimal</h3>
                    <p>No EC2 instances were in the running state across the monitored regions.<br>
                    All instances are already in stopped state or properly managed.</p>
                </div>
        """

    html_body += """
            </div>
            
            <div class="footer">
                <p>This is an automated report generated by AWS Lambda EC2 Automation System</p>
                <p>For any questions or concerns, please contact your AWS administrator</p>
                <p style="margin-top: 15px; font-size: 11px; color: #6c757d;">
                    &copy; 2024 Renuka AWS Management System. All rights reserved.
                </p>
            </div>
        </div>
    </body>
    </html>
    """

    # Print debug info
    print("HTML EMAIL BODY LENGTH:", len(html_body), "characters")

    # Send Email using SES with HTML format
    ses = boto3.client('ses', region_name='us-east-1')
    try:
        response = ses.send_email(
            Source=sender,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {'Data': subject},
                'Body': {
                    'Html': {'Data': html_body},
                    'Text': {'Data': "Please view this email in an HTML-compatible email client."}
                }
            }
        )
        print("SES response:", response)
    except ClientError as e:
        print("SES ERROR:", e.response['Error']['Message'])
        return {"status": "Email Failed"}

    return {"status": "Email Sent Successfully"}