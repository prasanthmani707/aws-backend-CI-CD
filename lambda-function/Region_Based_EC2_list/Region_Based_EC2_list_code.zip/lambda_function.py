import boto3
import json

def lambda_handler(event, context):
    try:
        http_method = (
            event.get("httpMethod") or
            event.get("requestContext", {})
                 .get("http", {})
                 .get("method", "GET")
        )

        if http_method != "GET":
            return response(405, {"message": "Method Not Allowed"})

        query_params = event.get("queryStringParameters") or {}
        region = query_params.get("region")

        if not region:
            return response(400, {
                "message": "region query parameter is required"
            })

        instances = []

        # region = all
        if region == "all":
            ec2_global = boto3.client("ec2")
            regions = ec2_global.describe_regions(AllRegions=False)["Regions"]

            for r in regions:
                region_name = r["RegionName"]
                ec2 = boto3.client("ec2", region_name=region_name)
                paginator = ec2.get_paginator("describe_instances")

                for page in paginator.paginate():
                    for reservation in page["Reservations"]:
                        for instance in reservation["Instances"]:
                            instances.append(
                                format_instance(instance, region_name)
                            )

        else:
            ec2 = boto3.client("ec2", region_name=region)
            paginator = ec2.get_paginator("describe_instances")

            for page in paginator.paginate():
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        instances.append(
                            format_instance(instance, region)
                        )

        return response(200, {
            "region": region,
            "count": len(instances),
            "instances": instances
        })

    except Exception as e:
        return response(500, {"error": str(e)})


def format_instance(instance, region):
    return {
        "instance_id": instance.get("InstanceId"),
        "instance_type": instance.get("InstanceType"),
        "state": instance.get("State", {}).get("Name"),
        "private_ip": instance.get("PrivateIpAddress"),
        "public_ip": instance.get("PublicIpAddress"),
        "availability_zone": instance.get("Placement", {}).get("AvailabilityZone"),
        "launch_time": instance.get("LaunchTime").isoformat(),
        "platform_details": instance.get("PlatformDetails"),
        "key_name": instance.get("KeyName"),
        "tags": {
            tag["Key"]: tag["Value"]
            for tag in instance.get("Tags", [])
        },
        "region": region
    }


def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps(body)
    }
