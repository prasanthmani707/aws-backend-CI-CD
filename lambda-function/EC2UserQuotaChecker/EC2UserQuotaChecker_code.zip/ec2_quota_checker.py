import boto3
import json
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import re
import urllib.parse

ec2 = boto3.client('ec2')
dynamodb = boto3.resource('dynamodb')
ses = boto3.client('ses')
table = dynamodb.Table('ManageEC2Instances')

SES_CONFIGURATION_SET = "softmania-ses-config"
SENDER_EMAIL = "kaliyappan.rangan@softmania.in"

def generate_chart_url(used_percent, remaining_percent):
    """Generate QuickChart URL dynamically by reading from JSON file"""
    
    try:
        # Read the JSON configuration file
        with open('chart_config.json', 'r') as file:
            chart_config = json.load(file)
        
        # Replace placeholders with actual data
        chart_config['data']['datasets'][0]['data'] = [used_percent, remaining_percent]
        chart_config['options']['elements']['center']['text'] = f"{used_percent:.0f}%"
        
        # Convert config to JSON string and URL encode it
        config_json = json.dumps(chart_config)
        encoded_config = urllib.parse.quote(config_json)
        
        # Generate the QuickChart URL
        chart_url = f"https://quickchart.io/chart?c={encoded_config}&width=500&height=300&backgroundColor=white"
        
        return chart_url
        
    except Exception as e:
        # Fallback URL if JSON file reading fails
        print(f"Error reading chart config: {str(e)}")
        return f"https://quickchart.io/chart/render/zf-bbff266f-51b8-4d67-b566-926b98980610?data1={used_percent:.1f},{remaining_percent:.1f}"

def lambda_handler(event, context):
    if isinstance(event, dict) and event.get("eventType") == "Delivery":
        print("[INFO] Received raw SES delivery event (test mode)")
        handle_raw_ses_event(event)
        return

    if 'Records' in event:
        for record in event['Records']:
            if 'Sns' in record:
                try:
                    message = json.loads(record['Sns']['Message'])
                    if message.get("eventType") == "Delivery":
                        print("[INFO] Received SNS-based SES delivery event")
                        handle_raw_ses_event(message)
                except Exception as e:
                    print(f"[ERROR] Failed to parse SNS message: {e}")
        return

    run_quota_checker()


def run_quota_checker():
    now = datetime.now(timezone.utc)

    response = ec2.describe_instances(
        Filters=[{'Name': 'tag-key', 'Values': ['UserEmail']}]
    )

    user_instances = {}

    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            state = instance['State']['Name']
            tags = {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}

            email = tags.get('UserEmail')
            service_type = tags.get('ServiceType', 'General')
            category_raw = tags.get('Category', 'General')

            if not email:
                continue

            price_match = re.search(r'\d+', category_raw)
            price = price_match.group(0) if price_match else '0'

            instance_name = tags.get('Name', instance_id)

            run_quota = float(tags.get('RunQuotaHours', '0'))
            hours_per_day = float(tags.get('HoursPerDay', '2'))
            plan_start_str = tags.get('PlanStartDate')

            if not run_quota or not plan_start_str:
                continue

            try:
                plan_start = datetime.fromisoformat(plan_start_str.replace("Z", "+00:00"))
                if plan_start.tzinfo is None:
                    plan_start = plan_start.replace(tzinfo=timezone.utc)
            except Exception as e:
                print(f"[ERROR] Invalid PlanStartDate format: {e}")
                continue

            plan_start_str_for_key = plan_start.strftime("%Y-%m-%dT%H:%M:%S")

            # ✅ For DataSources, track every instance individually using instance ID
            if service_type == "DataSources":
                user_key = f"{email}#{service_type}#{price}#{plan_start_str_for_key}#{instance_id}"
            else:
                user_key = f"{email}#{service_type}#{price}#{plan_start_str_for_key}"

            if user_key not in user_instances:
                user_instances[user_key] = {
                    'Email': email,
                    'ServiceType': service_type,
                    'Category': price,
                    'Instances': [],
                    'RunQuotaHours': run_quota,
                    'HoursPerDay': hours_per_day,
                    'PlanStartDate': plan_start,
                }

            user_instances[user_key]['Instances'].append({
                'InstanceId': instance_id,
                'State': state,
                'Name': instance_name
            })

    for user_key, user_data in user_instances.items():
        email = user_data['Email']
        service_type = user_data['ServiceType']

        item = table.get_item(Key={'UserEmail': user_key}).get('Item', {})
        is_new = not item

        used = float(item.get('TotalHoursUsed', 0))
        last_time = datetime.fromisoformat(item.get('LastCheckedTime')) if item.get('LastCheckedTime') else now
        notify = item.get('NotifyLevel', 'none')

        if last_time != now:
            delta_hours = (now - last_time).total_seconds() / 3600
            running_instances = [inst for inst in user_data['Instances'] if inst['State'] == 'running']
            if running_instances:
                used += delta_hours

        percent = (used / user_data['RunQuotaHours']) * 100
        max_days = user_data['RunQuotaHours'] / user_data['HoursPerDay']
        plan_end = user_data['PlanStartDate'] + timedelta(days=max_days)
        buffer = timedelta(minutes=5)
        expired_by_date = now >= (plan_end + buffer)

        days_elapsed = (now - user_data['PlanStartDate']).days
        # keep fraction calculation like before, but use int for "days allowed" to match existing behavior
        days_allowed = int(max_days)
        days_percent = (days_elapsed / days_allowed) * 100 if days_allowed > 0 else 0
        max_percent = max(percent, days_percent)

        quota_exceeded = percent >= 100
        date_exceeded = days_percent >= 100
        fifty_percent_reached = max_percent >= 75 and notify == 'none'
        hundred_percent_reached = max_percent >= 100 and notify != '100'

        instance_ids = [inst['InstanceId'] for inst in user_data['Instances']]

        # -----------------------------
        # NEW: send an alert when the *number of days* has matched/exceeded the allowed days
        # without changing existing termination behaviour.
        # This adds a one-off notify state 'days' (so we don't spam repeated emails),
        # and does NOT change the existing '75' and '100' notification states logic.
        # -----------------------------
        try:
            # days_match: True when days_elapsed >= days_allowed
            days_match = False
            if days_allowed > 0 and days_elapsed >= days_allowed:
                days_match = True

            # Send a "days match" alert if days reached/exceeded, not yet expired by the date buffer,
            # and we haven't already sent a days alert.
            if days_match and not expired_by_date and notify not in ('100', 'days'):
                # Use max_percent or 100 for message clarity; keep terminated=False so we don't conflict
                send_ses(
                    email,
                    alert_template(
                        email,
                        user_data['RunQuotaHours'],
                        used,
                        max(100.0, max_percent),  # show 100% to indicate days reached
                        service_type,
                        terminated=False,
                        plan_start_dt=user_data['PlanStartDate'],
                        hours_per_day=user_data['HoursPerDay']
                    ),
                    service_type
                )
                # mark that we sent the days-based alert so it won't repeat
                notify = 'days'
        except Exception as e:
            print(f"[ERROR] While processing days-match alert: {e}")
        # -----------------------------
        # End of NEW block
        # -----------------------------

        if quota_exceeded or date_exceeded:
            if instance_ids:
                try:
                    ec2.terminate_instances(InstanceIds=instance_ids)
                    print(f"[TERMINATED] {instance_ids} (User: {email}, Reason: Quota or Plan Duration exceeded)")
                except Exception as e:
                    print(f"[TERMINATE ERROR] {e}")

            if hundred_percent_reached:
                send_ses(
                    email,
                    alert_template(
                        email,
                        user_data['RunQuotaHours'],
                        used,
                        max_percent,
                        service_type,
                        terminated=True,
                        plan_start_dt=user_data['PlanStartDate'],
                        hours_per_day=user_data['HoursPerDay']
                    ),
                    service_type
                )
                notify = '100'

        elif fifty_percent_reached:
            send_ses(
                email,
                alert_template(
                    email,
                    user_data['RunQuotaHours'],
                    used,
                    max_percent,
                    service_type,
                    terminated=False,
                    plan_start_dt=user_data['PlanStartDate'],
                    hours_per_day=user_data['HoursPerDay']
                ),
                service_type
            )
            notify = '75'

        if is_new:
            welcome_key = f"{email}#{service_type}"
            try:
                welcome_status = table.get_item(Key={'UserEmail': f"welcome#{welcome_key}"})
                if 'Item' not in welcome_status:
                    send_welcome_email(email, service_type)
                    table.put_item(Item={
                        'UserEmail': f"welcome#{welcome_key}",
                        'Sent': True,
                        'Timestamp': now.isoformat()
                    })
            except Exception as e:
                print(f"[ERROR] While checking/saving welcome email status: {e}")

        table.put_item(Item={
            'UserEmail': user_key,
            'InstanceIds': instance_ids,
            'TotalHoursUsed': Decimal(str(used)),
            'LastCheckedTime': now.isoformat(),
            'RunQuotaHours': Decimal(str(user_data['RunQuotaHours'])),
            'PlanStartDate': user_data['PlanStartDate'].isoformat(),
            'HoursPerDay': Decimal(str(user_data['HoursPerDay'])),
            'NotifyLevel': notify
        })


def send_welcome_email(email, service_type):
    subject = f"👋 Welcome to SoftMania Lab Wizard ({service_type})"
    message = welcome_template(email, service_type)

    try:
        ses.send_email(
            Source=SENDER_EMAIL,
            Destination={'ToAddresses': [email]},
            Message={
                'Subject': {'Data': subject},
                'Body': {'Text': {'Data': message}}
            },
            ConfigurationSetName=SES_CONFIGURATION_SET
        )
        print(f"[INFO] Welcome email sent to {email} for {service_type}")
    except Exception as e:
        print(f"[SES ERROR] {e}")


def send_ses(email, message, service_type):
    """
    Sends an email with both HTML and plain-text fallback.
    If `message` contains HTML it will be put into Body.Html, otherwise Body.Text is used.
    We always include a Text fallback by stripping HTML tags (simple regex).
    """
    subject = f"🔔 Server Quota Alert – SoftMania ({service_type})"

    # Simple HTML detection
    is_html = False
    try:
        if isinstance(message, str) and ('<html' in message.lower() or message.strip().startswith('<!doctype') or '<body' in message.lower()):
            is_html = True
    except Exception:
        is_html = False

    # Create a plain-text fallback by stripping tags (very simple)
    def strip_html_to_text(html_text):
        try:
            # Remove script/style blocks
            html_text = re.sub(r'(?s)<(script|style).*?>.*?</\1>', '', html_text, flags=re.I)
            # Replace tags with spaces
            text = re.sub(r'<[^>]+>', '', html_text)
            # Unescape HTML entities for basic ones
            text = text.replace('&nbsp;', ' ').replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').strip()
            # Collapse multiple newlines/spaces
            text = re.sub(r'\n\s+\n', '\n\n', text)
            text = re.sub(r'[ \t]{2,}', ' ', text)
            return text
        except Exception:
            return re.sub(r'<[^>]+>', '', str(html_text))

    body_text = strip_html_to_text(message) if is_html else str(message)

    try:
        if is_html:
            ses.send_email(
                Source=SENDER_EMAIL,
                Destination={'ToAddresses': [email]},
                Message={
                    'Subject': {'Data': subject},
                    'Body': {
                        'Html': {'Data': message},
                        'Text': {'Data': body_text}
                    }
                },
                ConfigurationSetName=SES_CONFIGURATION_SET
            )
        else:
            # plain text only
            ses.send_email(
                Source=SENDER_EMAIL,
                Destination={'ToAddresses': [email]},
                Message={
                    'Subject': {'Data': subject},
                    'Body': {
                        'Text': {'Data': body_text}
                    }
                },
                ConfigurationSetName=SES_CONFIGURATION_SET
            )
        print(f"[INFO] Quota alert email sent to {email} for {service_type}")
    except Exception as e:
        print(f"[SES ERROR] {e}")


def welcome_template(email, service_type):
    line = "=" * 40
    LAB_URL = "https://splunklab.softmania.in/lab"
    SUPPORT_EMAIL = "labsupport@softmania.in"

    return f"""
Welcome aboard! 🎉 Your lab environment for {service_type} is now live and ready.

Hi {email},

🚀 What you can do now:
✔️ Start or stop your assigned EC2 servers  
✔️ Access the Splunk Lab for analysis and learning  
✔️ Monitor your usage

🔗 Lab Access:  
👉 {LAB_URL}  
🔐 Sign in with your Google account.

🕒 How Usage Quota Works:
- You have a set number of hours per day, up to a total quota.
- At 75% usage: ⚠️ you'll receive a usage warning.
- At 100% or on expiry: ❌ servers will be auto-terminated.

📬 You'll receive automated alerts based on usage. Stay informed and plan accordingly.

💬 Need Help?  
Reach out to our support team at {SUPPORT_EMAIL}  
We're here to help you make the most of your lab experience.

Happy experimenting! 🔬  
— Team SoftMania
"""

def alert_template(email, quota, used, percent, service_type, terminated=False, plan_start_dt=None, hours_per_day=2):
    from datetime import datetime, timedelta, timezone
    from zoneinfo import ZoneInfo

    # Constants
    LAB_URL = "https://splunklab.softmania.in/lab"
    SUPPORT_EMAIL = "labsupport@softmania.in"
    WHATSAPP_CONTACT = "https://wa.me/918317349618?text=Hi%2C+I+need+to+increase+the+quota+for+my+server."

    # Timezone setup
    IST_OFFSET = timedelta(hours=5, minutes=30)
    IST = timezone(IST_OFFSET)

    try:
        US_TZ = ZoneInfo("America/New_York")
    except Exception:
        US_TZ = timezone.utc

    # Compute plan expiry times
    try:
        if plan_start_dt is not None:
            total_days = float(quota) / float(hours_per_day)
            terminate_utc = plan_start_dt + timedelta(days=total_days)
            scheduled_terminate_ist = terminate_utc.astimezone(IST).strftime("%Y-%m-%d %I:%M %p (IST)")
            scheduled_terminate_utc = terminate_utc.strftime("%Y-%m-%d %H:%M:%S (UTC)")
        else:
            scheduled_terminate_ist = "Unknown"
            scheduled_terminate_utc = "Unknown"
    except Exception:
        scheduled_terminate_ist = "Unknown"
        scheduled_terminate_utc = "Unknown"

    now_utc = datetime.now(timezone.utc)
    now_ist_str = now_utc.astimezone(IST).strftime("%Y-%m-%d %I:%M %p (IST)")
    now_us_str = now_utc.astimezone(US_TZ).strftime("%Y-%m-%d %I:%M %p (%Z)")

    # Safe numeric parsing
    try:
        pct = float(percent)
    except Exception:
        pct = 0.0
    try:
        quota_f = float(quota)
    except Exception:
        quota_f = 0.0
    try:
        used_f = float(used)
    except Exception:
        used_f = 0.0

    remaining_hours = max(0.0, quota_f - used_f)
    
    # Generate dynamic chart URL using the external JSON file
    remaining_pct = max(0, 100 - pct)
    chart_url = generate_chart_url(pct, remaining_pct)

    # === Terminated Email (Plain Text) ===
    if terminated:
        return f"""❌ Quota Exceeded – Your {service_type} Server is Terminated

Hi {email},

Your usage quota for the {service_type} lab has been fully consumed, or the plan duration has ended.

📊 Quota Limit   : {quota_f:.2f} hours  
⏱️ Total Used   : {used_f:.2f} hours  
📈 Usage Level  : {pct:.0f}%  

🕓 Scheduled Termination Time (IST): {scheduled_terminate_ist}  
🕓 Scheduled Termination Time (UTC) : {scheduled_terminate_utc}  
🕓 Actual Terminated On (IST)      : {now_ist_str}  
🕓 Actual Terminated On (UTC)       : {now_us_str}

As per our policy, your instance(s) have been automatically terminated to avoid overuse.

🔐 You can review your usage or start a new plan if needed:  
👉 {LAB_URL}

💬 Questions or renewal support?  
Reach us at {SUPPORT_EMAIL}  
WhatsApp: {WHATSAPP_CONTACT}

Thanks for using SoftMania Lab Wizard.  
We hope it helped you experiment and learn productively!
"""

    html = f"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Server Usage Alert</title>
  <style>
    /* Base Styles - Mobile First */
    * {{
      box-sizing: border-box;
    }}
    
    body {{
      font-family: Arial, Helvetica, sans-serif;
      background: #f6f7fb;
      margin: 0;
      padding: 5vw;
      font-size: clamp(14px, 4vw, 18px);
      line-height: 1.4;
    }}
    
    .card {{
      width: 100%;
      max-width: 700px;
      margin: 0 auto;
      background: #ffffff;
      border-radius: clamp(6px, 2vw, 8px);
      box-shadow: 0 3px 12px rgba(0,0,0,0.08);
      overflow: hidden;
    }}
    
    .header {{
      background: #ff0000;
      color: #fff;
      padding: clamp(12px, 3vw, 16px) clamp(15px, 4vw, 24px);
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      font-size: clamp(18px, 5vw, 26px);
      text-align: center;
    }}
    
    .content {{
      padding: clamp(20px, 5vw, 28px) clamp(15px, 5vw, 40px);
      color: #000000;
      font-size: clamp(16px, 4vw, 20px);
    }}
    
    .chart-container {{
      text-align: center;
      margin: clamp(20px, 5vw, 25px) 0 clamp(25px, 6vw, 35px) 0;
    }}
    
    .chart-table {{
      width: 100%;
      max-width: min(500px, 90vw);
      height: clamp(140px, 40vw, 300px);
      margin: 0 auto;
      border-radius: 10px;
      overflow: hidden;
      display: table;
    }}
    
    .chart-cell {{
      text-align: center;
      vertical-align: middle;
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      width: 100%;
      height: 100%;
      display: table-cell;
      position: relative;
    }}
    
    .percentage-text {{
      font-size: clamp(42px, 12vw, 70px);
      font-weight: 900;
      color: #ff0000;
      line-height: 1;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-shadow: 3px 3px 6px rgba(255, 255, 255, 0.9);
      letter-spacing: -1px;
      margin-top: 110px;
      width: 100%;
      text-align: center;
    }}
    
    .usage-label {{
      font-size: clamp(18px, 5vw, 22px);
      color: #000000;
      font-weight: bold;
      margin: clamp(10px, 3vw, 18px) 0;
    }}
    
    .remaining-hours {{
      display: inline-flex;
      align-items: center;
      margin: clamp(12px, 3vw, 18px) auto;
      background-color: #d4edda;
      border: 1px solid #27ae60;
      border-radius: 6px;
      padding: clamp(8px, 2vw, 10px) clamp(15px, 3vw, 20px);
      color: #2c3e50;
      font-weight: 700;
      font-size: clamp(18px, 5vw, 28px);
      max-width: 90%;
    }}
    
    .expiry-info {{
      margin: clamp(10px, 3vw, 12px) auto;
      color: #000000;
      font-size: clamp(14px, 3vw, 16px);
      line-height: 1.6;
      text-align: center;
      max-width: 90%;
    }}
    
    .expiry-title {{
      font-weight: bold;
      margin-bottom: 5px;
      font-size: clamp(16px, 4vw, 20px);
    }}
    
    .expiry-times {{
      line-height: 1.4;
      font-size: clamp(14px, 3vw, 17px);
    }}
    
    .stats-table {{
      width: 100%;
      border-collapse: collapse;
      margin: clamp(15px, 4vw, 20px) 0;
      font-size: clamp(14px, 3vw, 16px);
    }}
    
    .stats-table td {{
      padding: clamp(8px, 2vw, 10px) clamp(10px, 2vw, 12px);
      border: 1px solid #e9eef2;
    }}
    
    .stats-left {{
      background: #f6f7fb;
      width: 55%;
      font-weight: 600;
      color: #000000;
    }}
    
    .note {{
      background: #fff8e1;
      border-left: 4px solid #f1c40f;
      padding: clamp(12px, 3vw, 14px);
      margin: clamp(12px, 3vw, 14px) 0;
      border-radius: 4px;
      color: #6b4d00;
      font-size: clamp(14px, 3vw, 16px);
      line-height: 1.5;
    }}
    
    .cta {{
      margin: clamp(15px, 4vw, 16px) 0;
      text-align: center;
    }}
    
    .btn-primary {{
      display: inline-block;
      padding: clamp(10px, 2vw, 12px) clamp(15px, 3vw, 22px);
      border-radius: 6px;
      background: #25D366;
      color: #fff;
      text-decoration: none;
      font-weight: 700;
      font-size: clamp(16px, 4vw, 18px);
      box-shadow: 0 3px 0 rgba(0,0,0,0.06);
      max-width: 90%;
      margin: 0 auto;
    }}
    
    .btn-primary:hover {{
      background: #1ebd5a;
    }}
    
    .manage-link {{
      display: inline-block;
      margin: clamp(8px, 2vw, 10px) 0;
      color: #0843b8;
      text-decoration: none;
      font-size: clamp(14px, 3vw, 16px);
    }}
    
    .manage-link:hover {{
      text-decoration: underline;
    }}
    
    .footer {{
      padding: clamp(15px, 4vw, 18px) clamp(20px, 5vw, 40px) clamp(20px, 5vw, 28px);
      text-align: center;
      font-size: clamp(13px, 3vw, 15px);
      color: #000000;
      line-height: 1.5;
    }}
    
    /* Desktop Enhancements */
    @media (min-width: 768px) {{
      .header {{
        justify-content: flex-start;
        text-align: left;
      }}
      
      .content {{
        text-align: left;
      }}
      
      .btn-primary {{
        max-width: none;
      }}
    }}
    
    /* Large Desktop */
    @media (min-width: 1200px) {{
      body {{
        padding: 20px;
      }}
    }}
  </style>
</head>
<body>
  <div class="card" role="article" aria-label="Server Usage Alert">
    <div class="header">⚠️ URGENT: Server Usage Alert</div>
    <div class="content">
      <p style="margin:0 0 8px 0;">Hi <strong>{email.split('@')[0] if email else email}</strong>,</p>
      <p style="margin:0 0 18px 0; color:#000000;">Your <strong>Splunk Lab Server</strong> usage status is as follows:</p>

      <div class="chart-container">
        <table class="chart-table" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td class="chart-cell" style="background-image: url('{chart_url}'); background-size: cover; background-position: center;">
              <div class="percentage-text">{pct:.0f}%</div>
            </td>
          </tr>
        </table>
        
        <div class="usage-label">Server Usage</div>
        
        <div class="remaining-hours">
          <span>⏱️</span>
          <span style="color: #27ae60; margin-left: 8px;">
            {remaining_hours:.1f} hours remaining
          </span>
        </div>

        <div class="expiry-info">
            <div class="expiry-title">Expiry / Valid Till:</div>
            <div class="expiry-times">
                IST - {scheduled_terminate_ist}<br>
                UTC - {scheduled_terminate_utc}
            </div>
        </div>
      </div>

      <table class="stats-table" role="table" aria-label="Quota Details">
        <tr>
          <td class="stats-left">Quota Assigned</td>
          <td>{quota_f:.2f} hours</td>
        </tr>
        <tr>
          <td class="stats-left">Used So Far</td>
          <td>{used_f:.2f} hours</td>
        </tr>
        <tr>
          <td class="stats-left">Usage Level</td>
          <td style="color:{('#e74c3c' if pct>=75 else '#2d9cdb')}; font-weight:700;">
            {pct:.0f}% {'(Critical)' if pct>=75 else ''}
          </td>
        </tr>
      </table>

      <div class="note" role="note">
        <strong>Note:</strong> Your server will be automatically terminated once quota or validity expires. Please act now to avoid service disruption.
      </div>

      <div class="cta">
        <a class="btn-primary" href="{WHATSAPP_CONTACT}" target="_blank" rel="noopener">
          Extend Quota Now
        </a><br/>
        <a class="manage-link" href="{LAB_URL}" target="_blank" rel="noopener">Manage Your Server</a>
      </div>
    </div>

    <div class="footer">
      For any help, contact <a href="mailto:{SUPPORT_EMAIL}">{SUPPORT_EMAIL}</a><br/>
      © SoftMania Lab Wizard
    </div>
  </div>
</body>
</html>
"""
    return html

def handle_raw_ses_event(data):
    try:
        mail = data.get('mail', {})
        delivery = data.get('delivery', {})

        email = delivery.get('recipients', [''])[0]
        timestamp = delivery.get('timestamp')
        subject = mail.get('commonHeaders', {}).get('subject', 'No Subject')

        print("✅ [SES Delivery Notification]")
        print(f"📬 To       : {email}")
        print(f"📅 Delivered: {timestamp}")
        print(f"📝 Subject  : {subject}")
    except Exception as e:
        print(f"[ERROR] While logging SES delivery: {e}")
