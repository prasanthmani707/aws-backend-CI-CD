import json
import boto3

ssm = boto3.client('ssm')

def lambda_handler(event, context):
    try:
        # Fetch both parameters at once
        response = ssm.get_parameters(
            Names=[
                '/exchange/inr_to_usd',
                '/exchange/usd_to_inr',
                '/exchange/FixedUSD'
            ],
            WithDecryption=True
        )

        params = {p['Name']: p['Value'] for p in response['Parameters']}

        inr_to_usd = params.get('/exchange/inr_to_usd')
        usd_to_inr = params.get('/exchange/usd_to_inr')
        fixed_usd = params.get('/exchange/FixedUSD')

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Exchange rates fetched successfully',
                'inr_to_usd': inr_to_usd,
                'usd_to_inr': usd_to_inr,
                'fixed_usd': fixed_usd
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }