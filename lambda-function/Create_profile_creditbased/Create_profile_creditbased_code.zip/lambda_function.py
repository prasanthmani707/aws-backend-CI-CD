import json
import boto3
import re
import os
from datetime import datetime
from botocore.exceptions import ClientError

# DynamoDB setup
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('user_profile_creditbased')

def lambda_handler(event, context):
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))

        # Required fields
        required_fields = ['email_id', 'name', 'phone', 'address']
        for field in required_fields:
            if field not in body:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": f"Missing field: {field}"})
                }

        # Normalize email
        email_id = body['email_id'].strip().lower()

        # Validate phone (string, digits only, 10 chars)
        phone = body['phone']
        # Allow international phone numbers like +919876543210
        if not isinstance(phone, str) or not re.match(r"^\+[1-9]\d{7,14}$", phone):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Phone must be in international format like +919876543210"})
            }

        # Validate address (must be object)
        address = body['address']
        if not isinstance(address, dict):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Address must be an object"})
            }

        now = datetime.utcnow().isoformat()
        
        # Update or create user profile
        table.update_item(
            Key={"email_id": email_id},
            UpdateExpression="""
                SET #n = :name,
                    phone = :phone,
                    address = :address,
                    updated_at = :updated_at,
                    created_at = if_not_exists(created_at, :created_at)
            """,
            ExpressionAttributeNames={
                "#n": "name"
            },
            ExpressionAttributeValues={
                ":name": body['name'],
                ":phone": phone,
                ":address": address,
                ":updated_at": now,
                ":created_at": now
            }
        )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Profile created/updated successfully",
                "email_id": email_id,
                "updated_at": now
            })
        }

    except ClientError as e:
        print("AWS Error:", e)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "AWS error occurred"})
        }

    except Exception as e:
        print("Internal Error:", e)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal server error"})
        }
